// Normalized intermediate representation (IR) of a Powermart XML export.
// The IR is intentionally flat and value-dense so that a future SQL generator
// can walk it without having to re-parse XML. Every original attribute is
// preserved on the `attrs` bag of the object that owned it.

export type Attrs = Readonly<Record<string, string>>

// Raw XML tree retained on the model so the "Raw XML" tab can serialize back
// from structured data instead of regex-scanning the source text.
export interface RawNode {
  tag: string
  attrs: Readonly<Record<string, string>>
  children: RawNode[]
}

export interface Field {
  name: string
  portType: string           // INPUT, OUTPUT, INPUT/OUTPUT, LOOKUP, RETURN, LOOKUP/OUTPUT, LOOKUP/RETURN, RETURN/OUTPUT, VARIABLE
  dataType: string
  precision: string
  scale: string
  expression: string         // present on OUTPUT / VARIABLE / aggregator expressions
  expressionType: string     // GENERAL, COND, AGG, …
  defaultValue: string
  description: string
  businessName: string
  pictureText: string
  group?: string             // for Router / Joiner / Union / Normalizer
  isGroupBy?: boolean        // Aggregator / Rank
  sortKey?: boolean          // Sorter
  sortDirection?: string
  rankIndex?: boolean        // Rank
  attrs: Attrs               // every raw attribute for loss-free display
}

export interface GroupDef {
  name: string
  type: 'INPUT' | 'OUTPUT'
  order: number
  description: string
  // Router output-group filter condition. Real Informatica exports carry it
  // on the GROUP element's EXPRESSION attribute (powrmart.dtd:
  // `GROUP.EXPRESSION CDATA #IMPLIED`). Empty for INPUT and DEFAULT groups.
  expression: string
  attrs: Attrs
}

export interface InitProp {
  name: string
  value: string
}

export interface Transformation {
  name: string
  type: string           // 'Expression', 'Lookup Procedure', 'Aggregator', ...
  reusable: boolean
  description: string
  fields: Field[]
  groups: GroupDef[]
  tableAttributes: { name: string; value: string }[]
  initProps: InitProp[]
  attrs: Attrs
}

export interface SourceField {
  name: string
  dataType: string
  precision: string
  scale: string
  keyType: string
  nullable: string
  fieldNumber: string
  attrs: Attrs
}

export interface FlatFileSpec {
  attrs: Attrs
}

export interface Source {
  name: string
  databaseType: string
  dbdName: string
  ownerName: string
  description: string
  isFlatFile: boolean
  flatFile?: FlatFileSpec
  fields: SourceField[]
  tableAttributes: { name: string; value: string }[]
  attrs: Attrs
}

export interface TargetField {
  name: string
  dataType: string
  precision: string
  scale: string
  keyType: string
  nullable: string
  fieldNumber: string
  attrs: Attrs
}

export interface Target {
  name: string
  databaseType: string
  description: string
  fields: TargetField[]
  tableAttributes: { name: string; value: string }[]
  attrs: Attrs
}

export interface Shortcut {
  name: string
  objectType: string       // SOURCE, TARGET, TRANSFORMATION, ...
  refFolder: string
  refObject: string
  refRepository: string
  referenceType: string    // GLOBAL, LOCAL
  attrs: Attrs
}

export interface MappingVariable {
  name: string
  dataType: string
  precision: string
  scale: string
  aggregationType: string
  defaultValue: string
  description: string
  userDefined: boolean
  attrs: Attrs
}

export interface Instance {
  name: string
  type: 'SOURCE' | 'TARGET' | 'TRANSFORMATION'
  transformationName: string
  transformationType: string
  reusable: boolean
  associatedSourceInstance?: string
  description: string
  attrs: Attrs
}

export interface Connector {
  fromInstance: string
  fromField: string
  fromGroup?: string
  fromInstanceType?: string
  toInstance: string
  toField: string
  toGroup?: string
  toInstanceType?: string
  attrs: Attrs
}

export interface TargetLoadOrder {
  targetInstance: string
  order: number
}

export interface Mapping {
  name: string
  description: string
  isValid: boolean
  // Inline (non-reusable) transformations defined inside this mapping.
  transformations: Transformation[]
  instances: Instance[]
  connectors: Connector[]
  mappingVariables: MappingVariable[]
  targetLoadOrder: TargetLoadOrder[]
  attrs: Attrs
}

export interface WorkflowLink {
  fromTask: string
  toTask: string
  condition: string
  attrs: Attrs
}

export interface Session {
  name: string
  mappingName: string
  description: string
  reusable: boolean
  attributes: { name: string; value: string }[]
  attrs: Attrs
}

export interface Task {
  name: string
  type: string            // Start, Command, Email, Decision, ...
  reusable: boolean
  description: string
  attrs: Attrs
}

export interface Workflow {
  name: string
  description: string
  isValid: boolean
  sessions: Session[]
  tasks: Task[]
  links: WorkflowLink[]
  attrs: Attrs
}

export interface Folder {
  name: string
  description: string
  owner: string
  shared: boolean
  sources: Source[]
  targets: Target[]
  transformations: Transformation[]  // reusable
  shortcuts: Shortcut[]
  mappings: Mapping[]
  workflows: Workflow[]
  attrs: Attrs
}

export interface Repository {
  name: string
  version: string
  codepage: string
  databaseType: string
  folders: Folder[]
  attrs: Attrs
}

export interface PowermartModel {
  creationDate: string
  repositoryVersion: string
  repositories: Repository[]
  // Total byte size of the parsed source — handy for showing in the header.
  sourceSize: number
  // POWERMART root node of the raw XML tree, used for the Raw XML tab.
  rawTree: RawNode
}

// ---- Selection model for the UI ----------------------------------------

export type SelectedObject =
  | { kind: 'source'; folder: string; name: string }
  | { kind: 'target'; folder: string; name: string }
  | { kind: 'transformation'; folder: string; name: string }
  | { kind: 'shortcut'; folder: string; name: string }
  | { kind: 'mapping'; folder: string; name: string }
  | { kind: 'workflow'; folder: string; name: string }
  | { kind: 'instance'; folder: string; mapping: string; name: string }
