import { useCallback, useEffect, useMemo, useState } from 'react'
import { parsePowermart, type ParseProgress } from './parser'
import type { PowermartModel, SelectedObject } from './ir'
import { TreeBrowser } from './TreeBrowser'
import { Detail } from './Detail'
import { clearLayoutCache } from './MappingGraph.layout'

function humanBytes(n: number): string {
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`
}

const SIDEBAR_KEY = 'pm.sidebarWidth'
const SIDEBAR_MIN = 180
const SIDEBAR_MAX = 720
const SIDEBAR_DEFAULT = 320

export default function App() {
  const [model, setModel] = useState<PowermartModel | null>(null)
  const [progress, setProgress] = useState<ParseProgress | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [selected, setSelected] = useState<SelectedObject | null>(null)
  const [dragging, setDragging] = useState(false)
  const [loadedName, setLoadedName] = useState<string>('')
  const [sidebarWidth, setSidebarWidth] = useState<number>(() => {
    const saved = Number(localStorage.getItem(SIDEBAR_KEY))
    return Number.isFinite(saved) && saved >= SIDEBAR_MIN && saved <= SIDEBAR_MAX
      ? saved : SIDEBAR_DEFAULT
  })

  const onResizeStart = useCallback((e: React.MouseEvent) => {
    e.preventDefault()
    const startX = e.clientX
    const startWidth = sidebarWidth
    let latest = startWidth
    const onMove = (ev: MouseEvent) => {
      latest = Math.max(SIDEBAR_MIN, Math.min(SIDEBAR_MAX, startWidth + ev.clientX - startX))
      setSidebarWidth(latest)
    }
    const onUp = () => {
      document.removeEventListener('mousemove', onMove)
      document.removeEventListener('mouseup', onUp)
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
      localStorage.setItem(SIDEBAR_KEY, String(latest))
    }
    document.body.style.cursor = 'col-resize'
    document.body.style.userSelect = 'none'
    document.addEventListener('mousemove', onMove)
    document.addEventListener('mouseup', onUp)
  }, [sidebarWidth])

  const loadText = useCallback(async (text: string, name: string) => {
    setError(null)
    setSelected(null)
    clearLayoutCache()
    setProgress({ bytesRead: 0, totalBytes: text.length, phase: 'parsing' })
    try {
      const m = await parsePowermart(text, (p) => setProgress(p))
      setModel(m)
      setLoadedName(name)
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setProgress(null)
    }
  }, [])

  // Warm up heavy chunks (MappingGraph + sql-formatter) on idle as soon as
  // the app mounts — *before* the user has even picked a file. By the time
  // they pick one and click into a mapping, both chunks are already in the
  // browser's memory cache, so first-paint of the graph is instant.
  useEffect(() => {
    const warm = () => {
      import('./MappingGraph')
      import('sql-formatter')
    }
    const w = window as any
    if (typeof w.requestIdleCallback === 'function') {
      const h = w.requestIdleCallback(warm, { timeout: 2000 })
      return () => w.cancelIdleCallback?.(h)
    }
    const t = setTimeout(warm, 200)
    return () => clearTimeout(t)
  }, [])

  const onFile = useCallback(async (file: File) => {
    const text = await file.text()
    await loadText(text, file.name)
  }, [loadText])

  const loadSample = useCallback(async () => {
    const r = await fetch('/sample.xml')
    const text = await r.text()
    await loadText(text, 'sample.xml')
  }, [loadText])

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) onFile(file)
  }, [onFile])

  // Keep content panel's selection addressable from URL fragment (optional nicety).
  useEffect(() => {
    if (!selected) return
    const parts = [selected.kind, selected.folder, (selected as any).name ?? '']
    history.replaceState(null, '', `#${parts.filter(Boolean).join('/')}`)
  }, [selected])

  const folderStats = useMemo(() => {
    if (!model) return null
    let sources = 0, targets = 0, xf = 0, mappings = 0, shortcuts = 0
    for (const r of model.repositories) {
      for (const f of r.folders) {
        sources += f.sources.length
        targets += f.targets.length
        xf += f.transformations.length + f.mappings.reduce((a, m) => a + m.transformations.length, 0)
        mappings += f.mappings.length
        shortcuts += f.shortcuts.length
      }
    }
    return { sources, targets, xf, mappings, shortcuts }
  }, [model])

  return (
    <div className="app">
      <div className="topbar">
        <div className="title">
          Powermart <span className="dim">viewer</span>
        </div>
        {model && (
          <>
            <div className="meta">
              {loadedName} &middot; {humanBytes(model.sourceSize)} &middot;{' '}
              {model.repositories.length} repo
              {model.repositories.length === 1 ? '' : 's'}
              {folderStats && (
                <>
                  {' '}&middot; {folderStats.sources} src, {folderStats.targets} tgt,{' '}
                  {folderStats.xf} xf, {folderStats.mappings} map,{' '}
                  {folderStats.shortcuts} sc
                </>
              )}
            </div>
          </>
        )}
        <div className="spacer" />
        {model && (
          <>
            <label>
              <input type="file" accept=".xml" style={{ display: 'none' }}
                     onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
              <span className="" style={{ display: 'inline-block' }}>
                <button onClick={(e) => (e.currentTarget.parentElement!.previousSibling as HTMLInputElement).click()}>
                  Open XML…
                </button>
              </span>
            </label>
            <button onClick={loadSample}>Reload sample</button>
          </>
        )}
      </div>

      {!model ? (
        <div
          className={`drop-zone ${dragging ? 'dragging' : ''}`}
          onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
        >
          <div className="card">
            <h1>Drop a Powermart XML here</h1>
            <div>Or load the bundled <code>sample.xml</code>.</div>
            <div className="actions">
              <label>
                <input type="file" accept=".xml"
                       onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
                <button onClick={(e) => (e.currentTarget.previousSibling as HTMLInputElement).click()}>
                  Choose file…
                </button>
              </label>
              <button onClick={loadSample}>Load bundled sample</button>
            </div>
            {progress && (
              <div>
                <div style={{ marginTop: 18 }}>
                  {progress.phase === 'parsing' && 'Parsing XML…'}
                  {progress.phase === 'building' && 'Building model…'}
                  {progress.phase === 'done' && 'Done.'}
                </div>
                <div className="progress">
                  <div style={{ width: `${Math.min(100, (progress.bytesRead / Math.max(progress.totalBytes, 1)) * 100)}%` }} />
                </div>
              </div>
            )}
            {error && (
              <div style={{ color: 'var(--danger)', marginTop: 18 }}>
                Parse error: {error}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div
          className="workspace"
          style={{ gridTemplateColumns: `${sidebarWidth}px 5px 1fr` }}
        >
          <aside className="sidebar">
            <TreeBrowser
              model={model}
              selected={selected}
              onSelect={setSelected}
            />
          </aside>
          <div
            className="resizer"
            role="separator"
            aria-orientation="vertical"
            title="Drag to resize · double-click to reset"
            onMouseDown={onResizeStart}
            onDoubleClick={() => {
              setSidebarWidth(SIDEBAR_DEFAULT)
              localStorage.setItem(SIDEBAR_KEY, String(SIDEBAR_DEFAULT))
            }}
          />
          <main className="content">
            <Detail model={model} rawTree={model.rawTree} selected={selected}
                    onSelect={setSelected} />
          </main>
        </div>
      )}
    </div>
  )
}
