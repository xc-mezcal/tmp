import { useCallback, useDeferredValue, useMemo, useState } from 'react'
import type { PowermartModel, SelectedObject } from './ir'

type Props = {
  model: PowermartModel
  selected: SelectedObject | null
  onSelect: (sel: SelectedObject) => void
}

type NodeId = string

const matches = (needle: string, hay: string) =>
  !needle || hay.toLowerCase().includes(needle.toLowerCase())

export function TreeBrowser({ model, selected, onSelect }: Props) {
  const [q, setQ] = useState('')
  // Filtering all nodes on every keystroke is the dominant tree-rerender
  // cost on big files. Defer the filter input so the textbox stays snappy
  // and the list catches up when React is idle.
  const deferredQ = useDeferredValue(q)
  const [open, setOpen] = useState<Set<NodeId>>(() => {
    // By default expand first repo + folders + object groups.
    const ids = new Set<NodeId>()
    for (const r of model.repositories) {
      ids.add(`repo:${r.name}`)
      for (const f of r.folders) {
        ids.add(`folder:${r.name}:${f.name}`)
        ids.add(`grp:${r.name}:${f.name}:sources`)
        ids.add(`grp:${r.name}:${f.name}:targets`)
        ids.add(`grp:${r.name}:${f.name}:transformations`)
        ids.add(`grp:${r.name}:${f.name}:mappings`)
        ids.add(`grp:${r.name}:${f.name}:shortcuts`)
        ids.add(`grp:${r.name}:${f.name}:workflows`)
      }
    }
    return ids
  })

  const toggle = useCallback((id: NodeId) => {
    setOpen((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      return next
    })
  }, [])

  const isSelected = useMemo(() => (kind: SelectedObject['kind'], folder: string, name: string) =>
    !!selected && selected.kind === kind && (selected as any).folder === folder && (selected as any).name === name,
    [selected])

  const isInstanceSelected = (folder: string, mapping: string, name: string) =>
    !!selected && selected.kind === 'instance' && selected.folder === folder &&
    (selected as Extract<SelectedObject, { kind: 'instance' }>).mapping === mapping &&
    selected.name === name

  const instIconClass = (type: string) =>
    type === 'SOURCE' ? 'src' : type === 'TARGET' ? 'tgt' : 'xform'
  const instIconChar = (type: string) =>
    type === 'SOURCE' ? 'S' : type === 'TARGET' ? 'T' : 'X'

  const rendered = useMemo(() => {
    const q = deferredQ
    const out: JSX.Element[] = []
    for (const repo of model.repositories) {
      const repoId = `repo:${repo.name}`
      const repoOpen = open.has(repoId)
      out.push(
        <div key={repoId} className="node" style={{ paddingLeft: 6 }} onClick={() => toggle(repoId)}>
          <span className="chev">{repoOpen ? '▾' : '▸'}</span>
          <span className="icon folder">R</span>
          <span className="label"><b>{repo.name}</b> <span className="subtle" style={{ color: 'var(--text-dim)' }}>/ {repo.databaseType}</span></span>
        </div>
      )
      if (!repoOpen) continue
      for (const folder of repo.folders) {
        const fid = `folder:${repo.name}:${folder.name}`
        const fOpen = open.has(fid)
        out.push(
          <div key={fid} className="node" style={{ paddingLeft: 18 }} onClick={() => toggle(fid)}>
            <span className="chev">{fOpen ? '▾' : '▸'}</span>
            <span className="icon folder">F</span>
            <span className="label">{folder.name}</span>
            <span className="badge">
              {folder.sources.length + folder.targets.length +
                folder.transformations.length + folder.shortcuts.length +
                folder.mappings.length + folder.workflows.length}
            </span>
          </div>
        )
        if (!fOpen) continue

        const groups: Array<{
          key: string; label: string; icon: string; iconClass: string;
          items: Array<{ name: string; kind: SelectedObject['kind']; subtitle?: string }>;
        }> = [
          { key: 'sources', label: 'Sources', icon: 'S', iconClass: 'src',
            items: folder.sources.map((s) => ({ name: s.name, kind: 'source', subtitle: s.databaseType })) },
          { key: 'targets', label: 'Targets', icon: 'T', iconClass: 'tgt',
            items: folder.targets.map((t) => ({ name: t.name, kind: 'target', subtitle: t.databaseType })) },
          { key: 'transformations', label: 'Transformations (reusable)', icon: 'X', iconClass: 'xform',
            items: folder.transformations.map((t) => ({ name: t.name, kind: 'transformation', subtitle: t.type })) },
          { key: 'mappings', label: 'Mappings', icon: 'M', iconClass: 'mapping',
            items: folder.mappings.map((m) => ({ name: m.name, kind: 'mapping', subtitle: `${m.instances.length} inst, ${m.connectors.length} conn` })) },
          { key: 'shortcuts', label: 'Shortcuts', icon: '→', iconClass: 'shortcut',
            items: folder.shortcuts.map((s) => ({ name: s.name, kind: 'shortcut', subtitle: `${s.objectType} → ${s.refFolder}/${s.refObject}` })) },
          { key: 'workflows', label: 'Workflows', icon: 'W', iconClass: 'workflow',
            items: folder.workflows.map((w) => ({ name: w.name, kind: 'workflow', subtitle: `${w.sessions.length} sess` })) },
        ]

        for (const g of groups) {
          const filtered = g.items.filter((i) => matches(q, i.name) || matches(q, i.subtitle ?? ''))
          if (q && filtered.length === 0) continue
          const gid = `grp:${repo.name}:${folder.name}:${g.key}`
          const gOpen = open.has(gid) || !!q
          out.push(
            <div key={gid} className="node" style={{ paddingLeft: 30 }} onClick={() => toggle(gid)}>
              <span className="chev">{gOpen ? '▾' : '▸'}</span>
              <span className={`icon ${g.iconClass}`}>{g.icon}</span>
              <span className="label">{g.label}</span>
              <span className="badge">{filtered.length}</span>
            </div>
          )
          if (!gOpen) continue
          for (const it of filtered) {
            const sel = isSelected(it.kind, folder.name, it.name)
            const isMapping = it.kind === 'mapping'
            const mapId = isMapping ? `map:${repo.name}:${folder.name}:${it.name}` : ''
            // A mapping node is both selectable (show mapping detail) AND
            // expandable (list its instances). Chevron toggles; the rest of
            // the row selects.
            const mapOpen = isMapping && (open.has(mapId) || !!q)
            out.push(
              <div
                key={`${gid}:${it.name}`}
                className={`node ${sel ? 'selected' : ''}`}
                style={{ paddingLeft: isMapping ? 42 : 48 }}
                title={it.subtitle}
                onClick={() => onSelect({ kind: it.kind, folder: folder.name, name: it.name } as SelectedObject)}
              >
                {isMapping && (
                  <span
                    className="chev"
                    onClick={(e) => { e.stopPropagation(); toggle(mapId) }}
                  >{mapOpen ? '▾' : '▸'}</span>
                )}
                <span className={`icon ${g.iconClass}`}>{g.icon}</span>
                <span className="label">{it.name}</span>
              </div>
            )
            if (isMapping && mapOpen) {
              const mapping = folder.mappings.find((m) => m.name === it.name)
              if (mapping) {
                const instances = [...mapping.instances].filter((i) =>
                  matches(q, i.name) || matches(q, i.transformationType ?? '')
                ).sort((a, b) => a.name.localeCompare(b.name))
                for (const inst of instances) {
                  const iSel = isInstanceSelected(folder.name, mapping.name, inst.name)
                  const subtitle = inst.transformationType || inst.type
                  out.push(
                    <div
                      key={`${mapId}:${inst.name}`}
                      className={`node ${iSel ? 'selected' : ''}`}
                      style={{ paddingLeft: 66 }}
                      title={`${inst.type}${inst.transformationType ? ' / ' + inst.transformationType : ''}`}
                      onClick={() => onSelect({
                        kind: 'instance', folder: folder.name,
                        mapping: mapping.name, name: inst.name,
                      })}
                    >
                      <span className={`icon ${instIconClass(inst.type)}`}>
                        {instIconChar(inst.type)}
                      </span>
                      <span className="label">{inst.name}</span>
                      <span className="subtle" style={{ marginLeft: 6, fontSize: 10 }}>
                        {subtitle}
                      </span>
                    </div>
                  )
                }
              }
            }
          }
        }
      }
    }
    return out
  }, [model, open, deferredQ, selected, toggle, onSelect])

  return (
    <div className="tree">
      <div className="search">
        <input type="search" placeholder="Search objects…" value={q}
               onChange={(e) => setQ(e.target.value)} />
      </div>
      {rendered}
    </div>
  )
}
