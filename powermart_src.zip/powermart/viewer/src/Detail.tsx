import { Fragment, Suspense, lazy, useMemo, useState, type ReactNode } from 'react'
import type {
  Attrs, Connector, Field, Folder, Mapping, PowermartModel, RawNode, SelectedObject,
  Source, SourceField, Target, TargetField, Transformation, Workflow, Shortcut,
} from './ir'
import { findNamedInFolder } from './parser'
import { resolveInstance, resolveShortcut, type Resolved } from './resolve'
import { routerGroupCondition, isDefaultRouterGroup } from './sql/catalog'
import { useFormattedSql } from './sql/format'
import { UnifiedLineageView, buildLineageRows } from './Lineage'

// Lazy-load the mapping graph. @xyflow/react + elkjs together are ~1.3 MB
// and only needed once a mapping is actually opened.
const MappingGraph = lazy(() =>
  import('./MappingGraph').then((m) => ({ default: m.MappingGraph })),
)

type Props = {
  model: PowermartModel
  rawTree: RawNode
  selected: SelectedObject | null
  onSelect: (s: SelectedObject) => void
}

export function Detail({ model, rawTree, selected, onSelect }: Props) {
  if (!selected) {
    return (
      <div className="detail">
        <div className="subtle">Select an object from the left tree.</div>
      </div>
    )
  }
  const folder = findFolder(model, selected.folder)
  if (!folder) return <div className="detail"><div className="subtle">Folder not found.</div></div>

  switch (selected.kind) {
    case 'source': {
      const obj = folder.sources.find((s) => s.name === selected.name)
      return obj ? <SourceDetail folder={folder} obj={obj} rawTree={rawTree} />
                 : <Missing what="source" name={selected.name} />
    }
    case 'target': {
      const obj = folder.targets.find((t) => t.name === selected.name)
      return obj ? <TargetDetail folder={folder} obj={obj} rawTree={rawTree} />
                 : <Missing what="target" name={selected.name} />
    }
    case 'transformation': {
      const obj = folder.transformations.find((t) => t.name === selected.name)
      return obj ? <TransformationDetail folder={folder} obj={obj} rawTree={rawTree} reusable />
                 : <Missing what="transformation" name={selected.name} />
    }
    case 'shortcut': {
      const obj = folder.shortcuts.find((s) => s.name === selected.name)
      return obj ? <ShortcutDetail model={model} folder={folder} obj={obj} rawTree={rawTree}
                                   onSelect={onSelect} />
                 : <Missing what="shortcut" name={selected.name} />
    }
    case 'mapping': {
      const obj = folder.mappings.find((m) => m.name === selected.name)
      return obj ? <MappingDetail model={model} folder={folder} mapping={obj} rawTree={rawTree}
                                  onSelectInstance={(iname) => onSelect({
                                    kind: 'instance', folder: folder.name,
                                    mapping: obj.name, name: iname,
                                  })} />
                 : <Missing what="mapping" name={selected.name} />
    }
    case 'workflow': {
      const obj = folder.workflows.find((w) => w.name === selected.name)
      return obj ? <WorkflowDetail folder={folder} obj={obj} rawTree={rawTree} />
                 : <Missing what="workflow" name={selected.name} />
    }
    case 'instance': {
      const mapping = folder.mappings.find((m) => m.name === selected.mapping)
      if (!mapping) return <Missing what="mapping" name={selected.mapping} />
      const inst = mapping.instances.find((i) => i.name === selected.name)
      if (!inst) return <Missing what="instance" name={selected.name} />
      return <InstanceDetail model={model} folder={folder} mapping={mapping}
                             instanceName={inst.name} rawTree={rawTree} onSelect={onSelect} />
    }
  }
}

function Missing({ what, name }: { what: string; name: string }) {
  return <div className="detail"><div className="subtle">Could not find {what} <code>{name}</code>.</div></div>
}

function findFolder(model: PowermartModel, name: string): Folder | undefined {
  for (const r of model.repositories) for (const f of r.folders) if (f.name === name) return f
  return undefined
}

// --------- Source ------------------------------------------------------

function SourceDetail({ folder, obj, rawTree }: { folder: Folder; obj: Source; rawTree: RawNode }) {
  const [tab, setTab] = useState<'fields' | 'attrs' | 'xml'>('fields')
  return (
    <div className="detail">
      <h2>
        <span className="icon-dot src" /> {obj.name}
        <span className="pill">SOURCE</span>
        <span className="pill accent">{obj.databaseType}</span>
        {obj.isFlatFile && <span className="pill">Flat File</span>}
      </h2>
      <div className="subtle">
        Folder {folder.name} · DBD <code>{obj.dbdName}</code>
        {obj.ownerName && <> · Owner <code>{obj.ownerName}</code></>}
        {obj.description && <> · {obj.description}</>}
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[
        ['fields', `Fields (${obj.fields.length})`],
        ['attrs', `Attributes (${obj.tableAttributes.length})`],
        ['xml', 'Raw XML'],
      ]} />
      {tab === 'fields' && <SourceFieldTable fields={obj.fields} />}
      {tab === 'attrs' && <TableAttrs items={obj.tableAttributes} />}
      {tab === 'xml' && <RawXmlForName rawTree={rawTree} folder={folder.name} tag="SOURCE" name={obj.name} />}
    </div>
  )
}

const SOURCE_FIELD_ACCESSORS: Accessors<SourceField> = {
  num: (f) => Number(f.fieldNumber) || 0,
  name: (f) => f.name,
  type: (f) => f.dataType,
  prec: (f) => Number(f.precision) || 0,
  scale: (f) => Number(f.scale) || 0,
  key: (f) => f.keyType || '',
  nullable: (f) => f.nullable,
  business: (f) => f.attrs.BUSINESSNAME || '',
}

function SourceFieldTable({ fields }: { fields: SourceField[] }) {
  const [expanded, toggleExpanded] = useExpansion()
  const { sorted, toggle, chev } = useSortedRows(fields, SOURCE_FIELD_ACCESSORS)
  return (
    <table className="grid">
      <thead>
        <tr>
          <th className="col-expand"></th>
          <SortableTh label="#" sortKey="num" toggle={toggle} chev={chev} />
          <SortableTh label="Name" sortKey="name" toggle={toggle} chev={chev} />
          <SortableTh label="Type" sortKey="type" toggle={toggle} chev={chev} />
          <SortableTh label="Prec" sortKey="prec" toggle={toggle} chev={chev} />
          <SortableTh label="Scale" sortKey="scale" toggle={toggle} chev={chev} />
          <SortableTh label="Key" sortKey="key" toggle={toggle} chev={chev} />
          <SortableTh label="Null" sortKey="nullable" toggle={toggle} chev={chev} />
          <SortableTh label="Business Name" sortKey="business" toggle={toggle} chev={chev} />
        </tr>
      </thead>
      <tbody>
        {sorted.map((f) => (
          <Fragment key={f.name}>
            <tr>
              <td className="col-expand"><ExpandChev open={expanded.has(f.name)} onClick={() => toggleExpanded(f.name)} /></td>
              <td className="dim">{f.fieldNumber}</td>
              <td>{f.name}</td>
              <td className="mono">{f.dataType}</td>
              <td>{f.precision}</td>
              <td>{f.scale}</td>
              <td>{f.keyType || ''}</td>
              <td className={f.nullable === 'NOTNULL' ? '' : 'dim'}>{f.nullable}</td>
              <td className="dim">{f.attrs.BUSINESSNAME || ''}</td>
            </tr>
            {expanded.has(f.name) && <AllAttrsRow attrs={f.attrs} colSpan={8} />}
          </Fragment>
        ))}
      </tbody>
    </table>
  )
}

// --------- Target ------------------------------------------------------

function TargetDetail({ folder, obj, rawTree }: { folder: Folder; obj: Target; rawTree: RawNode }) {
  const [tab, setTab] = useState<'fields' | 'attrs' | 'xml'>('fields')
  return (
    <div className="detail">
      <h2>
        <span className="icon-dot tgt" /> {obj.name}
        <span className="pill">TARGET</span>
        <span className="pill accent">{obj.databaseType}</span>
      </h2>
      <div className="subtle">
        Folder {folder.name}
        {obj.description && <> · {obj.description}</>}
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[
        ['fields', `Fields (${obj.fields.length})`],
        ['attrs', `Attributes (${obj.tableAttributes.length})`],
        ['xml', 'Raw XML'],
      ]} />
      {tab === 'fields' && <TargetFieldTable fields={obj.fields} />}
      {tab === 'attrs' && <TableAttrs items={obj.tableAttributes} />}
      {tab === 'xml' && <RawXmlForName rawTree={rawTree} folder={folder.name} tag="TARGET" name={obj.name} />}
    </div>
  )
}

const TARGET_FIELD_ACCESSORS: Accessors<TargetField> = {
  num: (f) => Number(f.fieldNumber) || 0,
  name: (f) => f.name,
  type: (f) => f.dataType,
  prec: (f) => Number(f.precision) || 0,
  scale: (f) => Number(f.scale) || 0,
  key: (f) => f.keyType || '',
  nullable: (f) => f.nullable,
  business: (f) => f.attrs.BUSINESSNAME || '',
}

function TargetFieldTable({ fields }: { fields: TargetField[] }) {
  const [expanded, toggleExpanded] = useExpansion()
  const { sorted, toggle, chev } = useSortedRows(fields, TARGET_FIELD_ACCESSORS)
  return (
    <table className="grid">
      <thead>
        <tr>
          <th className="col-expand"></th>
          <SortableTh label="#" sortKey="num" toggle={toggle} chev={chev} />
          <SortableTh label="Name" sortKey="name" toggle={toggle} chev={chev} />
          <SortableTh label="Type" sortKey="type" toggle={toggle} chev={chev} />
          <SortableTh label="Prec" sortKey="prec" toggle={toggle} chev={chev} />
          <SortableTh label="Scale" sortKey="scale" toggle={toggle} chev={chev} />
          <SortableTh label="Key" sortKey="key" toggle={toggle} chev={chev} />
          <SortableTh label="Null" sortKey="nullable" toggle={toggle} chev={chev} />
          <SortableTh label="Business Name" sortKey="business" toggle={toggle} chev={chev} />
        </tr>
      </thead>
      <tbody>
        {sorted.map((f) => (
          <Fragment key={f.name}>
            <tr>
              <td className="col-expand"><ExpandChev open={expanded.has(f.name)} onClick={() => toggleExpanded(f.name)} /></td>
              <td className="dim">{f.fieldNumber}</td>
              <td>{f.name}</td>
              <td className="mono">{f.dataType}</td>
              <td>{f.precision}</td>
              <td>{f.scale}</td>
              <td>{f.keyType || ''}</td>
              <td className={f.nullable === 'NOTNULL' ? '' : 'dim'}>{f.nullable}</td>
              <td className="dim">{f.attrs.BUSINESSNAME || ''}</td>
            </tr>
            {expanded.has(f.name) && <AllAttrsRow attrs={f.attrs} colSpan={8} />}
          </Fragment>
        ))}
      </tbody>
    </table>
  )
}

// --------- Transformation (type-aware) --------------------------------

// TABLEATTRIBUTEs that carry a hand-written SQL override. When one of these
// is non-empty the "Transformation" tab is flagged so the override catches
// the eye immediately.
const SQL_OVERRIDE_ATTRS = ['Sql Query', 'Lookup Sql Override']

function hasSqlOverride(obj: Transformation): boolean {
  return obj.tableAttributes.some(
    (a) => SQL_OVERRIDE_ATTRS.includes(a.name) && a.value.trim() !== '',
  )
}

export function TransformationDetail({
  folder, obj, rawTree, reusable, inMapping,
}: {
  folder: Folder; obj: Transformation; rawTree: RawNode;
  reusable: boolean; inMapping?: Mapping
}) {
  // Default tab is always "Transformation" — it surfaces any SQL override
  // (Sql Query, Lookup Sql Override, …) as the top-priority view.
  const [tab, setTab] = useState<'sql' | 'fields' | 'attrs' | 'groups' | 'init' | 'xml'>('sql')
  const sqlTabLabel = hasSqlOverride(obj) ? 'Transformation · SQL override' : 'Transformation'
  return (
    <div className="detail">
      <h2>
        <span className="icon-dot xform" /> {obj.name}
        <span className="pill accent">{obj.type || '(unknown type)'}</span>
        {reusable && <span className="pill ok">REUSABLE</span>}
        {inMapping && <span className="pill">in {inMapping.name}</span>}
      </h2>
      <div className="subtle">
        Folder {folder.name}
        {obj.description && <> · {obj.description}</>}
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[
        ['sql', sqlTabLabel],
        ['fields', `Fields (${obj.fields.length})`],
        ['attrs', `Attributes (${obj.tableAttributes.length})`],
        ['groups', `Groups (${obj.groups.length})`],
        ['init', `Init Props (${obj.initProps.length})`],
        ['xml', 'Raw XML'],
      ].filter((x) => x[0] !== 'groups' || obj.groups.length)
       .filter((x) => x[0] !== 'init' || obj.initProps.length) as any} />
      {tab === 'sql' && <TransformationLogicPane obj={obj} />}
      {tab === 'fields' && <TransformFieldTable fields={obj.fields} />}
      {tab === 'attrs' && <TableAttrs items={obj.tableAttributes} />}
      {tab === 'groups' && <GroupsTable obj={obj} />}
      {tab === 'init' && (
        <div className="section">
          {obj.initProps.map((p, idx) => (
            <div key={idx} className="section">
              <h3>{p.name}</h3>
              <pre className="code">{p.value || <span className="subtle">(empty)</span>}</pre>
            </div>
          ))}
        </div>
      )}
      {tab === 'xml' && <RawXmlForName rawTree={rawTree} folder={folder.name} tag="TRANSFORMATION" name={obj.name} />}
    </div>
  )
}

/** Type-specific summary panel. Optimized for what a future SQL generator
 *  will read: expressions, filters, joins, aggregates, group-bys, etc. */
function TransformationLogicPane({ obj }: { obj: Transformation }) {
  const tattr = (name: string) => obj.tableAttributes.find((a) => a.name === name)?.value ?? ''
  const outputs = obj.fields.filter((f) => /OUTPUT/.test(f.portType) && !/INPUT/.test(f.portType))
  const groupBys = obj.fields.filter((f) => f.isGroupBy)
  const sortKeys = obj.fields.filter((f) => f.sortKey)
  const t = obj.type

  return (
    <div className="section">
      {t === 'Source Qualifier' && (
        <>
          <KV title="SQL Query" value={tattr('Sql Query')} asSql />
          <KV title="User Defined Join" value={tattr('User Defined Join')} mono />
          <KV title="Source Filter" value={tattr('Source Filter')} mono />
          <KV title="Pre SQL" value={tattr('Pre SQL')} asSql />
          <KV title="Post SQL" value={tattr('Post SQL')} asSql />
          <KV title="Select Distinct" value={tattr('Select Distinct')} />
          <KV title="Number Of Sorted Ports" value={tattr('Number Of Sorted Ports')} />
        </>
      )}

      {t === 'Filter' && (
        <KV title="Filter Condition" value={tattr('Filter Condition')} mono multiline />
      )}

      {t === 'Expression' && (
        <>
          <h3>Output expressions</h3>
          <table className="grid">
            <thead><tr><th>Field</th><th>Type</th><th>Expression</th></tr></thead>
            <tbody>
              {outputs.map((f) => (
                <tr key={f.name}>
                  <td>{f.name}</td>
                  <td className="mono">{f.dataType}({f.precision}{f.scale && f.scale !== '0' ? `,${f.scale}` : ''})</td>
                  <td className="mono">{f.expression || <span className="subtle">(passthrough)</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      {t === 'Aggregator' && (
        <>
          <KV title="Group By" value={groupBys.map((f) => f.name).join(', ') || '(none)'} mono />
          <KV title="Sorted Input" value={tattr('Sorted Input')} />
          <KV title="Transformation Scope" value={tattr('Transformation Scope')} />
          <h3>Aggregated outputs</h3>
          <table className="grid">
            <thead><tr><th>Field</th><th>Type</th><th>Expression</th></tr></thead>
            <tbody>
              {outputs.map((f) => (
                <tr key={f.name}>
                  <td>{f.name}</td>
                  <td className="mono">{f.dataType}({f.precision}{f.scale && f.scale !== '0' ? `,${f.scale}` : ''})</td>
                  <td className="mono">{f.expression || <span className="subtle">(passthrough)</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      {t === 'Joiner' && (
        <>
          <KV title="Join Type" value={tattr('Join Type')} />
          <KV title="Join Condition" value={tattr('Join Condition')} mono multiline />
          <KV title="Sorted Input" value={tattr('Sorted Input')} />
          <KV title="Case Sensitive" value={tattr('Case Sensitive String Comparison')} />
          <GroupsTable obj={obj} />
        </>
      )}

      {t === 'Lookup Procedure' && (
        <>
          <KV title="Lookup table" value={tattr('Lookup table name')} mono />
          <KV title="Lookup condition" value={tattr('Lookup condition')} mono />
          <KV title="Lookup SQL override" value={tattr('Lookup Sql Override')} asSql />
          <KV title="Caching enabled" value={tattr('Lookup caching enabled')} />
          <KV title="Policy on multiple match" value={tattr('Lookup policy on multiple match')} />
          <KV title="Connection" value={tattr('Connection Information')} mono />
        </>
      )}

      {t === 'Router' && (
        <>
          <h3>Output groups</h3>
          <table className="grid">
            <thead><tr><th>Group</th><th>Order</th><th>Filter condition</th></tr></thead>
            <tbody>
              {obj.groups.filter((g) => g.type === 'OUTPUT')
                .sort((a, b) => a.order - b.order)
                .map((g) => {
                  const cond = routerGroupCondition(obj, g)
                  const isDefault = isDefaultRouterGroup(g.name)
                  return (
                    <tr key={g.name}>
                      <td>{g.name}</td>
                      <td className="dim">{g.order}</td>
                      <td className="mono">
                        {cond
                          ? cond
                          : <span className="subtle">
                              {isDefault
                                ? '(default — receives rows matching no other group)'
                                : '(no condition)'}
                            </span>}
                      </td>
                    </tr>
                  )
                })}
            </tbody>
          </table>
        </>
      )}

      {t === 'Update Strategy' && (
        <KV title="Update Strategy Expression" value={tattr('Update Strategy Expression')} mono multiline />
      )}

      {t === 'Transaction Control' && (
        <KV title="Transaction Control Condition" value={tattr('Transaction Control Condition')} mono multiline />
      )}

      {t === 'Sequence' && (
        <>
          <KV title="Start Value" value={tattr('Start Value')} />
          <KV title="Increment By" value={tattr('Increment By')} />
          <KV title="End Value" value={tattr('End Value')} />
          <KV title="Cycle" value={tattr('Cycle')} />
          <KV title="Number of Cached Values" value={tattr('Number of Cached Values')} />
        </>
      )}

      {t === 'Rank' && (
        <>
          <KV title="Top/Bottom" value={tattr('Top/Bottom')} />
          <KV title="Number Of Ranks" value={tattr('Number Of Ranks')} />
          <KV title="Group By" value={groupBys.map((f) => f.name).join(', ') || '(none)'} mono />
          <KV title="Rank Port" value={obj.fields.find((f) => f.rankIndex)?.name || '(none)'} mono />
        </>
      )}

      {t === 'Sorter' && (
        <>
          <KV title="Sort keys" value={sortKeys.map((f) => `${f.name} ${f.sortDirection ?? ''}`).join(', ')} mono />
          <KV title="Distinct" value={tattr('Distinct')} />
          <KV title="Case Sensitive" value={tattr('Case Sensitive')} />
        </>
      )}

      {t === 'Stored Procedure' && (
        <>
          <KV title="Call Text" value={tattr('Call Text')} mono multiline />
          <KV title="Stored Procedure Type" value={tattr('Stored Procedure Type')} />
          <KV title="Connection" value={tattr('Connection Information')} />
        </>
      )}

      {t === 'SQL Transformation' && (
        <>
          <KV title="SQL Mode" value={tattr('SQL Mode')} />
          <KV title="Database Type" value={tattr('Database Type')} />
          <KV title="Connection Type" value={tattr('Connection Type')} />
          <KV title="Script / Query" value={tattr('Script')} asSql />
        </>
      )}

      {t === 'Java Transformation' && (
        <>
          <KV title="Class" value={obj.initProps.find((p) => p.name === 'ClassName')?.value ?? ''} mono />
          <KV title="Runtime Location" value={obj.initProps.find((p) => p.name === 'Runtime Location')?.value ?? ''} mono />
          <h3>On Input Row</h3>
          <pre className="code">{obj.initProps.find((p) => p.name === 'On Input Row')?.value ?? ''}</pre>
          <h3>On End Of Data</h3>
          <pre className="code">{obj.initProps.find((p) => p.name === 'On End Of Data')?.value ?? ''}</pre>
          <h3>Imports</h3>
          <pre className="code">{obj.initProps.find((p) => p.name === 'Import Packages')?.value ?? ''}</pre>
        </>
      )}

      {t === 'HTTP Transformation' && (
        <>
          <KV title="Base URL" value={tattr('Base URL')} mono />
          <KV title="Method" value={tattr('HTTP Method')} />
          <KV title="Authentication" value={tattr('Authentication Type')} />
        </>
      )}

      {t === 'Web Services Consumer' && (
        <>
          <KV title="WSDL URL" value={tattr('WSDL URL')} mono />
          <KV title="Operation" value={tattr('Operation')} />
          <KV title="Endpoint" value={tattr('End Point URL')} mono />
        </>
      )}

      {t === 'External Procedure' && (
        <>
          <KV title="Module / DLL" value={tattr('Module/Program Name')} mono />
          <KV title="Procedure" value={tattr('Procedure Name')} mono />
          <KV title="Runtime Location" value={tattr('Runtime Location')} />
        </>
      )}

      {t === 'Normalizer' && (
        <>
          <KV title="Reset" value={tattr('Reset')} />
          <KV title="Restart" value={tattr('Restart')} />
        </>
      )}

      {(t === 'Custom Transformation' || t === 'Unstructured Data Transformation') && (
        <>
          <KV title="Template Name" value={obj.attrs.TEMPLATENAME ?? ''} />
          <KV title="Service Name" value={tattr('Service Name')} />
        </>
      )}
    </div>
  )
}

function KV({ title, value, mono, multiline, asSql }: {
  title: string; value: string; mono?: boolean; multiline?: boolean; asSql?: boolean
}) {
  if (!value) return (
    <div className="kv"><div className="k">{title}</div><div className="v"><span className="subtle">(empty)</span></div></div>
  )
  if (asSql) {
    return <Section title={title}><SqlPre value={value} /></Section>
  }
  if (multiline) {
    return <Section title={title}><pre className="code">{value}</pre></Section>
  }
  return (
    <div className="kv">
      <div className="k">{title}</div>
      <div className={`v ${mono ? 'mono' : ''}`}>{value}</div>
    </div>
  )
}

function SqlPre({ value }: { value: string }) {
  const formatted = useFormattedSql(value)
  return <pre className="code sql-block">{formatted}</pre>
}

const TRANSFORM_FIELD_ACCESSORS: Accessors<Field> = {
  name: (f) => f.name,
  port: (f) => f.portType,
  group: (f) => f.group ?? '',
  type: (f) => f.dataType,
  prec: (f) => Number(f.precision) || 0,
  scale: (f) => Number(f.scale) || 0,
  expr: (f) => f.expression ?? '',
  def: (f) => f.defaultValue ?? '',
}

function transformFieldKey(f: Field, i: number): string {
  return `${f.name}:${f.group ?? ''}:${f.portType}:${i}`
}

function TransformFieldTable({ fields }: { fields: Field[] }) {
  const [expanded, toggleExpanded] = useExpansion()
  // Keep a stable row-key by tagging each field with its original index so
  // expansion state survives sorting.
  const indexed = useMemo(
    () => fields.map((f, i) => ({ field: f, key: transformFieldKey(f, i) })),
    [fields],
  )
  const accessors = useMemo<Accessors<{ field: Field; key: string }>>(() => {
    const a: Accessors<{ field: Field; key: string }> = {}
    for (const k of Object.keys(TRANSFORM_FIELD_ACCESSORS)) {
      a[k] = (r) => TRANSFORM_FIELD_ACCESSORS[k](r.field)
    }
    return a
  }, [])
  const { sorted, toggle, chev } = useSortedRows(indexed, accessors)
  return (
    <table className="grid">
      <thead>
        <tr>
          <th className="col-expand"></th>
          <SortableTh label="Name" sortKey="name" toggle={toggle} chev={chev} />
          <SortableTh label="Port" sortKey="port" toggle={toggle} chev={chev} />
          <SortableTh label="Group" sortKey="group" toggle={toggle} chev={chev} />
          <SortableTh label="Type" sortKey="type" toggle={toggle} chev={chev} />
          <SortableTh label="Prec" sortKey="prec" toggle={toggle} chev={chev} />
          <SortableTh label="Scale" sortKey="scale" toggle={toggle} chev={chev} />
          <SortableTh label="Expression" sortKey="expr" toggle={toggle} chev={chev} />
          <SortableTh label="Default" sortKey="def" toggle={toggle} chev={chev} />
          <th>Flags</th>
        </tr>
      </thead>
      <tbody>
        {sorted.map(({ field: f, key }) => (
          <Fragment key={key}>
            <tr>
              <td className="col-expand"><ExpandChev open={expanded.has(key)} onClick={() => toggleExpanded(key)} /></td>
              <td>{f.name}</td>
              <td className={`port-${f.portType.replace(/\//g, '\\/')} mono`}>{f.portType}</td>
              <td className="dim">{f.group ?? ''}</td>
              <td className="mono">{f.dataType}</td>
              <td>{f.precision}</td>
              <td>{f.scale}</td>
              <td className="mono">{f.expression}</td>
              <td className="mono dim">{f.defaultValue}</td>
              <td className="dim">
                {[f.isGroupBy && 'GROUP BY',
                  f.sortKey && `SORT ${f.sortDirection ?? ''}`,
                  f.rankIndex && 'RANK',
                  f.expressionType && f.expressionType !== 'GENERAL' && f.expressionType,
                ].filter(Boolean).join(' · ')}
              </td>
            </tr>
            {expanded.has(key) && (
              <AllAttrsRow attrs={f.attrs} colSpan={9}
                extras={[
                  ['Description', f.description],
                  ['Business Name', f.businessName],
                  ['Picture Text', f.pictureText],
                ]} />
            )}
          </Fragment>
        ))}
      </tbody>
    </table>
  )
}

function useExpansion(): [Set<string>, (k: string) => void] {
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set())
  const toggle = (k: string) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(k)) next.delete(k); else next.add(k)
      return next
    })
  }
  return [expanded, toggle]
}

type SortState = { key: string; dir: 'asc' | 'desc' } | null
type Accessors<T> = Record<string, (r: T) => string | number>

function useSortedRows<T>(rows: T[], accessors: Accessors<T>) {
  const [sort, setSort] = useState<SortState>(null)
  const sorted = useMemo(() => {
    if (!sort) return rows
    const get = accessors[sort.key]
    if (!get) return rows
    const arr = [...rows]
    arr.sort((a, b) => {
      const av = get(a), bv = get(b)
      const cmp = typeof av === 'number' && typeof bv === 'number'
        ? av - bv
        : String(av).localeCompare(String(bv), undefined, { numeric: true })
      return sort.dir === 'asc' ? cmp : -cmp
    })
    return arr
  }, [rows, sort, accessors])
  // Three-state cycle per column: asc → desc → unsorted (back to the
  // original/default order). The ⇅ glyph marks the unsorted state.
  const toggle = (key: string) => setSort((s) => {
    if (s?.key !== key) return { key, dir: 'asc' }
    return s.dir === 'asc' ? { key, dir: 'desc' } : null
  })
  const chev = (key: string) =>
    sort?.key === key ? (sort.dir === 'asc' ? ' ▲' : ' ▼') : ' ⇅'
  return { sorted, toggle, chev }
}

function Section({ title, defaultOpen = true, children }: {
  title: ReactNode; defaultOpen?: boolean; children: ReactNode
}) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="section">
      <h3 className="section-head" onClick={() => setOpen(!open)}>
        <span className="row-chev">{open ? '▾' : '▸'}</span>{title}
      </h3>
      {open && children}
    </div>
  )
}

function SortableTh({ label, sortKey, chev, toggle }: {
  label: string; sortKey: string; chev: (k: string) => string; toggle: (k: string) => void
}) {
  return (
    <th className="th-sort" onClick={() => toggle(sortKey)}>{label}{chev(sortKey)}</th>
  )
}

function ExpandChev({ open, onClick }: { open: boolean; onClick: () => void }) {
  return <span className="row-chev" onClick={onClick}>{open ? '▾' : '▸'}</span>
}

function AllAttrsRow({ attrs, colSpan, extras }: {
  attrs: Attrs; colSpan: number; extras?: Array<[string, string]>
}) {
  const entries = Object.entries(attrs)
  return (
    <tr className="expanded-row">
      <td></td>
      <td colSpan={colSpan}>
        <div className="all-attrs">
          {extras?.filter(([, v]) => v).map(([k, v]) => (
            <div key={`x:${k}`} className="attr-pair emph">
              <span className="attr-k">{k}</span>
              <span className="attr-v mono">{v}</span>
            </div>
          ))}
          {entries.map(([k, v]) => (
            <div key={k} className="attr-pair">
              <span className="attr-k">{k}</span>
              <span className="attr-v mono">
                {v === '' ? <span className="subtle">""</span> : v}
              </span>
            </div>
          ))}
        </div>
      </td>
    </tr>
  )
}

function GroupsTable({ obj }: { obj: Transformation }) {
  if (obj.groups.length === 0) return <div className="subtle">No groups.</div>
  return (
    <table className="grid">
      <thead><tr><th>Name</th><th>Type</th><th>Order</th><th>Fields</th></tr></thead>
      <tbody>
        {obj.groups.map((g) => (
          <tr key={`${g.name}:${g.type}`}>
            <td>{g.name}</td>
            <td>{g.type}</td>
            <td>{g.order}</td>
            <td className="mono">
              {obj.fields.filter((f) => f.group === g.name).map((f) => f.name).join(', ')}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

function TableAttrs({ items }: { items: { name: string; value: string }[] }) {
  if (items.length === 0) return <div className="subtle">None.</div>
  return (
    <table className="grid">
      <thead><tr><th style={{ width: '35%' }}>Name</th><th>Value</th></tr></thead>
      <tbody>
        {items.map((a, i) => (
          <tr key={i}><td>{a.name}</td><td className="mono">{a.value}</td></tr>
        ))}
      </tbody>
    </table>
  )
}

// --------- Shortcut ----------------------------------------------------

function ShortcutDetail({
  model, folder, obj, rawTree, onSelect,
}: {
  model?: PowermartModel; folder: Folder; obj: Shortcut; rawTree: RawNode;
  onSelect?: (s: SelectedObject) => void
}) {
  const [tab, setTab] = useState<'info' | 'attrs' | 'xml'>('info')
  const resolved = model ? resolveShortcut(model, obj) : null
  const isBroken = resolved?.kind === 'shortcut-broken'
  const canJump = resolved && resolved.kind !== 'shortcut-broken' && onSelect

  const jump = () => {
    if (!canJump || !onSelect) return
    const kind = resolved.kind === 'transformation' ? 'transformation'
               : resolved.kind === 'source' ? 'source' : 'target'
    onSelect({ kind, folder: resolved.folder.name, name: resolved.obj.name })
  }

  return (
    <div className="detail">
      <h2>
        <span className="icon-dot shortcut" /> {obj.name}
        <span className="pill shortcut">SHORTCUT</span>
        <span className="pill accent">{obj.objectType}</span>
        {isBroken && <span className="pill warn">BROKEN</span>}
      </h2>
      <div className="subtle">
        Folder {folder.name} · {obj.referenceType} reference
      </div>
      <div className="via-shortcut">
        Points to{' '}
        {canJump
          ? <a href="#" onClick={(e) => { e.preventDefault(); jump() }}>
              <code>{obj.refFolder}/{obj.refObject}</code>
            </a>
          : <code>{obj.refFolder}/{obj.refObject}</code>}
        {' '}({obj.objectType})
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[
        ['info', 'Info'],
        ['attrs', 'All attributes'],
        ['xml', 'Raw XML'],
      ]} />
      {tab === 'info' && (
        <div className="section">
          <KV title="Points to folder" value={obj.refFolder} mono />
          <KV title="Points to object" value={obj.refObject} mono />
          <KV title="Target repository" value={obj.refRepository} mono />
          <KV title="Reference type" value={obj.referenceType} />
          <KV title="Object type" value={obj.objectType} />
        </div>
      )}
      {tab === 'attrs' && <AttrsTable attrs={obj.attrs} />}
      {tab === 'xml' && <RawXmlForName rawTree={rawTree} folder={folder.name} tag="SHORTCUT" name={obj.name} />}
    </div>
  )
}

// --------- Mapping ----------------------------------------------------

function MappingDetail({
  model, folder, mapping, rawTree, onSelectInstance,
}: {
  model: PowermartModel; folder: Folder; mapping: Mapping; rawTree: RawNode;
  onSelectInstance: (n: string) => void
}) {
  const [tab, setTab] = useState<'graph' | 'instances' | 'connectors' | 'variables' | 'xml'>('graph')
  return (
    <div className="detail" style={{ height: '100%', padding: 0 }}>
      <div style={{ padding: '12px 16px 0' }}>
        <h2>
          <span className="icon-dot mapping" /> {mapping.name}
          <span className="pill">MAPPING</span>
          <span className={`pill ${mapping.isValid ? 'ok' : 'warn'}`}>
            {mapping.isValid ? 'VALID' : 'INVALID'}
          </span>
        </h2>
        <div className="subtle">
          Folder {folder.name} · {mapping.instances.length} instances ·{' '}
          {mapping.connectors.length} connectors ·{' '}
          {mapping.transformations.length} inline transformations
          {mapping.description && <> · {mapping.description}</>}
        </div>
        <Tabs value={tab} onChange={setTab} tabs={[
          ['graph', 'Graph'],
          ['instances', `Instances (${mapping.instances.length})`],
          ['connectors', `Connectors (${mapping.connectors.length})`],
          ['variables', `Variables (${mapping.mappingVariables.length})`],
          ['xml', 'Raw XML'],
        ]} />
      </div>
      {tab === 'graph' && (
        <div style={{ position: 'relative', flex: 1, minHeight: 500, height: '100%' }}>
          <Suspense fallback={<div className="detail"><div className="subtle">Loading mapping graph…</div></div>}>
            <MappingGraph model={model} folder={folder} mapping={mapping}
                          onSelectInstance={onSelectInstance} rawTree={rawTree} />
          </Suspense>
        </div>
      )}
      {tab !== 'graph' && (
        <div style={{ padding: '0 16px 16px' }}>
          {tab === 'instances' && <InstanceTable mapping={mapping} onSelect={onSelectInstance} />}
          {tab === 'connectors' && <ConnectorTable mapping={mapping} />}
          {tab === 'variables' && (
            <table className="grid">
              <thead><tr><th>Name</th><th>Type</th><th>Aggregation</th><th>Default</th></tr></thead>
              <tbody>
                {mapping.mappingVariables.map((v) => (
                  <tr key={v.name}>
                    <td className="mono">{v.name}</td>
                    <td className="mono">{v.dataType}({v.precision})</td>
                    <td>{v.aggregationType}</td>
                    <td className="mono">{v.defaultValue}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {tab === 'xml' && <RawXmlForName rawTree={rawTree} folder={folder.name} tag="MAPPING" name={mapping.name} />}
        </div>
      )}
    </div>
  )
}

function InstanceTable({ mapping, onSelect }: { mapping: Mapping; onSelect: (n: string) => void }) {
  return (
    <table className="grid">
      <thead><tr><th>Name</th><th>Type</th><th>Refers to</th><th>Reusable</th></tr></thead>
      <tbody>
        {mapping.instances.map((i) => (
          <tr key={i.name} style={{ cursor: 'pointer' }} onClick={() => onSelect(i.name)}>
            <td>{i.name}</td>
            <td className="dim">{i.type}{i.transformationType && ` / ${i.transformationType}`}</td>
            <td className="mono">{i.transformationName}</td>
            <td className="dim">{i.reusable ? 'YES' : ''}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

const CONNECTOR_ACCESSORS: Accessors<Mapping['connectors'][number]> = {
  fi: (c) => c.fromInstance,
  ff: (c) => c.fromField,
  fg: (c) => c.fromGroup ?? '',
  ti: (c) => c.toInstance,
  tf: (c) => c.toField,
  tg: (c) => c.toGroup ?? '',
}

function ConnectorTable({ mapping }: { mapping: Mapping }) {
  const { sorted, toggle, chev } = useSortedRows(mapping.connectors, CONNECTOR_ACCESSORS)
  return (
    <table className="grid">
      <thead>
        <tr>
          <SortableTh label="From instance" sortKey="fi" toggle={toggle} chev={chev} />
          <SortableTh label="From field" sortKey="ff" toggle={toggle} chev={chev} />
          <SortableTh label="Group" sortKey="fg" toggle={toggle} chev={chev} />
          <SortableTh label="→ To instance" sortKey="ti" toggle={toggle} chev={chev} />
          <SortableTh label="To field" sortKey="tf" toggle={toggle} chev={chev} />
          <SortableTh label="Group" sortKey="tg" toggle={toggle} chev={chev} />
        </tr>
      </thead>
      <tbody>
        {sorted.map((c, i) => (
          <tr key={i}>
            <td>{c.fromInstance}</td>
            <td className="mono">{c.fromField}</td>
            <td className="dim">{c.fromGroup ?? ''}</td>
            <td>{c.toInstance}</td>
            <td className="mono">{c.toField}</td>
            <td className="dim">{c.toGroup ?? ''}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

// Connector tables scoped to a single instance. Unlike the mapping-wide
// ConnectorTable, the fixed side (this instance) is dropped from the columns
// so the panel stays focused on "where does this come from / go to".

const INCOMING_CONN_ACCESSORS: Accessors<Connector> = {
  fi: (c) => c.fromInstance,
  fg: (c) => c.fromGroup ?? '',
  ff: (c) => c.fromField,
  tf: (c) => c.toField,
  tg: (c) => c.toGroup ?? '',
}

function IncomingConnectorTable({ connectors }: { connectors: Connector[] }) {
  const { sorted, toggle, chev } = useSortedRows(connectors, INCOMING_CONN_ACCESSORS)
  if (connectors.length === 0) return <div className="subtle">No incoming connectors.</div>
  return (
    <table className="grid">
      <thead>
        <tr>
          <SortableTh label="From instance" sortKey="fi" toggle={toggle} chev={chev} />
          <SortableTh label="From group" sortKey="fg" toggle={toggle} chev={chev} />
          <SortableTh label="From field" sortKey="ff" toggle={toggle} chev={chev} />
          <SortableTh label="→ To field" sortKey="tf" toggle={toggle} chev={chev} />
          <SortableTh label="To group" sortKey="tg" toggle={toggle} chev={chev} />
        </tr>
      </thead>
      <tbody>
        {sorted.map((c, i) => (
          <tr key={i}>
            <td>{c.fromInstance}</td>
            <td className="dim">{c.fromGroup ?? ''}</td>
            <td className="mono">{c.fromField}</td>
            <td className="mono">{c.toField}</td>
            <td className="dim">{c.toGroup ?? ''}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

const OUTGOING_CONN_ACCESSORS: Accessors<Connector> = {
  ti: (c) => c.toInstance,
  tg: (c) => c.toGroup ?? '',
  tf: (c) => c.toField,
  ff: (c) => c.fromField,
  fg: (c) => c.fromGroup ?? '',
}

function OutgoingConnectorTable({ connectors }: { connectors: Connector[] }) {
  const { sorted, toggle, chev } = useSortedRows(connectors, OUTGOING_CONN_ACCESSORS)
  if (connectors.length === 0) return <div className="subtle">No outgoing connectors.</div>
  return (
    <table className="grid">
      <thead>
        <tr>
          <SortableTh label="To instance" sortKey="ti" toggle={toggle} chev={chev} />
          <SortableTh label="To group" sortKey="tg" toggle={toggle} chev={chev} />
          <SortableTh label="To field" sortKey="tf" toggle={toggle} chev={chev} />
          <SortableTh label="← From field" sortKey="ff" toggle={toggle} chev={chev} />
          <SortableTh label="From group" sortKey="fg" toggle={toggle} chev={chev} />
        </tr>
      </thead>
      <tbody>
        {sorted.map((c, i) => (
          <tr key={i}>
            <td>{c.toInstance}</td>
            <td className="dim">{c.toGroup ?? ''}</td>
            <td className="mono">{c.toField}</td>
            <td className="mono">{c.fromField}</td>
            <td className="dim">{c.fromGroup ?? ''}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

// --------- Instance (clicked from graph) ------------------------------

function InstanceDetail({
  model, folder, mapping, instanceName, rawTree, onSelect,
}: {
  model: PowermartModel; folder: Folder; mapping: Mapping; instanceName: string;
  rawTree: RawNode; onSelect: (s: SelectedObject) => void
}) {
  const inst = mapping.instances.find((i) => i.name === instanceName)!
  const resolved = resolveInstance(model, folder, mapping, inst)
  const lineageRows = useMemo(
    () => buildLineageRows(resolved, inst, mapping),
    [resolved, inst, mapping],
  )
  const incoming = useMemo(
    () => mapping.connectors.filter((c) => c.toInstance === inst.name),
    [mapping, inst.name],
  )
  const outgoing = useMemo(
    () => mapping.connectors.filter((c) => c.fromInstance === inst.name),
    [mapping, inst.name],
  )

  return (
    <div className="detail">
      <h2>
        <span className="icon-dot xform" /> {inst.name}
        <span className="pill">INSTANCE</span>
        <span className="pill accent">{inst.type}{inst.transformationType && ` / ${inst.transformationType}`}</span>
      </h2>
      <div className="subtle">
        In mapping{' '}
        <a href="#" onClick={(e) => { e.preventDefault();
          onSelect({ kind: 'mapping', folder: folder.name, name: mapping.name }) }}>{mapping.name}</a>
        {' · '}refers to <code>{inst.transformationName}</code>
        {inst.associatedSourceInstance && <> · associated source <code>{inst.associatedSourceInstance}</code></>}
      </div>

      <Section title={`Fields (${lineageRows.length}) — incoming + outgoing lineage`}>
        <div className="subtle" style={{ marginBottom: 6 }}>
          One row per field. Default order: <b>input → literal → derived → lkp → output</b>.
          The original Informatica order is preserved within each role; toggle to "Original order" if it already reads logically.
        </div>
        <UnifiedLineageView rows={lineageRows} />
      </Section>

      <Section title={`Incoming connectors (${incoming.length})`}>
        <IncomingConnectorTable connectors={incoming} />
      </Section>

      <Section title={`Outgoing connectors (${outgoing.length})`}>
        <OutgoingConnectorTable connectors={outgoing} />
      </Section>

      <ResolvedEmbed resolved={resolved} instanceName={inst.name}
                      mapping={mapping} rawTree={rawTree} />
    </div>
  )
}

function ResolvedEmbed({ resolved, instanceName, mapping, rawTree }: {
  resolved: Resolved | null; instanceName: string;
  mapping: Mapping; rawTree: RawNode
}) {
  if (!resolved) {
    return <div className="subtle">Instance does not resolve to any known object.</div>
  }
  if (resolved.kind === 'shortcut-broken') {
    const sc = resolved.obj
    return (
      <div className="section">
        <div className="via-shortcut warn">
          <span className="pill warn">BROKEN SHORTCUT</span>{' '}
          <code>{instanceName}</code> → <code>{sc.name}</code> →{' '}
          <code>{sc.refFolder}/{sc.refObject}</code> — target not found.
        </div>
      </div>
    )
  }
  const via = resolved.viaShortcut ? (
    <div className="via-shortcut">
      <span className="pill shortcut">via SHORTCUT</span>{' '}
      <code>{instanceName}</code> → <code>{resolved.viaShortcut.name}</code> →{' '}
      <code>{resolved.folder.name}/{resolved.viaShortcut.refObject}</code>
    </div>
  ) : null

  if (resolved.kind === 'transformation') {
    return (
      <>
        {via}
        <TransformationDetail folder={resolved.folder} obj={resolved.obj}
                              rawTree={rawTree} reusable={resolved.reusable}
                              inMapping={mapping} />
      </>
    )
  }
  if (resolved.kind === 'source') {
    return (
      <>
        {via}
        <SourceDetail folder={resolved.folder} obj={resolved.obj} rawTree={rawTree} />
      </>
    )
  }
  // target
  return (
    <>
      {via}
      <TargetDetail folder={resolved.folder} obj={resolved.obj} rawTree={rawTree} />
    </>
  )
}

// --------- Workflow ---------------------------------------------------

function WorkflowDetail({ folder, obj, rawTree }: { folder: Folder; obj: Workflow; rawTree: RawNode }) {
  const [tab, setTab] = useState<'sessions' | 'links' | 'xml'>('sessions')
  return (
    <div className="detail">
      <h2>
        <span className="icon-dot" style={{ background: 'var(--warn)' }} /> {obj.name}
        <span className="pill">WORKFLOW</span>
        <span className={`pill ${obj.isValid ? 'ok' : 'warn'}`}>
          {obj.isValid ? 'VALID' : 'INVALID'}
        </span>
      </h2>
      <div className="subtle">
        Folder {folder.name} · {obj.sessions.length} sessions · {obj.links.length} links
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[
        ['sessions', `Sessions (${obj.sessions.length})`],
        ['links', `Links (${obj.links.length})`],
        ['xml', 'Raw XML'],
      ]} />
      {tab === 'sessions' && (
        <table className="grid">
          <thead><tr><th>Name</th><th>Maps to</th><th>Attributes</th></tr></thead>
          <tbody>
            {obj.sessions.map((s) => (
              <tr key={s.name}>
                <td>{s.name}</td>
                <td className="mono">{s.mappingName}</td>
                <td className="dim">{s.attributes.length}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {tab === 'links' && (
        <table className="grid">
          <thead><tr><th>From</th><th>→ To</th><th>Condition</th></tr></thead>
          <tbody>
            {obj.links.map((l, i) => (
              <tr key={i}>
                <td>{l.fromTask}</td>
                <td>{l.toTask}</td>
                <td className="mono">{l.condition}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {tab === 'xml' && <RawXmlForName rawTree={rawTree} folder={folder.name} tag="WORKFLOW" name={obj.name} />}
    </div>
  )
}

// --------- Raw XML view -----------------------------------------------

export function RawXmlForName({
  rawTree, folder, tag, name,
}: { rawTree: RawNode; folder?: string; tag: string; name: string }) {
  const node = folder
    ? findNamedInFolder(rawTree, folder, tag, name)
    : findNamedAnywhere(rawTree, tag, name)
  if (!node) return <div className="subtle">(element not found)</div>
  return (
    <div className="xml-tree-wrap">
      <div className="xml-toolbar subtle">
        Collapsible view — click a chevron to fold child elements.
      </div>
      <pre className="code xml-tree">
        <XmlElement node={node} depth={0} initialDepth={2} />
      </pre>
    </div>
  )
}

function findNamedAnywhere(root: RawNode, tag: string, name: string): RawNode | null {
  if (root.tag === tag && root.attrs.NAME === name) return root
  for (const c of root.children) {
    const hit = findNamedAnywhere(c, tag, name)
    if (hit) return hit
  }
  return null
}

function XmlElement({ node, depth, initialDepth }: {
  node: RawNode; depth: number; initialDepth: number
}) {
  const [open, setOpen] = useState(depth < initialDepth)
  const indent = '  '.repeat(depth)
  const attrs = Object.entries(node.attrs)
  const hasChildren = node.children.length > 0

  const attrFragments = attrs.map(([k, v], i) => (
    <span key={i}>
      {' '}<span className="xml-attr-name">{k}</span>=
      <span className="xml-attr-value">"{escapeXml(v)}"</span>
    </span>
  ))

  if (!hasChildren) {
    return (
      <div className="xml-line">
        <span className="xml-indent">{indent}</span>
        <span className="xml-bracket">&lt;</span>
        <span className="xml-tagname">{node.tag}</span>
        {attrFragments}
        <span className="xml-bracket">/&gt;</span>
      </div>
    )
  }

  return (
    <>
      <div className="xml-line">
        <span className="xml-indent">{indent}</span>
        <span className="xml-chev" onClick={() => setOpen(!open)}>{open ? '▾' : '▸'}</span>
        <span className="xml-bracket">&lt;</span>
        <span className="xml-tagname">{node.tag}</span>
        {attrFragments}
        <span className="xml-bracket">&gt;</span>
        {!open && (
          <>
            <span className="xml-fold"> … {node.children.length} child element{node.children.length === 1 ? '' : 's'} … </span>
            <span className="xml-bracket">&lt;/</span>
            <span className="xml-tagname">{node.tag}</span>
            <span className="xml-bracket">&gt;</span>
          </>
        )}
      </div>
      {open && node.children.map((c, i) => (
        <XmlElement key={i} node={c} depth={depth + 1} initialDepth={initialDepth} />
      ))}
      {open && (
        <div className="xml-line">
          <span className="xml-indent">{indent}</span>
          <span className="xml-bracket">&lt;/</span>
          <span className="xml-tagname">{node.tag}</span>
          <span className="xml-bracket">&gt;</span>
        </div>
      )}
    </>
  )
}

function escapeXml(v: string): string {
  return v
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

// --------- Generic helpers --------------------------------------------

function Tabs<T extends string>({ value, onChange, tabs }: {
  value: T; onChange: (v: T) => void; tabs: [T, string][]
}) {
  return (
    <div className="tabs">
      {tabs.map(([k, label]) => (
        <div key={k} className={`tab ${k === value ? 'active' : ''}`}
             onClick={() => onChange(k)}>{label}</div>
      ))}
    </div>
  )
}

function AttrsTable({ attrs }: { attrs: Attrs }) {
  const rows = Object.entries(attrs)
  if (rows.length === 0) return <div className="subtle">No attributes.</div>
  return (
    <table className="grid">
      <thead><tr><th style={{ width: '35%' }}>Name</th><th>Value</th></tr></thead>
      <tbody>
        {rows.map(([k, v]) => (
          <tr key={k}><td>{k}</td><td className="mono">{v}</td></tr>
        ))}
      </tbody>
    </table>
  )
}
