// Unified field-lineage view: replaces the old "Incoming connectors" /
// "Outgoing connectors" tables in InstanceDetail with a single grid showing
// every field of the instance, classified by logical role
// (input → literal → derived → lkp → output) so a reader can scan the
// transformation top-to-bottom and understand "what comes in, what's
// computed how, what goes out".
//
// Long expressions (e.g. multi-arg :LKP calls) are truncated; an expand
// chevron reveals the full expression + every up/downstream connector.

import { Fragment, useMemo, useState, type ReactNode } from 'react'
import type {
  Connector, Instance, Mapping, SourceField, TargetField,
} from './ir'
import type { Resolved } from './resolve'
import { parsePortType, type PortTypeMeta } from './sql/catalog'

export type FieldRole = 'input' | 'passthru' | 'literal' | 'derived' | 'lkp' | 'output'

// Display order for "By role" sort. Passthroughs sit right after inputs:
// they're carried-through values, conceptually input-side.
const ROLE_ORDER: Record<FieldRole, number> = {
  input: 0, passthru: 1, literal: 2, derived: 3, lkp: 4, output: 5,
}
const ROLE_LABEL: Record<FieldRole, string> = {
  input: 'INPUT', passthru: 'PASSTHRU', literal: 'LITERAL',
  derived: 'DERIVED', lkp: 'LKP', output: 'OUTPUT',
}

function classifyExpression(expr: string): 'literal' | 'derived' | 'lkp' {
  const t = expr.trim()
  if (!t) return 'derived'
  if (/:LKP\./i.test(t)) return 'lkp'
  if (/^-?\d+(\.\d+)?$/.test(t)) return 'literal'
  if (/^'(?:[^']|'')*'$/.test(t)) return 'literal'
  if (/^(NULL|TRUE|FALSE)$/i.test(t)) return 'literal'
  return 'derived'
}

function classifyRole(flags: PortTypeMeta, expression: string): FieldRole {
  // Override priority (highest wins):
  //   passthru > output > {literal | derived | lkp} > input
  //
  // 1. INPUT+OUTPUT → passthru (the special case the user called out: a
  //    field that just carries data through, not derived).
  if (flags.isInput && flags.isOutput) return 'passthru'
  // 2. Any OUTPUT port → output, regardless of expression. The
  //    sub-classification (literal/derived/lkp) is reserved for variables.
  if (flags.isOutput) return 'output'
  // 3. VARIABLE (no input, no output flag): classify by expression.
  if (flags.isVariable) {
    const t = expression.trim()
    if (!t) return 'derived'
    return classifyExpression(expression)
  }
  // 4. Default: pure INPUT-only.
  return 'input'
}

export type LineageRow = {
  line: number          // 1-based original index in the underlying field list
  name: string
  flags: PortTypeMeta
  group?: string
  dataType: string
  precision: string
  scale: string
  expression: string
  role: FieldRole
  upstream: Connector[]
  downstream: Connector[]
}

const SYNTHETIC_OUTPUT: PortTypeMeta = {
  raw: 'OUTPUT', roles: ['OUTPUT'],
  isInput: false, isOutput: true, isVariable: false, isLookupKey: false, isReturn: false,
  sqlRole: 'select', description: '',
}
const SYNTHETIC_INPUT: PortTypeMeta = {
  raw: 'INPUT', roles: ['INPUT'],
  isInput: true, isOutput: false, isVariable: false, isLookupKey: false, isReturn: false,
  sqlRole: 'filter', description: '',
}

export function buildLineageRows(
  resolved: Resolved | null,
  inst: Instance,
  mapping: Mapping,
): LineageRow[] {
  const incoming = new Map<string, Connector[]>()
  const outgoing = new Map<string, Connector[]>()
  for (const c of mapping.connectors) {
    if (c.toInstance === inst.name) {
      const arr = incoming.get(c.toField) ?? []
      arr.push(c); incoming.set(c.toField, arr)
    }
    if (c.fromInstance === inst.name) {
      const arr = outgoing.get(c.fromField) ?? []
      arr.push(c); outgoing.set(c.fromField, arr)
    }
  }

  if (!resolved || resolved.kind === 'shortcut-broken') return []

  if (resolved.kind === 'transformation') {
    return resolved.obj.fields.map((f, i) => {
      const flags = parsePortType(f.portType)
      const expression = f.expression || ''
      return {
        line: i + 1,
        name: f.name,
        flags, group: f.group,
        dataType: f.dataType, precision: f.precision, scale: f.scale,
        expression,
        role: classifyRole(flags, expression),
        upstream: incoming.get(f.name) ?? [],
        downstream: outgoing.get(f.name) ?? [],
      }
    })
  }
  if (resolved.kind === 'source') {
    return resolved.obj.fields.map((f: SourceField, i: number) => ({
      line: i + 1, name: f.name, flags: SYNTHETIC_OUTPUT,
      dataType: f.dataType, precision: f.precision, scale: f.scale,
      expression: '', role: 'output' as FieldRole,
      upstream: [], downstream: outgoing.get(f.name) ?? [],
    }))
  }
  // target
  return resolved.obj.fields.map((f: TargetField, i: number) => ({
    line: i + 1, name: f.name, flags: SYNTHETIC_INPUT,
    dataType: f.dataType, precision: f.precision, scale: f.scale,
    expression: '', role: 'input' as FieldRole,
    upstream: incoming.get(f.name) ?? [], downstream: [],
  }))
}

// ---------- Logical clustering ---------------------------------------------

// "Logical" order = topological clustering by output. Each OUTPUT field's
// transitive expression-dependency closure forms one cluster, in the order
// it would be produced inside a CTE (input → literal → derived → lkp →
// output). Outputs are processed in original line order; if a field feeds
// multiple outputs, it sticks with the first one it reached.

const IDENT_RE = /[A-Za-z_]\w*/g

function expressionDeps(expr: string, knownNames: Set<string>, self: string): Set<string> {
  const out = new Set<string>()
  if (!expr) return out
  for (const m of expr.match(IDENT_RE) ?? []) {
    if (m !== self && knownNames.has(m)) out.add(m)
  }
  return out
}

function computeLogicalClusters(rows: LineageRow[]): LineageRow[][] {
  const byName = new Map<string, LineageRow>()
  const knownNames = new Set<string>()
  for (const r of rows) { byName.set(r.name, r); knownNames.add(r.name) }

  const deps = new Map<string, Set<string>>()
  for (const r of rows) deps.set(r.name, expressionDeps(r.expression, knownNames, r.name))

  // Cluster heads = fields whose ROLE is 'output'. Using role (not the raw
  // isOutput flag) excludes passthroughs (INPUT+OUTPUT, role='input'), which
  // carry data through unchanged and shouldn't head their own clusters —
  // they fall through to the orphan cluster instead.
  const outputs = rows.filter((r) => r.role === 'output').sort((a, b) => a.line - b.line)
  const assigned = new Set<string>()
  const clusters: LineageRow[][] = []

  // Build a cluster from one output by reverse-reachability through expression
  // deps, then order its members with layered topological sort (Kahn). Within
  // a layer, fall back to original line number for stability.
  //
  //   layer 0 = leaves (inputs / dep-free literals)
  //   layer N = nodes whose in-cluster deps are all in layers < N
  //   last layer ≈ the output
  //
  // Each layer maps to "one CTE's worth of fields you could compute together",
  // which is the user-facing intuition for the order.
  const buildCluster = (members: Set<string>): LineageRow[] => {
    const remaining = new Set(members)
    const ordered: LineageRow[] = []
    while (remaining.size > 0) {
      const layer: string[] = []
      for (const n of remaining) {
        const ds = deps.get(n) ?? new Set<string>()
        let ready = true
        for (const d of ds) {
          if (members.has(d) && remaining.has(d)) { ready = false; break }
        }
        if (ready) layer.push(n)
      }
      // Cycle guard — shouldn't trigger for Informatica expressions, but
      // emit remaining nodes in line order rather than infinite-looping.
      if (layer.length === 0) for (const n of remaining) layer.push(n)
      layer.sort((a, b) => byName.get(a)!.line - byName.get(b)!.line)
      for (const n of layer) {
        ordered.push(byName.get(n)!)
        remaining.delete(n)
      }
    }
    return ordered
  }

  for (const out of outputs) {
    if (assigned.has(out.name)) continue
    // Reverse-reachability: collect every field the output transitively
    // depends on. Skip nodes already claimed by an earlier output's cluster
    // (first-output-wins, deterministic via line-sorted outputs above).
    const members = new Set<string>()
    const stack = [out.name]
    while (stack.length) {
      const cur = stack.pop()!
      if (members.has(cur) || assigned.has(cur)) continue
      members.add(cur)
      for (const d of deps.get(cur) ?? []) stack.push(d)
    }
    if (members.size === 0) continue
    for (const n of members) assigned.add(n)
    clusters.push(buildCluster(members))
  }

  // Orphans: fields not reachable from any output. Split by role so input/
  // passthru orphans get their own cluster (which floats to the top) and
  // dead variables get a separate cluster that sinks to the bottom.
  const inputOrphans = new Set<string>()
  const deadOrphans = new Set<string>()
  for (const r of rows) {
    if (assigned.has(r.name)) continue
    if (r.role === 'input' || r.role === 'passthru') inputOrphans.add(r.name)
    else deadOrphans.add(r.name)
  }
  if (inputOrphans.size > 0) clusters.push(buildCluster(inputOrphans))
  if (deadOrphans.size > 0) clusters.push(buildCluster(deadOrphans))

  // Final cluster ordering. Goal: never show an output above an input.
  //
  //   tier 0: orphan input/passthru cluster   → top
  //   tier 1: real output cluster (has deps)  → middle, by output line
  //   tier 2: trivial output cluster (no deps, e.g. literal-only output)
  //   tier 3: dead-variable orphan cluster    → bottom
  const tierOf = (c: LineageRow[]): number => {
    const hasOutput = c.some((r) => r.role === 'output')
    const hasInputTier = c.some((r) => r.role === 'input' || r.role === 'passthru')
    if (!hasOutput) return hasInputTier ? 0 : 3
    return c.length > 1 ? 1 : 2
  }
  const repLine = (c: LineageRow[]): number =>
    c.find((r) => r.role === 'output')?.line
      ?? Math.min(...c.map((r) => r.line))
  clusters.sort((a, b) => {
    const ta = tierOf(a), tb = tierOf(b)
    if (ta !== tb) return ta - tb
    return repLine(a) - repLine(b)
  })

  return clusters
}

// ---------- View -----------------------------------------------------------

type SortMode = 'logical' | 'role' | 'original'

export function UnifiedLineageView({ rows }: { rows: LineageRow[] }) {
  const [mode, setMode] = useState<SortMode>('logical')
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set())
  const toggle = (k: string) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(k)) next.delete(k); else next.add(k)
      return next
    })
  }

  // sorted: flat row list. clusterStarts: indices in `sorted` where a new
  // logical cluster begins (used for visual separators). For non-logical
  // modes the set is empty so no separators render.
  const { sorted, clusterStarts } = useMemo(() => {
    if (mode === 'logical') {
      const clusters = computeLogicalClusters(rows)
      const flat: LineageRow[] = []
      const starts = new Set<number>()
      for (const c of clusters) {
        if (flat.length > 0) starts.add(flat.length)
        flat.push(...c)
      }
      return { sorted: flat, clusterStarts: starts }
    }
    const arr = [...rows]
    if (mode === 'role') {
      arr.sort((a, b) => {
        const r = ROLE_ORDER[a.role] - ROLE_ORDER[b.role]
        return r !== 0 ? r : a.line - b.line
      })
    } else {
      arr.sort((a, b) => a.line - b.line)
    }
    return { sorted: arr, clusterStarts: new Set<number>() }
  }, [rows, mode])

  const counts = useMemo(() => {
    const m: Record<FieldRole, number> = {
      input: 0, passthru: 0, literal: 0, derived: 0, lkp: 0, output: 0,
    }
    for (const r of rows) m[r.role]++
    return m
  }, [rows])

  return (
    <div>
      <div className="lineage-toolbar">
        <div className="seg" role="tablist" aria-label="Sort order">
          <button className={mode === 'logical' ? 'active' : ''}
                  onClick={() => setMode('logical')}
                  title="Cluster by output: each output's dependency closure together, in CTE-build order">
            Logical
          </button>
          <button className={mode === 'role' ? 'active' : ''}
                  onClick={() => setMode('role')}
                  title="Group by role: input → literal → derived → lkp → output">
            By role
          </button>
          <button className={mode === 'original' ? 'active' : ''}
                  onClick={() => setMode('original')}
                  title="Original Informatica field order">
            Original
          </button>
        </div>
        <div className="lineage-counts">
          {(Object.keys(counts) as FieldRole[]).filter((k) => counts[k] > 0).map((k) => (
            <span key={k} className={`pill role-${k}`}>{ROLE_LABEL[k]} {counts[k]}</span>
          ))}
        </div>
      </div>
      <table className="grid lineage-grid">
        <thead>
          <tr>
            <th className="col-expand"></th>
            <th title="Line / original order">#</th>
            <th title="INPUT port">I</th>
            <th title="VARIABLE port">V</th>
            <th title="OUTPUT port">O</th>
            <th>Role</th>
            <th>Name</th>
            <th>Expression</th>
            <th>Type</th>
            <th>From</th>
            <th>To</th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((r, idx) => {
            const hasExpr = r.expression.trim().length > 0
            const multipleConnectors = r.upstream.length > 1 || r.downstream.length > 1
            // Any field with an expression OR multi-connector lineage gets a
            // chevron, regardless of length — the cell is CSS-clipped to one
            // line and that ellipsis can hide arbitrarily short content too,
            // so users always need a way out.
            const expandable = hasExpr || multipleConnectors
            const isOpen = expanded.has(r.name)
            const startsCluster = clusterStarts.has(idx)
            // Toggle on cell click as a shortcut, but skip if the user is
            // mid-text-selection (so copy-paste still works).
            const onCellToggle = () => {
              if (window.getSelection()?.toString()) return
              toggle(r.name)
            }
            return (
              <Fragment key={r.name}>
                <tr className={`lineage-row role-${r.role}-row${startsCluster ? ' cluster-start' : ''}`}>
                  <td className="col-expand">
                    {expandable
                      ? <span className="row-chev" onClick={() => toggle(r.name)}>{isOpen ? '▾' : '▸'}</span>
                      : null}
                  </td>
                  <td className="dim">{r.line}</td>
                  <Flag on={r.flags.isInput} />
                  <Flag on={r.flags.isVariable} />
                  <Flag on={r.flags.isOutput} />
                  <td><span className={`pill role-${r.role}`}>{ROLE_LABEL[r.role]}</span></td>
                  <td>
                    {r.name}
                    {r.group && <span className="subtle"> [{r.group}]</span>}
                  </td>
                  <td
                    className={`mono lineage-expr-cell${hasExpr ? ' clickable' : ''}${isOpen ? ' open' : ''}`}
                    onClick={hasExpr ? onCellToggle : undefined}
                    title={hasExpr && !isOpen ? r.expression : undefined}
                  >
                    {hasExpr && (isOpen
                      ? <span className="lineage-expr-full">{r.expression}</span>
                      : <span className="lineage-expr-clip">{r.expression}</span>)}
                  </td>
                  <td className="mono dim">
                    {r.dataType}{r.precision ? `(${r.precision}${r.scale && r.scale !== '0' ? `,${r.scale}` : ''})` : ''}
                  </td>
                  <td className="mono">{summarizeConnectors(r.upstream, 'from')}</td>
                  <td className="mono">{summarizeConnectors(r.downstream, 'to')}</td>
                </tr>
                {isOpen && <LineageDetailRow row={r} />}
              </Fragment>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

function Flag({ on }: { on: boolean }) {
  return <td className={`port-flag ${on ? 'on' : 'off'}`}>{on ? '●' : '·'}</td>
}

function summarizeConnectors(cs: Connector[], dir: 'from' | 'to'): ReactNode {
  if (cs.length === 0) return ''
  const c = cs[0]
  const inst = dir === 'from' ? c.fromInstance : c.toInstance
  const field = dir === 'from' ? c.fromField : c.toField
  const grp = dir === 'from' ? c.fromGroup : c.toGroup
  const head = `${inst}${grp ? ` [${grp}]` : ''}.${field}`
  return cs.length === 1 ? head : <>{head}<span className="subtle"> +{cs.length - 1}</span></>
}

function LineageDetailRow({ row }: { row: LineageRow }) {
  return (
    <tr className="expanded-row">
      <td></td>
      <td colSpan={10}>
        <div className="lineage-detail">
          {row.expression && (
            <div className="lineage-detail-block">
              <div className="dim">Expression</div>
              <pre className="code">{row.expression}</pre>
            </div>
          )}
          {row.upstream.length > 0 && (
            <div className="lineage-detail-block">
              <div className="dim">Incoming ({row.upstream.length})</div>
              <ul className="lineage-list">
                {row.upstream.map((c, i) => (
                  <li key={i} className="mono">
                    {c.fromInstance}{c.fromGroup && ` [${c.fromGroup}]`}.{c.fromField}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {row.downstream.length > 0 && (
            <div className="lineage-detail-block">
              <div className="dim">Outgoing ({row.downstream.length})</div>
              <ul className="lineage-list">
                {row.downstream.map((c, i) => (
                  <li key={i} className="mono">
                    {c.toInstance}{c.toGroup && ` [${c.toGroup}]`}.{c.toField}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </td>
    </tr>
  )
}
