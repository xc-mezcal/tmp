import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  applyNodeChanges,
  Background, Controls, Handle, MiniMap, Position, ReactFlow,
  type Edge, type Node, type NodeChange, type NodeProps,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import ELK from 'elkjs/lib/elk.bundled.js'
import type { Folder, Instance, Mapping, PowermartModel, RawNode } from './ir'
import { resolveInstance, type Resolved } from './resolve'
import { TransformationDetail, RawXmlForName } from './Detail'
import { getLayoutCache, setLayoutCache, type XY } from './MappingGraph.layout'

// Beyond this node count we skip elkjs entirely — it gets slow and has been
// observed to produce empty layouts. The topological fallback is instant.
const ELK_NODE_LIMIT = 150

// Hoisted to module scope so every edge in the graph shares the *same*
// style object reference. React Flow does shallow-compares; freshly-allocated
// inline literals would force re-diffs on every parent render.
const EDGE_STYLE = { stroke: '#7c8ab0', strokeWidth: 1.5 }
const EDGE_LABEL_STYLE = { fill: '#9aa3b2', fontSize: 10 }
const EDGE_LABEL_BG_STYLE = { fill: '#161a22' }

type Props = {
  model: PowermartModel
  folder: Folder
  mapping: Mapping
  rawTree: RawNode
  onSelectInstance: (name: string) => void
}

type PmNodeData = {
  label: string
  subtitle: string
  kind: 'SOURCE' | 'TARGET' | 'TRANSFORMATION'
  selected: boolean
}

function PmNode({ data }: NodeProps<Node<PmNodeData>>) {
  const cls = data.kind === 'SOURCE' ? 'source'
           : data.kind === 'TARGET' ? 'target' : 'transform'
  return (
    <div className={`pm-node ${cls} ${data.selected ? 'selected' : ''}`}>
      <Handle type="target" position={Position.Left} style={{ background: '#555' }} />
      <div className="pm-title">{data.label}</div>
      <div className="pm-subtitle">{data.subtitle}</div>
      <Handle type="source" position={Position.Right} style={{ background: '#555' }} />
    </div>
  )
}

const nodeTypes = { pm: PmNode }

const elk = new ELK()

export function MappingGraph({ model, folder, mapping, rawTree, onSelectInstance }: Props) {
  const [nodes, setNodes] = useState<Node<PmNodeData>[]>([])
  const [edges, setEdges] = useState<Edge[]>([])
  const [drawerInstance, setDrawerInstance] = useState<string | null>(null)
  const layoutKey = useRef(0)

  // Build unlaid-out nodes + edges from the mapping.
  const { rawNodes, rawEdges } = useMemo(() => {
    const nodes: Node<PmNodeData>[] = mapping.instances.map((inst) => {
      const r = resolveInstance(model, folder, mapping, inst)
      return {
        id: inst.name,
        type: 'pm',
        position: { x: 0, y: 0 },
        data: {
          label: inst.name,
          subtitle: subtitleFor(inst, r),
          kind: inst.type,
          selected: false,
        },
      }
    })
    // Deduplicate instance-level edges (multiple field-level connectors
    // between the same pair collapse into one visual edge).
    // O(N) count per (from, to) pair instead of an inner filter per connector.
    const counts = new Map<string, number>()
    for (const c of mapping.connectors) {
      const key = `${c.fromInstance}→${c.toInstance}`
      counts.set(key, (counts.get(key) ?? 0) + 1)
    }
    const seen = new Set<string>()
    const edges: Edge[] = []
    for (const c of mapping.connectors) {
      const key = `${c.fromInstance}→${c.toInstance}`
      if (seen.has(key)) continue
      seen.add(key)
      const fieldCount = counts.get(key) ?? 1
      edges.push({
        id: `e:${c.fromInstance}:${c.toInstance}`,
        source: c.fromInstance,
        target: c.toInstance,
        label: fieldCount > 1 ? `${fieldCount}` : undefined,
        style: EDGE_STYLE,
        labelStyle: EDGE_LABEL_STYLE,
        labelBgStyle: EDGE_LABEL_BG_STYLE,
      })
    }
    return { rawNodes: nodes, rawEdges: edges }
  }, [model, folder, mapping])

  const cacheKey = `${folder.name}/${mapping.name}`

  // Compute layout whenever the mapping changes.
  //
  // Preference order: session-cached positions (user's drags) → topological
  // longest-path layering (instant, always valid) → ELK refinement for
  // smaller graphs (tidier crossings).
  useEffect(() => {
    let cancelled = false
    const key = ++layoutKey.current

    const cached = getLayoutCache(cacheKey)
    const topoPos = topoLayout(rawNodes, rawEdges)
    const initialPos = new Map<string, XY>()
    for (const n of rawNodes) {
      initialPos.set(n.id, cached?.get(n.id) ?? topoPos.get(n.id) ?? { x: 0, y: 0 })
    }
    setNodes(rawNodes.map((n) => ({ ...n, position: initialPos.get(n.id)! })))
    setEdges(rawEdges)

    // If the cache fully covers this mapping, trust it — skip layout.
    const fullyCached = cached && rawNodes.every((n) => cached.has(n.id))
    if (fullyCached) return
    if (rawNodes.length > ELK_NODE_LIMIT) {
      setLayoutCache(cacheKey, initialPos)
      return
    }

    const graph = {
      id: 'root',
      layoutOptions: {
        'elk.algorithm': 'layered',
        'elk.direction': 'RIGHT',
        'elk.layered.spacing.nodeNodeBetweenLayers': '90',
        'elk.spacing.nodeNode': '40',
        'elk.layered.nodePlacement.strategy': 'NETWORK_SIMPLEX',
      },
      children: rawNodes.map((n) => ({
        id: n.id, width: 200, height: 64,
      })),
      edges: rawEdges.map((e) => ({
        id: e.id, sources: [e.source], targets: [e.target],
      })),
    }
    elk.layout(graph as any).then((res) => {
      if (cancelled || key !== layoutKey.current) return
      const posById = new Map<string, XY>()
      for (const c of res.children ?? []) {
        if (c.id && typeof c.x === 'number' && typeof c.y === 'number') {
          posById.set(c.id, { x: c.x, y: c.y })
        }
      }
      if (posById.size === 0) { setLayoutCache(cacheKey, initialPos); return }
      const merged = new Map(initialPos)
      for (const [id, p] of posById) merged.set(id, p)
      setLayoutCache(cacheKey, merged)
      setNodes((curr) => curr.map((n) => ({ ...n, position: merged.get(n.id) ?? n.position })))
    }).catch((err) => {
      setLayoutCache(cacheKey, initialPos)
      // eslint-disable-next-line no-console
      console.warn('ELK layout failed, using topological fallback:', err)
    })
    return () => { cancelled = true }
  }, [rawNodes, rawEdges, cacheKey])

  // React Flow change handler — lets users drag nodes and persists new
  // positions. When a drag ends (`!change.dragging`), snapshot the new
  // positions into the session cache so re-mounting the graph (tab switch,
  // detail navigation) restores the user's layout.
  const onNodesChange = useCallback((changes: NodeChange<Node<PmNodeData>>[]) => {
    setNodes((curr) => {
      const next = applyNodeChanges(changes, curr)
      const dragEnded = changes.some(
        (c) => c.type === 'position' && c.dragging === false,
      )
      if (dragEnded) {
        const snap = new Map<string, XY>()
        for (const n of next) snap.set(n.id, { x: n.position.x, y: n.position.y })
        setLayoutCache(cacheKey, snap)
      }
      return next
    })
  }, [cacheKey])

  // Selection highlight.
  useEffect(() => {
    setNodes((curr) => curr.map((n) => ({
      ...n,
      data: { ...n.data, selected: n.id === drawerInstance },
    })))
  }, [drawerInstance])

  const drawerInst = drawerInstance
    ? mapping.instances.find((i) => i.name === drawerInstance)
    : null
  const resolved = drawerInst
    ? resolveInstance(model, folder, mapping, drawerInst)
    : null

  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        onNodesChange={onNodesChange}
        nodesDraggable
        fitView
        fitViewOptions={{ padding: 0.15 }}
        proOptions={{ hideAttribution: true }}
        onNodeClick={(_e, node) => {
          setDrawerInstance(node.id)
          onSelectInstance(node.id)
        }}
        onPaneClick={() => setDrawerInstance(null)}
      >
        <Background color="#2a3042" gap={24} />
        <Controls showInteractive={false} />
        <MiniMap
          pannable zoomable
          nodeColor={(n) => {
            const k = (n.data as PmNodeData)?.kind
            return k === 'SOURCE' ? '#f4a261'
                 : k === 'TARGET' ? '#2a9d8f'
                 : '#8b9dfb'
          }}
          maskColor="rgba(0,0,0,0.5)"
          style={{ background: '#0f1115', border: '1px solid #2a3042' }}
        />
      </ReactFlow>

      {drawerInst && (
        <div className="drawer">
          <div className="drawer-close">
            <div>
              <b>{drawerInst.name}</b>{' '}
              <span className="subtle">{drawerInst.type}
                {drawerInst.transformationType && ` / ${drawerInst.transformationType}`}</span>
            </div>
            <button onClick={() => setDrawerInstance(null)}>Close</button>
          </div>
          <ResolvedBody resolved={resolved} instanceName={drawerInst.name}
                         mapping={mapping} rawTree={rawTree} />
        </div>
      )}
    </div>
  )
}

function ResolvedBody({ resolved, instanceName, mapping, rawTree }: {
  resolved: Resolved | null; instanceName: string;
  mapping: Mapping; rawTree: RawNode
}) {
  if (!resolved) {
    return <div className="detail"><div className="subtle">Reference not found.</div></div>
  }
  if (resolved.kind === 'shortcut-broken') {
    return (
      <div className="detail">
        <h2>{resolved.obj.name} <span className="pill warn">BROKEN SHORTCUT</span></h2>
        <div className="subtle">
          Points to {resolved.obj.refFolder}/{resolved.obj.refObject} ({resolved.obj.objectType}) — not found in model.
        </div>
      </div>
    )
  }
  const via = resolved.viaShortcut
    ? <ViaShortcutBanner instanceName={instanceName} viaShortcut={resolved.viaShortcut}
                          targetFolder={resolved.folder.name} />
    : null
  if (resolved.kind === 'transformation') {
    return (
      <>
        {via}
        <TransformationDetail folder={resolved.folder} obj={resolved.obj}
                              rawTree={rawTree} reusable={resolved.reusable}
                              inMapping={mapping} />
      </>
    )
  }
  if (resolved.kind === 'source') {
    return (
      <div className="detail">
        {via}
        <h2>{resolved.obj.name} <span className="pill">SOURCE</span>
          <span className="pill accent">{resolved.obj.databaseType}</span></h2>
        <div className="subtle">Referenced from this mapping as <code>{instanceName}</code></div>
        <RawXmlForName rawTree={rawTree} folder={resolved.folder.name} tag="SOURCE" name={resolved.obj.name} />
      </div>
    )
  }
  // target
  return (
    <div className="detail">
      {via}
      <h2>{resolved.obj.name} <span className="pill">TARGET</span>
        <span className="pill accent">{resolved.obj.databaseType}</span></h2>
      <div className="subtle">Referenced from this mapping as <code>{instanceName}</code></div>
      <RawXmlForName rawTree={rawTree} folder={resolved.folder.name} tag="TARGET" name={resolved.obj.name} />
    </div>
  )
}

function ViaShortcutBanner({ instanceName, viaShortcut, targetFolder }: {
  instanceName: string; viaShortcut: import('./ir').Shortcut; targetFolder: string
}) {
  return (
    <div className="via-shortcut">
      <span className="pill shortcut">via SHORTCUT</span>{' '}
      <code>{instanceName}</code> → <code>{viaShortcut.name}</code> →{' '}
      <code>{targetFolder}/{viaShortcut.refObject}</code>
    </div>
  )
}

/** Topological longest-path layering. Places every node at a column equal to
 *  its longest-path distance from a root, then stacks nodes within each
 *  column. Stable, cheap, and cycle-tolerant. */
function topoLayout(
  rawNodes: Node<PmNodeData>[],
  rawEdges: Edge[],
): Map<string, { x: number; y: number }> {
  const COL_W = 260, ROW_H = 110
  const indeg = new Map<string, number>()
  const outAdj = new Map<string, string[]>()
  for (const n of rawNodes) { indeg.set(n.id, 0); outAdj.set(n.id, []) }
  for (const e of rawEdges) {
    if (!indeg.has(e.source) || !indeg.has(e.target)) continue
    indeg.set(e.target, (indeg.get(e.target) ?? 0) + 1)
    outAdj.get(e.source)!.push(e.target)
  }
  const layer = new Map<string, number>()
  const queue: string[] = []
  const rem = new Map(indeg)
  for (const [id, d] of rem) if (d === 0) { queue.push(id); layer.set(id, 0) }
  let head = 0
  while (head < queue.length) {
    const u = queue[head++]
    const uL = layer.get(u) ?? 0
    for (const v of outAdj.get(u) ?? []) {
      layer.set(v, Math.max(layer.get(v) ?? 0, uL + 1))
      const r = (rem.get(v) ?? 0) - 1
      rem.set(v, r)
      if (r === 0) queue.push(v)
    }
  }
  // Any unvisited nodes came from cycles — drop them at layer 0.
  for (const n of rawNodes) if (!layer.has(n.id)) layer.set(n.id, 0)

  const origIdx = new Map(rawNodes.map((n, i) => [n.id, i]))
  const byLayer = new Map<number, string[]>()
  for (const [id, l] of layer) {
    const arr = byLayer.get(l) ?? []
    arr.push(id)
    byLayer.set(l, arr)
  }
  for (const arr of byLayer.values()) {
    arr.sort((a, b) => (origIdx.get(a) ?? 0) - (origIdx.get(b) ?? 0))
  }
  const positions = new Map<string, { x: number; y: number }>()
  for (const [lvl, ids] of byLayer) {
    ids.forEach((id, i) => positions.set(id, { x: lvl * COL_W, y: i * ROW_H }))
  }
  return positions
}

function subtitleFor(inst: Instance, resolved: Resolved | null): string {
  const via = resolved?.kind !== 'shortcut-broken' && resolved?.viaShortcut
    ? ` ← ${resolved.viaShortcut.name}` : ''
  if (inst.type === 'SOURCE') return `SOURCE → ${inst.transformationName}${via}`
  if (inst.type === 'TARGET') return `TARGET → ${inst.transformationName}${via}`
  const bits = [inst.transformationType || 'TRANSFORMATION']
  if (inst.reusable) bits.push('reusable')
  if (resolved?.kind !== 'shortcut-broken' && resolved?.viaShortcut) {
    bits.push(`via ${resolved.viaShortcut.name}`)
  }
  if (inst.associatedSourceInstance) bits.push(`src: ${inst.associatedSourceInstance}`)
  return bits.join(' · ')
}
