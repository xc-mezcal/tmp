// Cached node positions keyed by `${folder}/${mapping}`. Survives component
// unmount (e.g. tab switches) so a user's manual drags aren't lost when they
// navigate away and come back. Cleared on new-file load.
//
// Kept in its own module so App.tsx can call `clearLayoutCache()` without
// pulling in the @xyflow/react + elkjs MappingGraph chunk.

export type XY = { x: number; y: number }

const cache = new Map<string, Map<string, XY>>()

export function getLayoutCache(key: string): Map<string, XY> | undefined {
  return cache.get(key)
}

export function setLayoutCache(key: string, positions: Map<string, XY>): void {
  cache.set(key, positions)
}

export function clearLayoutCache(): void {
  cache.clear()
}
