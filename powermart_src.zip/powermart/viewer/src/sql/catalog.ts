// Catalog of Informatica Powermart transformation TYPEs and PORTTYPEs with the
// SQL-relevant semantics each one carries. The actively-used exports are
// `parsePortType` (PORTTYPE → role flags, used by the lineage view) and
// `routerGroupCondition` / `isDefaultRouterGroup`. `TRANSFORMATION_TYPES` is
// kept as reference data.
//
// Sources:
//   powrmart.dtd                    (TYPE/PORTTYPE are CDATA — unenumerated)
//   Informatica PowerCenter 10.x docs: Transformation Guide, Designer Guide
//   sample.xml emitted by our generate_sample.py
//
// "sql.kind" groups transformations by the SQL shape they translate into:
//   source        — pure read (no SQL emitted at the instance level; the SQ
//                   absorbs the source)
//   projection    — relational projection with per-output expressions
//                   (Expression, Update Strategy, Transaction Control)
//   selection     — WHERE filter (Filter)
//   aggregation   — GROUP BY + aggregate expressions (Aggregator, Rank)
//   join          — JOIN ... ON ...  (Joiner, optional Union all)
//   lookup        — scalar/correlated subquery (Lookup Procedure; unconnected
//                   :LKP call compiles inline)
//   branch        — routes rows to multiple output groups (Router)
//   pivot         — column→row expansion (Normalizer)
//   passthrough   — no relational effect (Sorter, Sequence pre-sort)
//   sink          — writes a target (INSERT/UPDATE/DELETE; actual DML driven
//                   by any inbound Update Strategy)
//   scan-sql      — free-form SQL block (SQL Transformation, Stored Procedure)
//   opaque        — user code — no SQL inference (Java, External Procedure,
//                   HTTP, Web Services, Unstructured Data, Custom)

export type SqlKind =
  | 'source' | 'projection' | 'selection' | 'aggregation' | 'join'
  | 'lookup' | 'branch' | 'pivot' | 'passthrough' | 'sink'
  | 'scan-sql' | 'opaque'

export interface TransformationTypeMeta {
  /** Canonical TYPE string as it appears in TRANSFORMATION.TYPE. */
  type: string
  /** Short code used in Informatica (SQ, EXP, FIL, …). */
  code: string
  /** SQL semantics group; drives generator dispatch. */
  sql: SqlKind
  /** TABLEATTRIBUTE names that carry SQL-bearing logic, in render order. */
  sqlAttrs: string[]
  /** Human-readable one-line summary for UI. */
  summary: string
}

export const TRANSFORMATION_TYPES: Record<string, TransformationTypeMeta> = {
  'Source Definition':     { type: 'Source Definition', code: 'SRC', sql: 'source',
    sqlAttrs: [], summary: 'Physical source table / file definition.' },
  'Target Definition':     { type: 'Target Definition', code: 'TGT', sql: 'sink',
    sqlAttrs: ['Update Override', 'Pre SQL', 'Post SQL', 'Target Load Type'],
    summary: 'Physical target table / file. Emits INSERT/UPDATE/DELETE.' },
  'Source Qualifier':      { type: 'Source Qualifier', code: 'SQ', sql: 'join',
    sqlAttrs: ['Sql Query', 'User Defined Join', 'Source Filter',
               'Number Of Sorted Ports', 'Select Distinct', 'Pre SQL', 'Post SQL'],
    summary: 'Reads from one or more sources; top-level SELECT of the mapping branch.' },
  'Expression':            { type: 'Expression', code: 'EXP', sql: 'projection',
    sqlAttrs: [], summary: 'Per-row column projection using expression language.' },
  'Filter':                { type: 'Filter', code: 'FIL', sql: 'selection',
    sqlAttrs: ['Filter Condition'], summary: 'Row-level predicate — WHERE clause.' },
  'Aggregator':            { type: 'Aggregator', code: 'AGG', sql: 'aggregation',
    sqlAttrs: ['Sorted Input', 'Transformation Scope', 'Cache Directory'],
    summary: 'Group-by with aggregate expressions over grouped ports.' },
  'Joiner':                { type: 'Joiner', code: 'JNR', sql: 'join',
    sqlAttrs: ['Join Type', 'Join Condition', 'Sorted Input',
               'Master Sort Order', 'Case Sensitive String Comparison'],
    summary: 'Inner / outer / full join of two pipelines (master + detail).' },
  'Lookup Procedure':      { type: 'Lookup Procedure', code: 'LKP', sql: 'lookup',
    sqlAttrs: ['Lookup table name', 'Lookup condition', 'Lookup Sql Override',
               'Lookup caching enabled', 'Lookup policy on multiple match',
               'Lookup source is static', 'Connection Information'],
    summary: 'Cache or correlated SELECT. Unconnected invocation is :LKP.name(args).' },
  'Router':                { type: 'Router', code: 'RTR', sql: 'branch',
    sqlAttrs: [], summary: 'Multi-output split: per-group filter condition.' },
  'Update Strategy':       { type: 'Update Strategy', code: 'UPD', sql: 'projection',
    sqlAttrs: ['Update Strategy Expression', 'Forward Rejected Rows'],
    summary: 'Tags rows with DD_INSERT/UPDATE/DELETE/REJECT via an expression.' },
  'Transaction Control':   { type: 'Transaction Control', code: 'TC', sql: 'projection',
    sqlAttrs: ['Transaction Control Condition'],
    summary: 'Emits COMMIT/ROLLBACK based on an expression (no SQL effect per row).' },
  'Sequence':              { type: 'Sequence', code: 'SEQ', sql: 'projection',
    sqlAttrs: ['Start Value', 'Increment By', 'End Value', 'Cycle',
               'Number of Cached Values', 'Reset'],
    summary: 'Generates monotonic integers — modeled as row_number() or sequence().' },
  'Rank':                  { type: 'Rank', code: 'RNK', sql: 'aggregation',
    sqlAttrs: ['Top/Bottom', 'Number Of Ranks', 'Case Sensitive String Comparison'],
    summary: 'Top-N / bottom-N per group using a RANK() window function.' },
  'Sorter':                { type: 'Sorter', code: 'SRT', sql: 'passthrough',
    sqlAttrs: ['Distinct', 'Case Sensitive', 'Null Treated Low'],
    summary: 'Sort + optional DISTINCT. Adds ORDER BY to the stream.' },
  'Union Transformation':  { type: 'Union Transformation', code: 'UN', sql: 'join',
    sqlAttrs: [], summary: 'UNION ALL of multiple input groups.' },
  'Normalizer':            { type: 'Normalizer', code: 'NRM', sql: 'pivot',
    sqlAttrs: ['Reset', 'Restart'],
    summary: 'Pivot / unpivot: occurs columns → rows (CROSS JOIN LATERAL / UNNEST).' },
  'Stored Procedure':      { type: 'Stored Procedure', code: 'SP', sql: 'scan-sql',
    sqlAttrs: ['Call Text', 'Stored Procedure Type', 'Connection Information',
               'Execution Order', 'Subsecond Precision'],
    summary: 'CALL proc(...). May be source-pre/post or inline per-row (:SP).' },
  'SQL Transformation':    { type: 'SQL Transformation', code: 'SQL', sql: 'scan-sql',
    sqlAttrs: ['SQL Mode', 'Database Type', 'Connection Type', 'Script'],
    summary: 'User-written SQL; query mode passes result rows downstream.' },
  'Java Transformation':   { type: 'Java Transformation', code: 'JAVA', sql: 'opaque',
    sqlAttrs: [], summary: 'User Java code — opaque to SQL generation.' },
  'External Procedure':    { type: 'External Procedure', code: 'EXT', sql: 'opaque',
    sqlAttrs: ['Module/Program Name', 'Procedure Name', 'Runtime Location'],
    summary: 'Calls a DLL/shared library; :EXT.proc(…) in expressions.' },
  'HTTP Transformation':          { type: 'HTTP Transformation', code: 'HTTP', sql: 'opaque',
    sqlAttrs: ['Base URL', 'HTTP Method', 'Authentication Type'],
    summary: 'HTTP client — opaque to SQL.' },
  'Web Services Consumer':        { type: 'Web Services Consumer', code: 'WSC', sql: 'opaque',
    sqlAttrs: ['WSDL URL', 'Operation', 'End Point URL'], summary: 'SOAP client — opaque.' },
  'Unstructured Data Transformation': { type: 'Unstructured Data Transformation', code: 'UDT',
    sql: 'opaque', sqlAttrs: [], summary: 'Data Transformation Studio streams — opaque.' },
  'Custom Transformation':        { type: 'Custom Transformation', code: 'CT', sql: 'opaque',
    sqlAttrs: ['Module Identifier', 'Generate Transaction'],
    summary: 'User C/C++ transformation — opaque.' },
}

export function metaForType(type: string | undefined): TransformationTypeMeta | undefined {
  if (!type) return undefined
  return TRANSFORMATION_TYPES[type]
}

// -------- Router group filter conditions ----------------------------------

/** Resolve the filter condition of one Router output GROUP.
 *
 *  Real Informatica PowerCenter exports carry the condition directly on the
 *  GROUP element's EXPRESSION attribute (powrmart.dtd:
 *  `GROUP.EXPRESSION CDATA #IMPLIED`) — *not* as a TABLEATTRIBUTE. Older /
 *  hand-rolled exports sometimes used a TABLEATTRIBUTE named
 *  "<group> Group Filter Condition" instead, so that is kept as a fallback.
 *
 *  The DEFAULT output group has no condition: it receives every row that
 *  matched none of the other output groups. */
export function routerGroupCondition(
  t: { tableAttributes: { name: string; value: string }[] },
  g: { name: string; expression: string },
): string {
  if (g.expression.trim()) return g.expression
  const ta = t.tableAttributes.find((a) => a.name === `${g.name} Group Filter Condition`)
  return ta?.value ?? ''
}

/** Heuristic: a Router output group whose name marks it as the catch-all
 *  DEFAULT group (Informatica names it DEFAULT, DEFAULT1, DEFAULT2, …). */
export function isDefaultRouterGroup(name: string): boolean {
  return /^DEFAULT\d*$/i.test(name.trim())
}

// -------- PORTTYPE catalog -------------------------------------------------

/** Single role inferred from a PORTTYPE string. */
export type PortRole =
  | 'INPUT' | 'OUTPUT' | 'VARIABLE'
  | 'LOOKUP' | 'RETURN'
  | 'MASTER' | 'DETAIL'

export interface PortTypeMeta {
  raw: string              // as seen in XML
  roles: PortRole[]        // union of role bits
  /** Reads from upstream connectors. */
  isInput: boolean
  /** Writes to downstream connectors. */
  isOutput: boolean
  /** Holds intermediate value in Expression / Aggregator. */
  isVariable: boolean
  /** Part of a Lookup's condition (matched against input row). */
  isLookupKey: boolean
  /** Scalar returned from unconnected :LKP call. */
  isReturn: boolean
  /** Where the port lives in SQL generation:
   *  - select:    appears in the projection list
   *  - filter:    feeds a WHERE / ON predicate
   *  - joinKey:   participates as a join key
   *  - internal:  expression-scope only (variable) */
  sqlRole: 'select' | 'filter' | 'joinKey' | 'internal' | 'passthrough' | 'return'
  description: string
}

const ROLE_ORDER: PortRole[] = ['INPUT', 'OUTPUT', 'VARIABLE', 'LOOKUP', 'RETURN', 'MASTER', 'DETAIL']

/** Parse a PORTTYPE string. Tokens may be comma- or slash-separated; some
 *  files use a plain space. We normalize to canonical role order. */
export function parsePortType(raw: string): PortTypeMeta {
  const tokens = raw
    .toUpperCase()
    .split(/[,\/\s]+/)
    .map((s) => s.trim())
    .filter(Boolean)
  const roles = ROLE_ORDER.filter((r) => tokens.includes(r))

  const isInput    = roles.includes('INPUT')
  const isOutput   = roles.includes('OUTPUT')
  const isVariable = roles.includes('VARIABLE')
  const isLookup   = roles.includes('LOOKUP')
  const isReturn   = roles.includes('RETURN')

  let sqlRole: PortTypeMeta['sqlRole']
  let description: string
  if (isVariable) {
    sqlRole = 'internal'
    description = 'Intermediate variable scoped to this transformation. Not materialized downstream; used in subsequent expressions within the same transform.'
  } else if (isLookup && (isOutput || isReturn)) {
    sqlRole = isReturn ? 'return' : 'select'
    description = isReturn
      ? 'Unconnected lookup return port. Its value is returned by :LKP.name(args). Also appears in SELECT if connected downstream.'
      : 'Lookup output: projected from the lookup table and available to downstream connectors once the lookup matches.'
  } else if (isLookup) {
    sqlRole = 'joinKey'
    description = 'Lookup condition key. Matched against the inbound row — appears on the right side of WHERE / ON.'
  } else if (isReturn) {
    sqlRole = 'return'
    description = 'Unconnected scalar return (:LKP.name).'
  } else if (isInput && isOutput) {
    sqlRole = 'passthrough'
    description = 'Passthrough port — value flows from upstream straight to downstream.'
  } else if (isOutput) {
    sqlRole = 'select'
    description = 'Output port — computed value exposed to downstream connectors.'
  } else if (isInput) {
    sqlRole = 'filter'
    description = 'Input-only port — consumed by this transform (e.g. into an expression) but not re-emitted.'
  } else {
    sqlRole = 'passthrough'
    description = `Unrecognized port role (raw="${raw}").`
  }

  return {
    raw, roles,
    isInput, isOutput, isVariable, isLookupKey: isLookup, isReturn,
    sqlRole, description,
  }
}

/** Infer the DML operation that a target instance should emit from its
 *  ATTRIBUTE values. Powermart emits update-strategy-aware targets based on
 *  the Session's "Treat Source Rows As" and target load type. */
export type TargetLoadOp = 'INSERT' | 'UPDATE' | 'DELETE' | 'UPSERT' | 'TRUNCATE_INSERT' | 'UNKNOWN'
export function inferTargetLoadOp(attrs: Readonly<Record<string, string>>): TargetLoadOp {
  const t = attrs.TARGETLOADTYPE ?? attrs['Target Load Type'] ?? ''
  if (/bulk/i.test(t)) return 'INSERT'
  if (/normal/i.test(t)) return 'INSERT'
  return 'UNKNOWN'
}
