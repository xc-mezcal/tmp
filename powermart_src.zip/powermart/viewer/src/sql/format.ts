// Thin wrapper over sql-formatter with graceful fallback.
//
// Our generated SQL sometimes contains angle-bracket placeholders (e.g.
// `FROM <upstream: SQ_foo>`), Informatica call-site artifacts (`:LKP.name(…)`,
// `:SEQ.name`), or pure comments — any of which can trip the parser. When
// formatting fails, we pass the original text through untouched so the UI
// still shows *something* meaningful.
//
// sql-formatter is ~290 KB minified — we load it via dynamic import() so it
// ships in its own chunk rather than bloating the initial bundle.

import { useEffect, useState } from 'react'

export type SqlDialect = 'plsql' | 'sql' | 'postgresql' | 'mysql' | 'tsql' | 'bigquery'

const FORMAT_OPTIONS = {
  keywordCase: 'upper' as const,
  tabWidth: 2,
  linesBetweenQueries: 1,
}

type FormatterModule = typeof import('sql-formatter')
let modulePromise: Promise<FormatterModule> | null = null
function loadFormatter(): Promise<FormatterModule> {
  modulePromise ??= import('sql-formatter')
  return modulePromise
}

/** React hook: returns the pretty-printed version of `src`, initially equal
 *  to `src` while sql-formatter loads asynchronously. */
export function useFormattedSql(src: string, dialect: SqlDialect = 'plsql'): string {
  const [out, setOut] = useState(src)
  useEffect(() => {
    if (!src || !src.trim()) { setOut(src); return }
    let cancelled = false
    loadFormatter().then((m) => {
      if (cancelled) return
      try {
        setOut(m.format(src, { ...FORMAT_OPTIONS, language: dialect as any }))
      } catch {
        setOut(src)
      }
    })
    return () => { cancelled = true }
  }, [src, dialect])
  return out
}

/** TABLEATTRIBUTE names that carry actual SQL text (as opposed to Informatica
 *  DSL expressions like Filter Condition). These are safe to pretty-print. */
export const SQL_BEARING_ATTRS = new Set<string>([
  'Sql Query',
  'Pre SQL',
  'Post SQL',
  'Lookup Sql Override',
  'Update Override',
  'Script',
])

export function isSqlAttr(name: string): boolean {
  return SQL_BEARING_ATTRS.has(name)
}
