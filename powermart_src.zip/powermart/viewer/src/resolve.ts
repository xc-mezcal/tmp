// Resolves INSTANCE → underlying Source/Target/Transformation, walking
// through SHORTCUTs that may cross folder boundaries.
//
// A Powermart SHORTCUT is a symbolic pointer: `SC_foo` in folder B might
// point at `foo` in folder A. Mapping instances reference the pointer by
// name, but downstream consumers (field grids, SQL generation) need the
// underlying object. Shortcut targets are always in the same repository,
// but may be in a different folder.

import type {
  Folder, Instance, Mapping, PowermartModel, Shortcut, Source, Target,
  Transformation,
} from './ir'

export type Resolved =
  | { kind: 'source';         folder: Folder; obj: Source;         viaShortcut?: Shortcut }
  | { kind: 'target';         folder: Folder; obj: Target;         viaShortcut?: Shortcut }
  | { kind: 'transformation'; folder: Folder; obj: Transformation; reusable: boolean; viaShortcut?: Shortcut }
  | { kind: 'shortcut-broken'; obj: Shortcut }

export function findFolder(model: PowermartModel, name: string): Folder | undefined {
  for (const r of model.repositories) for (const f of r.folders) if (f.name === name) return f
  return undefined
}

export function resolveShortcut(model: PowermartModel, sc: Shortcut): Resolved {
  const tf = findFolder(model, sc.refFolder)
  if (!tf) return { kind: 'shortcut-broken', obj: sc }
  const name = sc.refObject

  const ot = sc.objectType
  if (ot === 'SOURCE') {
    const s = tf.sources.find((x) => x.name === name)
    if (s) return { kind: 'source', folder: tf, obj: s, viaShortcut: sc }
  } else if (ot === 'TARGET') {
    const t = tf.targets.find((x) => x.name === name)
    if (t) return { kind: 'target', folder: tf, obj: t, viaShortcut: sc }
  } else if (ot === 'TRANSFORMATION' || ot === 'MAPPLET') {
    const tr = tf.transformations.find((x) => x.name === name)
    if (tr) return { kind: 'transformation', folder: tf, obj: tr, reusable: true, viaShortcut: sc }
  }

  // OBJECTTYPE missing or unexpected — scan everything.
  const s = tf.sources.find((x) => x.name === name)
  if (s) return { kind: 'source', folder: tf, obj: s, viaShortcut: sc }
  const t = tf.targets.find((x) => x.name === name)
  if (t) return { kind: 'target', folder: tf, obj: t, viaShortcut: sc }
  const tr = tf.transformations.find((x) => x.name === name)
  if (tr) return { kind: 'transformation', folder: tf, obj: tr, reusable: true, viaShortcut: sc }

  return { kind: 'shortcut-broken', obj: sc }
}

/** Resolve an INSTANCE in a MAPPING to the underlying object, following
 *  shortcuts. Lookup order: inline (mapping-scoped) transformation, then
 *  direct object in this folder, then shortcut → cross-folder target. */
export function resolveInstance(
  model: PowermartModel, folder: Folder, mapping: Mapping, inst: Instance,
): Resolved | null {
  const name = inst.transformationName

  if (inst.type === 'TRANSFORMATION') {
    const inline = mapping.transformations.find((t) => t.name === name)
    if (inline) return { kind: 'transformation', folder, obj: inline, reusable: false }
    const reusable = folder.transformations.find((t) => t.name === name)
    if (reusable) return { kind: 'transformation', folder, obj: reusable, reusable: true }
  }
  if (inst.type === 'SOURCE') {
    const s = folder.sources.find((x) => x.name === name)
    if (s) return { kind: 'source', folder, obj: s }
  }
  if (inst.type === 'TARGET') {
    const t = folder.targets.find((x) => x.name === name)
    if (t) return { kind: 'target', folder, obj: t }
  }

  const sc = folder.shortcuts.find((x) => x.name === name)
  if (sc) return resolveShortcut(model, sc)
  return null
}
