# Powermart XML Viewer

Project for viewing Informatica Powermart (`powrmart.dtd`) XML exports.
Expected file sizes: 20–30k lines (single-digit MB) in practice; the viewer
loads everything into memory. Conversion of transformations to SQL is an
active, partially-shipped milestone.

## Current milestones (as of 2026-04-19)

### M1 — Sample data ✅
- `generate_sample.py` — parameterized generator producing realistic Powermart XML.
  - Folder 1 `SHARED_METADATA`: only SOURCE + TARGET (Oracle, Teradata, flat file).
  - Folder 2 `EDW_CORE`: reusable TRANSFORMATIONs (one per major type), SHORTCUTs
    back to Folder 1, one big MAPPING exercising most transformation types, plus
    small mappings and a WORKFLOW with SESSIONs.
  - Covers ~18 transformation types: Source Qualifier, Expression, Filter, Aggregator,
    Joiner, Lookup, Router, Update Strategy, Sequence Generator, Rank, Sorter,
    Union, Normalizer, Stored Procedure, SQL Transformation, Transaction Control,
    Java, External Procedure, HTTP, Web Services Consumer, Unstructured Data.
  - `--scale N` multiplies mapping counts. scale=1 → ~880 lines; scale=50 → ~35k;
    scale≈300 → ~200k.
- `sample.xml` — committed scale=1 output used as the default demo.
- `simple.xml` — original hand-written minimal example (kept for reference).

**Caveat**: the generator does not emit every shape of real Powermart XML.
Treat it as illustrative, not exhaustive. When something behaves oddly in the
viewer, cross-check against the powrmart.dtd (authoritative schema) — see the
`dtd_reference.md` memory entry for its location and open-schema gotchas.

### M2 — Viewer app ✅
Location: `viewer/` (Vite + React 18 + TypeScript).

Dependencies: `@xyflow/react` (v12) for the DAG, `elkjs` for auto-layout,
`saxes` for single-pass XML parsing.

Source layout (~2500 LOC):
- `src/ir.ts` — normalized IR: Repository → Folder → {Source, Target, Transformation,
  Shortcut, Mapping, Workflow}. Every original XML attribute is preserved on an
  `attrs` bag so nothing is lost during parse. The model also retains the full
  `rawTree: RawNode` so the Raw XML tab renders from structured data, not a
  regex scan of text. Field definitions are enriched with
  `expressionType / defaultValue / description / businessName / pictureText`.
- `src/parser.ts` — saxes-based parser. Single-pass: `parser.write(text)` builds
  the raw tree, then `buildModel(...)` walks it into the IR. No streaming /
  chunking — file sizes are small enough that the 30-line progress bar read-and-
  parse path was overkill. Exports `findNamedInFolder` / `findNamedRawNode`
  for tab-based raw-XML lookup.
- `src/resolve.ts` — `resolveShortcut(model, sc)` and
  `resolveInstance(model, folder, mapping, inst)`. Transitively follows
  SHORTCUTs across folders and returns a discriminated union
  (`source | target | transformation | shortcut-broken`), with an optional
  `viaShortcut` breadcrumb so the UI can say "this instance came via SC_foo".
- `src/App.tsx` — drop-zone / file-picker / "load sample" button / progress bar /
  top bar with file size + repo stats / 2-pane workspace.
- `src/TreeBrowser.tsx` — collapsible tree grouping objects by type per folder,
  with fuzzy search that auto-expands matching groups. Shortcut leaves show
  `objectType → refFolder/refObject` in their subtitle.
- `src/Detail.tsx` — type-aware detail panes. Per transformation type, surfaces
  the SQL-relevant bits in the "Transformation" tab:
  - Source Qualifier: SQL Query, User Defined Join, Source Filter, Pre/Post SQL
  - Filter: Filter Condition
  - Expression: output-field expression grid
  - Aggregator: group-by fields + aggregate expression grid + sorted input flag
  - Joiner: Join Type + Join Condition + master/detail groups
  - Lookup: Lookup table + Lookup condition + Lookup SQL override + caching config
  - Router: per-output-group filter condition table
  - Update Strategy / Transaction Control: their expression
  - Sequence: start/increment/cycle
  - Rank: top/bottom + N + rank port + group-bys
  - Sorter: sort keys + direction
  - Stored Procedure: Call Text + type
  - SQL Transformation: Script/Query + mode + DB type
  - Java: ClassName + Runtime Location + On Input Row / On End Of Data code blocks
  - HTTP / Web Services / External Procedure: endpoints and bindings

  The Fields tab is now a full-column grid: expand-chev per row reveals every
  raw attribute for that field, with Description / Business Name / Picture Text
  highlighted. Each object also has an Attributes tab and a Raw XML tab (see
  below). The default tab is "Transformation" — it surfaces any SQL override
  as the top-priority view.

  InstanceDetail also carries collapsible "Incoming connectors" / "Outgoing
  connectors" panels alongside the unified incoming+outgoing lineage grid.
  Every connector/field table column is a 3-state sort toggle:
  asc → desc → back to original order.

  The Raw XML tab renders a pretty-formatted, chevron-collapsible tree from the
  retained `rawTree` (not a regex over source text). It finds the matching
  element by `tag + NAME` within the selected folder, falling back to
  anywhere in the tree. `XmlElement` collapses subtrees on click; initial
  expand depth = 2.

  ShortcutDetail shows a clickable "Points to" link that jumps to the resolved
  underlying object, and flags `BROKEN` when the target cannot be found.

  InstanceDetail (and MappingGraph's right drawer) use `resolveInstance` to
  walk through shortcuts and render the underlying Source/Target/Transformation
  in place, with a "via SHORTCUT" banner when a redirection happened.
- `src/MappingGraph.tsx` — React Flow DAG of INSTANCEs. Field-level CONNECTORs
  between the same pair collapse into one visual edge labeled with field count.
  elkjs `layered` left-to-right auto-layout. Click a node → right drawer with
  the full type-aware transformation detail.
- `src/sql/catalog.ts` — data-driven catalog of transformation TYPEs and
  PORTTYPE semantics. `parsePortType` accepts comma/slash/space-separated
  PORTTYPE strings and returns structured flags (`isInput / isOutput /
  isVariable / isLookupKey / isReturn`) plus a derived `sqlRole`.
  `routerGroupCondition` resolves a Router output group's filter condition
  (`GROUP/@EXPRESSION`, with a legacy TABLEATTRIBUTE fallback);
  `isDefaultRouterGroup` flags the catch-all group. The `TRANSFORMATION_TYPES`
  table is kept as reference data.
- `src/sql/format.ts` — `useFormattedSql` pretty-prints a SQL string for the
  Transformation tab's SQL-override blocks.
- `src/index.css` — dark theme, no CSS framework. Covers field-row expander,
  shortcut via-banner, pill variants, SQL block rendering.

### Status
- `npm run typecheck` and `npm run build` both clean.
- Bundle is ~1.87 MB (uncompressed) / ~576 KB (gzip). Code-splitting elkjs +
  @xyflow/react into a lazy chunk is deferred (see M-bundle below).
- `npm run dev` boots on port 5173; UI not yet visually verified by automation.

## Running

```
cd viewer
npm install        # first time only
npm run dev        # http://localhost:5173
```

Regenerate sample at a different scale:

```
python3 generate_sample.py --out viewer/public/sample.xml --scale 50
```

## Completed in this iteration (2026-04-15 → 2026-04-19)

- **Raw XML tab works on every object type.** Previously the regex extractor
  failed on multi-line elements. Now renders from the parsed `rawTree`.
- **Shortcut refinement.** Shortcuts are no longer shown as opaque pointer
  nodes in the mapping graph drawer. `resolveInstance` follows the shortcut
  across folders and shows the underlying source/target/transformation, with
  a "via SHORTCUT" banner so the provenance is still visible. Broken shortcuts
  are flagged explicitly.
- **Full field columns + all-attrs expander.** Each field row in Source /
  Target / Transformation field grids has an expand chevron that reveals every
  original XML attribute, plus Description / Business Name / Picture Text /
  Default Value surfaced as first-class columns.
- **M5 — SQL generation dropped (2026-05-19).** The "Generated SQL" tab and its
  engine (`sql/generate.ts`, `sql/expr.ts`) were removed. This is a viewer —
  kept deliberately light. The Transformation tab still surfaces any raw SQL
  override (Sql Query, Lookup Sql Override) and labels itself
  "Transformation · SQL override" when one is present.
- **Router group conditions.** Router output-group filter conditions are read
  from the `GROUP` element's `EXPRESSION` attribute (per powrmart.dtd), not a
  TABLEATTRIBUTE. `routerGroupCondition()` in `sql/catalog.ts` keeps the old
  `"<group> Group Filter Condition"` TABLEATTRIBUTE as a fallback. The
  generator now emits realistic Router XML (per-group `EXPRESSION` + a trailing
  `DEFAULT1` catch-all group).

## Known gaps / next milestones

- **M3 — Field-level lineage highlight on the graph.** Click a target column →
  highlight the upstream path through CONNECTORs back to the originating source
  column. Backend (connector tables) already exists; UI pending.
- **M-bundle — Code-split elkjs + @xyflow/react** into a lazy chunk (currently
  ~1.9 MB bundle). Deferred; bundle is acceptable for now.
- **M6 — Multi-file / multi-repository import.** Load several Powermart XML
  files into one model, letting shortcuts resolve across files. Requires
  rethinking `SelectedObject`'s folder scoping and the sidebar grouping.

## Sharing the project

`viewer/node_modules` is ~91 MB and recreateable — exclude it when sharing.
Actual project payload is ~600 KB.

```
# Tarball:
tar --exclude='powermart/viewer/node_modules' \
    --exclude='powermart/viewer/dist' \
    --exclude='powermart/viewer/.vite' \
    -czf powermart.tgz powermart/
# Then on the other machine: extract, `cd viewer && npm install && npm run dev`.
```

Git-based sharing works out of the box — `viewer/.gitignore` already excludes
`node_modules`, `dist`, `.vite`.
