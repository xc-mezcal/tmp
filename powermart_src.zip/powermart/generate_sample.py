#!/usr/bin/env python3
"""Generate a realistic Informatica PowerMart (powrmart.dtd) XML export.

Structure:
  Folder SHARED_METADATA   -> only SOURCE + TARGET definitions (relational + flat file)
  Folder EDW_CORE          -> reusable TRANSFORMATIONs (one per type), SHORTCUTs to
                              the shared folder, several MAPPINGs (including one large
                              mapping that exercises most transformation types), plus
                              a WORKFLOW with SESSIONs.

Use --scale N to multiply mapping/transformation counts. scale=1 emits ~8k lines;
scale=25 lands around ~200k lines. Generated XML references powrmart.dtd.
"""

import argparse
import sys
from contextlib import contextmanager
from datetime import datetime


# ============================================================
# XML writer
# ============================================================

class W:
    def __init__(self, fh):
        self.fh = fh
        self.d = 0

    @staticmethod
    def _esc(s):
        return (s.replace("&", "&amp;").replace('"', "&quot;")
                 .replace("<", "&lt;").replace(">", "&gt;"))

    def _attrs(self, kw):
        out = []
        for k, v in kw.items():
            if v is None:
                continue
            out.append(f' {k}="{self._esc(str(v))}"')
        return "".join(out)

    def line(self, s):
        self.fh.write("    " * self.d + s + "\n")

    def raw(self, s):
        self.fh.write(s)

    @contextmanager
    def tag(self, name, **kw):
        self.line(f"<{name}{self._attrs(kw)}>")
        self.d += 1
        try:
            yield
        finally:
            self.d -= 1
            self.line(f"</{name}>")

    def empty(self, name, **kw):
        self.line(f"<{name}{self._attrs(kw)}/>")


# ============================================================
# Reference metadata
# ============================================================

REL_SOURCES = [
    # (name, dbname, dbtype, fields[ (name, dt, prec, scale, keytype, nullable) ])
    ("HR_EMPLOYEE", "HR_DB", "Oracle", [
        ("EMP_ID",         "number",    10, 0, "PRIMARY KEY", "NOTNULL"),
        ("FIRST_NAME",     "string",    50, 0, "",            "NULL"),
        ("LAST_NAME",      "string",    50, 0, "",            "NULL"),
        ("EMAIL",          "string",   100, 0, "",            "NULL"),
        ("HIRE_DATE",      "date/time", 19, 0, "",            "NULL"),
        ("DEPT_ID",        "number",    10, 0, "FOREIGN KEY", "NULL"),
        ("MGR_ID",         "number",    10, 0, "",            "NULL"),
        ("SALARY",         "number",    15, 2, "",            "NULL"),
        ("COMMISSION_PCT", "number",     5, 2, "",            "NULL"),
        ("JOB_ID",         "string",    20, 0, "",            "NULL"),
        ("STATUS",         "string",     1, 0, "",            "NULL"),
        ("LAST_UPDATE",    "date/time", 19, 0, "",            "NULL"),
    ]),
    ("HR_DEPARTMENT", "HR_DB", "Oracle", [
        ("DEPT_ID",     "number", 10, 0, "PRIMARY KEY", "NOTNULL"),
        ("DEPT_NAME",   "string", 80, 0, "",            "NULL"),
        ("LOCATION_ID", "number", 10, 0, "",            "NULL"),
        ("MGR_ID",      "number", 10, 0, "",            "NULL"),
        ("COST_CENTER", "string", 20, 0, "",            "NULL"),
    ]),
    ("FIN_PAYROLL_TXN", "FIN_DB", "Teradata", [
        ("TXN_ID",     "number",    18, 0, "PRIMARY KEY", "NOTNULL"),
        ("EMP_ID",     "number",    10, 0, "FOREIGN KEY", "NOTNULL"),
        ("PAY_PERIOD", "string",     7, 0, "",            "NULL"),
        ("GROSS_PAY",  "number",    15, 2, "",            "NULL"),
        ("NET_PAY",    "number",    15, 2, "",            "NULL"),
        ("TAX_AMOUNT", "number",    15, 2, "",            "NULL"),
        ("BONUS",      "number",    15, 2, "",            "NULL"),
        ("PAY_DATE",   "date/time", 19, 0, "",            "NULL"),
        ("CURRENCY",   "string",     3, 0, "",            "NULL"),
        ("STATUS",     "string",    10, 0, "",            "NULL"),
    ]),
]

FLAT_SOURCES = [
    ("FF_DAILY_EXCEPTIONS", [
        ("RECORD_TYPE", "string",   2, 0),
        ("EMP_ID",      "string",  10, 0),
        ("REASON_CODE", "string",  20, 0),
        ("DESCRIPTION", "string", 200, 0),
        ("REPORTED_AT", "string",  19, 0),
    ]),
]

TARGETS = [
    ("DW_DIM_EMPLOYEE", "Oracle", [
        ("EMP_SK",         "number",    18, 0, "PRIMARY KEY", "NOTNULL"),
        ("EMP_ID",         "number",    10, 0, "",            "NOTNULL"),
        ("FULL_NAME",      "string",   120, 0, "",            "NULL"),
        ("EMAIL",          "string",   100, 0, "",            "NULL"),
        ("DEPT_SK",        "number",    18, 0, "FOREIGN KEY", "NULL"),
        ("HIRE_DATE",      "date/time", 19, 0, "",            "NULL"),
        ("EFFECTIVE_FROM", "date/time", 19, 0, "",            "NULL"),
        ("EFFECTIVE_TO",   "date/time", 19, 0, "",            "NULL"),
        ("IS_CURRENT",     "string",     1, 0, "",            "NULL"),
        ("LOAD_DTS",       "date/time", 19, 0, "",            "NULL"),
    ]),
    ("DW_DIM_DEPARTMENT", "Oracle", [
        ("DEPT_SK",     "number",    18, 0, "PRIMARY KEY", "NOTNULL"),
        ("DEPT_ID",     "number",    10, 0, "",            "NOTNULL"),
        ("DEPT_NAME",   "string",    80, 0, "",            "NULL"),
        ("COST_CENTER", "string",    20, 0, "",            "NULL"),
        ("LOAD_DTS",    "date/time", 19, 0, "",            "NULL"),
    ]),
    ("DW_FACT_PAYROLL", "Oracle", [
        ("PAYROLL_SK", "number",    18, 0, "PRIMARY KEY", "NOTNULL"),
        ("EMP_SK",     "number",    18, 0, "FOREIGN KEY", "NOTNULL"),
        ("DEPT_SK",    "number",    18, 0, "FOREIGN KEY", "NULL"),
        ("PAY_PERIOD", "string",     7, 0, "",            "NULL"),
        ("GROSS_PAY",  "number",    15, 2, "",            "NULL"),
        ("NET_PAY",    "number",    15, 2, "",            "NULL"),
        ("TAX_AMOUNT", "number",    15, 2, "",            "NULL"),
        ("BONUS",      "number",    15, 2, "",            "NULL"),
        ("TOTAL_COMP", "number",    15, 2, "",            "NULL"),
        ("CURRENCY",   "string",     3, 0, "",            "NULL"),
        ("PAY_DATE",   "date/time", 19, 0, "",            "NULL"),
        ("LOAD_DTS",   "date/time", 19, 0, "",            "NULL"),
    ]),
    ("DW_FACT_PAYROLL_ERROR", "Oracle", [
        ("ERR_ID",         "number",    18, 0, "PRIMARY KEY", "NOTNULL"),
        ("EMP_ID",         "number",    10, 0, "",            "NULL"),
        ("ERR_REASON",     "string",   255, 0, "",            "NULL"),
        ("SOURCE_PAYLOAD", "string",  4000, 0, "",            "NULL"),
        ("LOAD_DTS",       "date/time", 19, 0, "",            "NULL"),
    ]),
]


# ============================================================
# Writers: SOURCE, TARGET
# ============================================================

def write_source_rel(w, name, dbname, db_type, fields):
    with w.tag("SOURCE",
               BUSINESSNAME="", DATABASETYPE=db_type,
               DBDNAME=dbname, DESCRIPTION=f"Relational source {name}",
               NAME=name, OBJECTVERSION="1", OWNERNAME=dbname,
               VERSIONNUMBER="1"):
        for i, (fn, dt, p, s, k, nn) in enumerate(fields, 1):
            w.empty("SOURCEFIELD",
                    BUSINESSNAME="", DATATYPE=dt, DESCRIPTION="",
                    FIELDNUMBER=i, FIELDPROPERTY="0", FIELDTYPE="ELEMITEM",
                    HIDDEN="NO", KEYTYPE=k, LENGTH="0", LEVEL="0", NAME=fn,
                    NULLABLE=nn, OCCURS="0", OFFSET="0",
                    PHYSICALLENGTH="0", PHYSICALOFFSET="0", PICTURETEXT="",
                    PRECISION=p, SCALE=s, SOURCEFIELDTYPE="DB_COLUMN",
                    USAGE_FLAGS="")
        w.empty("TABLEATTRIBUTE", NAME="Owner Name", VALUE=dbname)


def write_source_flat(w, name, fields):
    with w.tag("SOURCE",
               BUSINESSNAME="", DATABASETYPE="Flat File", DBDNAME=name,
               DESCRIPTION=f"Flat file source {name}", NAME=name,
               OBJECTVERSION="1", OWNERNAME="", VERSIONNUMBER="1"):
        w.empty("FLATFILE",
                CODEPAGE="UTF-8", CONSECDELIMITERSASONE="NO",
                DELIMITED="YES", DELIMITERS=",",
                ESCAPE_CHARACTER="\\", KEEPESCAPECHAR="NO",
                LINESEQUENTIAL="NO", MULTIDELIMITERSASAND="NO",
                NULLCHARTYPE="ASCII", NULLCHARACTER="*", PADBYTES="1",
                QUOTE_CHARACTER="DOUBLE", REPEATABLE="NO", ROWDELIMITER="0",
                SHIFTSENSITIVEDATA="NO", SKIPROWS="1",
                STRIPTRAILINGBLANKS="NO")
        for i, (fn, dt, p, s) in enumerate(fields, 1):
            w.empty("SOURCEFIELD",
                    BUSINESSNAME="", DATATYPE=dt, DESCRIPTION="",
                    FIELDNUMBER=i, FIELDPROPERTY="0", FIELDTYPE="ELEMITEM",
                    HIDDEN="NO", KEYTYPE="", LENGTH="0", LEVEL="0", NAME=fn,
                    NULLABLE="NULL", OCCURS="0", OFFSET="0",
                    PHYSICALLENGTH="0", PHYSICALOFFSET="0", PICTURETEXT="",
                    PRECISION=p, SCALE=s, SOURCEFIELDTYPE="FLAT_FILE",
                    USAGE_FLAGS="")


def write_target(w, name, db_type, fields):
    with w.tag("TARGET",
               BUSINESSNAME="", CONSTRAINT="", CREATIONDATE=datetime.now().strftime("%m/%d/%Y %H:%M:%S"),
               DATABASETYPE=db_type, DESCRIPTION=f"Target table {name}",
               NAME=name, OBJECTVERSION="1", TABLEOPTIONS="", VERSIONNUMBER="1"):
        for i, (fn, dt, p, s, k, nn) in enumerate(fields, 1):
            w.empty("TARGETFIELD",
                    BUSINESSNAME="", DATATYPE=dt, DESCRIPTION="",
                    FIELDNUMBER=i, FIELDPROPERTY="0", KEYTYPE=k, NAME=fn,
                    NULLABLE=nn, PHYSICALLENGTH="0", PHYSICALOFFSET="0",
                    PICTURETEXT="", PRECISION=p, SCALE=s)


# ============================================================
# Transformations — one writer per type
# ============================================================

def _tfield(w, name, porttype, dt, prec, scale, expression=None, **extra):
    w.empty("TRANSFORMFIELD",
            NAME=name, PORTTYPE=porttype, DATATYPE=dt,
            PRECISION=prec, SCALE=scale,
            EXPRESSION=expression or "", EXPRESSIONTYPE="GENERAL",
            DEFAULTVALUE="", DESCRIPTION="",
            PICTURETEXT="", **extra)


def _tattr(w, name, value):
    w.empty("TABLEATTRIBUTE", NAME=name, VALUE=value)


def write_source_qualifier(w, name, source_name, sql_override="", user_join="", filter_cond=""):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Source Qualifier for {source_name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO", TYPE="Source Qualifier",
               VERSIONNUMBER="1"):
        _tattr(w, "Sql Query", sql_override)
        _tattr(w, "User Defined Join", user_join)
        _tattr(w, "Source Filter", filter_cond)
        _tattr(w, "Number Of Sorted Ports", "0")
        _tattr(w, "Tracing Level", "Normal")
        _tattr(w, "Select Distinct", "NO")
        _tattr(w, "Is Partitionable", "NO")
        _tattr(w, "Pre SQL", "")
        _tattr(w, "Post SQL", "")


def write_expression(w, name, in_fields, out_fields, reusable="NO"):
    """out_fields: list of (name, dt, prec, scale, expr)"""
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Expression {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE=reusable, TYPE="Expression",
               VERSIONNUMBER="1"):
        for fn, dt, p, s in in_fields:
            _tfield(w, fn, "INPUT", dt, p, s)
        for fn, dt, p, s, expr in out_fields:
            _tfield(w, fn, "OUTPUT", dt, p, s, expression=expr)
        _tattr(w, "Tracing Level", "Normal")


def write_filter(w, name, in_fields, condition):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Filter {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO", TYPE="Filter",
               VERSIONNUMBER="1"):
        for fn, dt, p, s in in_fields:
            _tfield(w, fn, "INPUT/OUTPUT", dt, p, s)
        _tattr(w, "Filter Condition", condition)
        _tattr(w, "Tracing Level", "Normal")


def write_aggregator(w, name, in_fields, out_fields, group_by):
    """group_by: list of field names from in_fields used as GROUP BY keys."""
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Aggregator {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO", TYPE="Aggregator",
               VERSIONNUMBER="1"):
        for fn, dt, p, s in in_fields:
            _tfield(w, fn, "INPUT", dt, p, s,
                    ISGROUPBY="YES" if fn in group_by else "NO")
        for fn, dt, p, s, expr in out_fields:
            _tfield(w, fn, "OUTPUT", dt, p, s, expression=expr, ISGROUPBY="NO")
        _tattr(w, "Cache Directory", "$PMCacheDir")
        _tattr(w, "Tracing Level", "Normal")
        _tattr(w, "Sorted Input", "NO")
        _tattr(w, "Aggregator Data Cache Size", "Auto")
        _tattr(w, "Aggregator Index Cache Size", "Auto")
        _tattr(w, "Transformation Scope", "All Input")


def write_joiner(w, name, master_fields, detail_fields, out_fields,
                 join_condition, join_type="Normal Join"):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Joiner {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO", TYPE="Joiner",
               VERSIONNUMBER="1"):
        with w.tag("GROUP", DESCRIPTION="", NAME="MASTER", ORDER="0", TYPE="INPUT"):
            pass
        with w.tag("GROUP", DESCRIPTION="", NAME="DETAIL", ORDER="1", TYPE="INPUT"):
            pass
        for fn, dt, p, s in master_fields:
            _tfield(w, fn, "INPUT", dt, p, s, GROUP="MASTER")
        for fn, dt, p, s in detail_fields:
            _tfield(w, fn, "INPUT", dt, p, s, GROUP="DETAIL")
        for fn, dt, p, s, expr in out_fields:
            _tfield(w, fn, "OUTPUT", dt, p, s, expression=expr or "")
        _tattr(w, "Case Sensitive String Comparison", "YES")
        _tattr(w, "Cache Directory", "$PMCacheDir")
        _tattr(w, "Join Condition", join_condition)
        _tattr(w, "Join Type", join_type)
        _tattr(w, "Null ordering in master", "Null Is Highest Value")
        _tattr(w, "Null ordering in detail", "Null Is Highest Value")
        _tattr(w, "Joiner Data Cache Size", "Auto")
        _tattr(w, "Joiner Index Cache Size", "Auto")
        _tattr(w, "Sorted Input", "NO")
        _tattr(w, "Tracing Level", "Normal")


def write_lookup(w, name, lookup_table, in_fields, lookup_fields, return_fields,
                 sql_override, lookup_condition, connected=True):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Lookup {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO",
               TYPE="Lookup Procedure", VERSIONNUMBER="1"):
        for fn, dt, p, s in in_fields:
            _tfield(w, fn, "INPUT", dt, p, s)
        for fn, dt, p, s in lookup_fields:
            _tfield(w, fn, "LOOKUP", dt, p, s)
        for fn, dt, p, s in return_fields:
            port = "OUTPUT" if connected else "RETURN"
            _tfield(w, fn, port, dt, p, s)
        _tattr(w, "Lookup table name", lookup_table)
        _tattr(w, "Lookup Sql Override", sql_override)
        _tattr(w, "Lookup condition", lookup_condition)
        _tattr(w, "Lookup caching enabled", "YES")
        _tattr(w, "Lookup cache directory name", "$PMCacheDir")
        _tattr(w, "Lookup policy on multiple match", "Use First Value")
        _tattr(w, "Connection Information", "$Source")
        _tattr(w, "Lookup source is static", "YES")
        _tattr(w, "Re-cache from lookup source", "NO")
        _tattr(w, "Lookup Data Cache Size", "Auto")
        _tattr(w, "Lookup Index Cache Size", "Auto")
        _tattr(w, "Tracing Level", "Normal")


def write_router(w, name, in_fields, groups):
    """groups: list of (group_name, filter_expr). INPUT group implicit.
    Each custom group fans out all in_fields as OUTPUT.

    Per powrmart.dtd, a Router output group's filter condition lives on the
    GROUP element's EXPRESSION attribute -- not in a TABLEATTRIBUTE. A trailing
    DEFAULT output group (no EXPRESSION) catches rows matching no other group.
    """
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Router {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO", TYPE="Router",
               VERSIONNUMBER="1"):
        with w.tag("GROUP", DESCRIPTION="", NAME="INPUT", ORDER="0", TYPE="INPUT"):
            pass
        for i, (gn, expr) in enumerate(groups, 1):
            with w.tag("GROUP", DESCRIPTION="", EXPRESSION=expr,
                       NAME=gn, ORDER=i, TYPE="OUTPUT"):
                pass
        with w.tag("GROUP", DESCRIPTION="", NAME="DEFAULT1",
                   ORDER=len(groups) + 1, TYPE="OUTPUT"):
            pass
        for fn, dt, p, s in in_fields:
            _tfield(w, fn, "INPUT", dt, p, s, GROUP="INPUT")
            for gn, _expr in groups:
                _tfield(w, fn, "OUTPUT", dt, p, s, GROUP=gn)
            _tfield(w, fn, "OUTPUT", dt, p, s, GROUP="DEFAULT1")
        _tattr(w, "Tracing Level", "Normal")


def write_update_strategy(w, name, in_fields, expr):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Update Strategy {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO",
               TYPE="Update Strategy", VERSIONNUMBER="1"):
        for fn, dt, p, s in in_fields:
            _tfield(w, fn, "INPUT/OUTPUT", dt, p, s)
        _tattr(w, "Update Strategy Expression", expr)
        _tattr(w, "Forward Rejected Rows", "YES")
        _tattr(w, "Tracing Level", "Normal")


def write_sequence_generator(w, name, start=1, increment=1):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Sequence Generator {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO",
               TYPE="Sequence", VERSIONNUMBER="1"):
        _tfield(w, "NEXTVAL", "OUTPUT", "number", 10, 0)
        _tfield(w, "CURRVAL", "OUTPUT", "number", 10, 0)
        _tattr(w, "Start Value", str(start))
        _tattr(w, "Increment By", str(increment))
        _tattr(w, "End Value", "9223372036854775807")
        _tattr(w, "Current Value", str(start))
        _tattr(w, "Cycle", "NO")
        _tattr(w, "Number of Cached Values", "1000")
        _tattr(w, "Reset", "NO")
        _tattr(w, "Tracing Level", "Normal")


def write_rank(w, name, in_fields, rank_field, group_by, top_or_bottom="Top", n_ranks=10):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Rank {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO", TYPE="Rank",
               VERSIONNUMBER="1"):
        for fn, dt, p, s in in_fields:
            _tfield(w, fn, "INPUT/OUTPUT", dt, p, s,
                    ISGROUPBY="YES" if fn in group_by else "NO",
                    ISPARTITION="NO",
                    RANKINDEX="YES" if fn == rank_field else "NO")
        _tfield(w, "RANKINDEX", "OUTPUT", "number", 10, 0)
        _tattr(w, "Cache Directory", "$PMCacheDir")
        _tattr(w, "Top/Bottom", top_or_bottom)
        _tattr(w, "Number Of Ranks", str(n_ranks))
        _tattr(w, "Rank Data Cache Size", "Auto")
        _tattr(w, "Rank Index Cache Size", "Auto")
        _tattr(w, "Tracing Level", "Normal")


def write_sorter(w, name, in_fields, sort_keys):
    """sort_keys: list of (field_name, 'ASCENDING'|'DESCENDING')"""
    keymap = dict(sort_keys)
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Sorter {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO", TYPE="Sorter",
               VERSIONNUMBER="1"):
        for fn, dt, p, s in in_fields:
            _tfield(w, fn, "INPUT/OUTPUT", dt, p, s,
                    SORTKEY="YES" if fn in keymap else "NO",
                    SORTDIRECTION=keymap.get(fn, "ASCENDING"))
        _tattr(w, "Sorter Cache Size", "Auto")
        _tattr(w, "Case Sensitive", "YES")
        _tattr(w, "Work Directory", "$PMTempDir")
        _tattr(w, "Distinct", "NO")
        _tattr(w, "Tracing Level", "Normal")
        _tattr(w, "Null Treated Low", "NO")


def write_union(w, name, fields, n_inputs=2):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Union {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO",
               TEMPLATENAME="Union Transformation",
               TYPE="Custom Transformation", VERSIONNUMBER="1"):
        for i in range(n_inputs):
            with w.tag("GROUP", DESCRIPTION="", NAME=f"INPUT_GROUP_{i+1}",
                       ORDER=str(i), TYPE="INPUT"):
                pass
        with w.tag("GROUP", DESCRIPTION="", NAME="OUTPUT_GROUP",
                   ORDER=str(n_inputs), TYPE="OUTPUT"):
            pass
        for i in range(n_inputs):
            for fn, dt, p, s in fields:
                _tfield(w, fn, "INPUT", dt, p, s, GROUP=f"INPUT_GROUP_{i+1}")
        for fn, dt, p, s in fields:
            _tfield(w, fn, "OUTPUT", dt, p, s, GROUP="OUTPUT_GROUP")
        _tattr(w, "Tracing Level", "Normal")


def write_normalizer(w, name, occurs_field, occurs_count=3):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Normalizer {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO",
               TYPE="Normalizer", VERSIONNUMBER="1"):
        _tfield(w, "ID", "INPUT", "number", 10, 0)
        for i in range(1, occurs_count + 1):
            _tfield(w, f"{occurs_field}{i}", "INPUT", "number", 15, 2)
        _tfield(w, "ID_OUT", "OUTPUT", "number", 10, 0)
        _tfield(w, f"{occurs_field}_OUT", "OUTPUT", "number", 15, 2)
        _tfield(w, "GK_COLUMN", "OUTPUT", "number", 19, 0)
        _tfield(w, "GCID_COLUMN", "OUTPUT", "number", 10, 0)
        _tattr(w, "Reset", "NO")
        _tattr(w, "Restart", "NO")
        _tattr(w, "Tracing Level", "Normal")


def write_stored_procedure(w, name):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Stored Procedure {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO",
               TYPE="Stored Procedure", VERSIONNUMBER="1"):
        _tfield(w, "IN_EMP_ID", "INPUT", "number", 10, 0)
        _tfield(w, "IN_PAY_DATE", "INPUT", "date/time", 19, 0)
        _tfield(w, "RETURN_VALUE", "RETURN/OUTPUT", "number", 15, 2)
        _tattr(w, "Call Text", "CALL AUDIT_PKG.LOG_PAYROLL(?, ?, ?)")
        _tattr(w, "Stored Procedure Type", "Normal")
        _tattr(w, "Connection Information", "$Target")
        _tattr(w, "Execution Order", "0")
        _tattr(w, "Tracing Level", "Normal")
        _tattr(w, "Input Row Type", "INSERT")


def write_sql_transformation(w, name):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"SQL Transformation {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO",
               TYPE="SQL Transformation", VERSIONNUMBER="1"):
        _tfield(w, "EMP_ID", "INPUT", "number", 10, 0)
        _tfield(w, "SQL_Error", "OUTPUT", "string", 2000, 0)
        _tfield(w, "NumRowsAffected", "OUTPUT", "number", 10, 0)
        _tattr(w, "SQL Mode", "Script")
        _tattr(w, "Database Type", "Oracle")
        _tattr(w, "Connection Type", "Dynamic")
        _tattr(w, "Script",
               "UPDATE stg_payroll SET processed_flag='Y' WHERE emp_id = ?EMP_ID?;")
        _tattr(w, "Auto Commit", "YES")
        _tattr(w, "Tracing Level", "Normal")


def write_transaction_control(w, name, in_fields, condition):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Transaction Control {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="NO",
               TYPE="Transaction Control", VERSIONNUMBER="1"):
        for fn, dt, p, s in in_fields:
            _tfield(w, fn, "INPUT/OUTPUT", dt, p, s)
        _tattr(w, "Transaction Control Condition", condition)
        _tattr(w, "Tracing Level", "Normal")


def write_java_transformation(w, name):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Java Transformation {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="YES",
               TYPE="Java Transformation", VERSIONNUMBER="1"):
        _tfield(w, "IN_PAYLOAD", "INPUT", "string", 4000, 0)
        _tfield(w, "OUT_JSON", "OUTPUT", "string", 4000, 0)
        with w.tag("GROUP", DESCRIPTION="", NAME="INPUT", ORDER="0", TYPE="INPUT"):
            pass
        with w.tag("GROUP", DESCRIPTION="", NAME="OUTPUT", ORDER="1", TYPE="OUTPUT"):
            pass
        w.empty("INITPROP", NAME="ModuleIdentifier", VALUE=f"JTX_{name}")
        w.empty("INITPROP", NAME="IsActive", VALUE="YES")
        w.empty("INITPROP", NAME="Runtime Location", VALUE="$PMJavaDir")
        w.empty("INITPROP", NAME="ClassName", VALUE=f"com.acme.etl.{name}")
        w.empty("INITPROP", NAME="Import Packages",
                VALUE="import java.util.*; import com.fasterxml.jackson.databind.*;")
        w.empty("INITPROP", NAME="Helpers", VALUE="")
        w.empty("INITPROP", NAME="On Input Row",
                VALUE=("ObjectMapper m = new ObjectMapper(); "
                       "Map<String,Object> o = m.readValue(IN_PAYLOAD, Map.class); "
                       "OUT_JSON = m.writeValueAsString(o); generateRow();"))
        w.empty("INITPROP", NAME="On End Of Data", VALUE="")
        _tattr(w, "Tracing Level", "Normal")


def write_external_procedure(w, name):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"External Procedure {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="YES",
               TYPE="External Procedure", VERSIONNUMBER="1"):
        _tfield(w, "IN_KEY", "INPUT", "string", 40, 0)
        _tfield(w, "OUT_HASH", "OUTPUT", "string", 64, 0)
        _tattr(w, "Module/Program Name", "libacmehash.so")
        _tattr(w, "Procedure Name", "sha256_of")
        _tattr(w, "Runtime Location", "$PMExtProcDir")
        _tattr(w, "Output is Deterministic", "YES")
        _tattr(w, "Output is Repeatable", "ALWAYS")
        _tattr(w, "Tracing Level", "Normal")


def write_http_transformation(w, name):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"HTTP {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="YES",
               TYPE="HTTP Transformation", VERSIONNUMBER="1"):
        _tfield(w, "IN_EMP_ID", "INPUT", "number", 10, 0)
        _tfield(w, "OUT_RESPONSE", "OUTPUT", "string", 8000, 0)
        _tfield(w, "OUT_STATUS", "OUTPUT", "number", 5, 0)
        _tattr(w, "Base URL", "https://api.internal.example.com/v1/employee")
        _tattr(w, "HTTP Method", "GET")
        _tattr(w, "Authentication Type", "None")
        _tattr(w, "Connection Timeout", "30")
        _tattr(w, "Tracing Level", "Normal")


def write_web_services_consumer(w, name):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Web Services Consumer {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="YES",
               TYPE="Web Services Consumer", VERSIONNUMBER="1"):
        _tfield(w, "IN_REQUEST", "INPUT", "string", 8000, 0)
        _tfield(w, "OUT_RESPONSE", "OUTPUT", "string", 8000, 0)
        _tattr(w, "WSDL URL", "https://soap.internal.example.com/PayrollService?wsdl")
        _tattr(w, "Operation", "getPayrollSummary")
        _tattr(w, "End Point URL",
               "https://soap.internal.example.com/PayrollService")
        _tattr(w, "Tracing Level", "Normal")


def write_unstructured_data(w, name):
    with w.tag("TRANSFORMATION", DESCRIPTION=f"Unstructured Data {name}",
               NAME=name, OBJECTVERSION="1", REUSABLE="YES",
               TYPE="Unstructured Data Transformation", VERSIONNUMBER="1"):
        _tfield(w, "IN_DOCUMENT", "INPUT", "binary", 104857600, 0)
        _tfield(w, "OUT_TEXT", "OUTPUT", "string", 65535, 0)
        _tattr(w, "Service Name", "UDT_PDFExtract")
        _tattr(w, "Output Type", "Structured")
        _tattr(w, "Tracing Level", "Normal")


# ============================================================
# Build the reusable transformation catalogue for Folder 2
# ============================================================

def write_reusable_transformations(w):
    # Reusable Expression: Bonus calculation
    write_expression(w, "EXP_Calc_Bonus",
                     in_fields=[("BASE_SALARY", "number", 15, 2),
                                ("COMMISSION_PCT", "number", 5, 2),
                                ("STATUS", "string", 1, 0)],
                     out_fields=[("BONUS", "number", 15, 2,
                                  "IIF(STATUS='A', BASE_SALARY * IIF(ISNULL(COMMISSION_PCT),0.10,COMMISSION_PCT), 0)"),
                                 ("IS_ELIGIBLE", "string", 1, 0,
                                  "DECODE(STATUS,'A','Y','T','N','N')")],
                     reusable="YES")
    # Reusable Java
    write_java_transformation(w, "JTX_Parse_Event_JSON")
    # Reusable External Procedure
    write_external_procedure(w, "EXT_Hash_SHA256")
    # Reusable HTTP
    write_http_transformation(w, "HTTP_Employee_Lookup")
    # Reusable Web Services
    write_web_services_consumer(w, "WSC_Payroll_Summary")
    # Reusable Unstructured
    write_unstructured_data(w, "UDT_PDF_Extract")
    # Reusable Normalizer
    write_normalizer(w, "NRM_Quarterly_Sales", occurs_field="Q", occurs_count=4)


# ============================================================
# Mapping — the big one
# ============================================================

def write_big_mapping(w, mapping_name):
    with w.tag("MAPPING", DESCRIPTION=f"{mapping_name}: full ETL from HR+FIN to DW_FACT_PAYROLL",
               ISVALID="YES", NAME=mapping_name, OBJECTVERSION="1",
               VERSIONNUMBER="1"):

        # Mapping variables
        w.empty("MAPPINGVARIABLE", AGGREGATIONTYPE="MAX",
                DATATYPE="date/time", DEFAULTVALUE="01/01/1900 00:00:00",
                DESCRIPTION="High-water mark for incremental load",
                ISEXPRESSIONVARIABLE="NO", NAME="$$LastRunDate",
                PRECISION=19, SCALE=0, USERDEFINED="YES")
        w.empty("MAPPINGVARIABLE", AGGREGATIONTYPE="MAX",
                DATATYPE="string", DEFAULTVALUE="INIT",
                DESCRIPTION="Current batch identifier",
                ISEXPRESSIONVARIABLE="NO", NAME="$$BatchId",
                PRECISION=36, SCALE=0, USERDEFINED="YES")

        # ---- Non-reusable TRANSFORMATIONs inside this MAPPING ----

        # Source Qualifier over HR_EMPLOYEE + HR_DEPARTMENT with SQL override
        write_source_qualifier(
            w, "SQ_Employee_Dept", "HR_EMPLOYEE",
            sql_override=(
                "SELECT e.EMP_ID, e.FIRST_NAME, e.LAST_NAME, e.EMAIL, e.HIRE_DATE, "
                "e.DEPT_ID, e.SALARY, e.COMMISSION_PCT, e.STATUS, e.LAST_UPDATE, "
                "d.DEPT_NAME, d.COST_CENTER "
                "FROM HR.HR_EMPLOYEE e LEFT OUTER JOIN HR.HR_DEPARTMENT d "
                "ON e.DEPT_ID = d.DEPT_ID "
                "WHERE e.LAST_UPDATE > TO_DATE('$$LastRunDate','MM/DD/YYYY HH24:MI:SS')"),
            user_join="",
            filter_cond="")
        # Project SQ fields
        with w.tag("TRANSFORMATION", DESCRIPTION="SQ_Employee_Dept fields",
                   NAME="SQ_Employee_Dept_FIELDS", OBJECTVERSION="1",
                   REUSABLE="NO", TYPE="Source Qualifier", VERSIONNUMBER="1"):
            pass  # placeholder — fields are declared on the main SQ above in a real export

        # Source Qualifier for payroll
        write_source_qualifier(
            w, "SQ_Payroll", "FIN_PAYROLL_TXN",
            sql_override="",
            user_join="",
            filter_cond="STATUS = 'POSTED'")

        # Expression: cleaning
        write_expression(w, "EXP_Clean",
            in_fields=[("EMP_ID", "number", 10, 0),
                       ("FIRST_NAME", "string", 50, 0),
                       ("LAST_NAME", "string", 50, 0),
                       ("EMAIL", "string", 100, 0),
                       ("SALARY", "number", 15, 2),
                       ("COMMISSION_PCT", "number", 5, 2),
                       ("STATUS", "string", 1, 0),
                       ("DEPT_NAME", "string", 80, 0)],
            out_fields=[
                ("EMP_ID_O",     "number", 10, 0, "EMP_ID"),
                ("FULL_NAME",    "string", 120, 0,
                 "LTRIM(RTRIM(INITCAP(FIRST_NAME))) || ' ' || LTRIM(RTRIM(UPPER(LAST_NAME)))"),
                ("EMAIL_NORM",   "string", 100, 0,
                 "LOWER(LTRIM(RTRIM(EMAIL)))"),
                ("SALARY_CLEAN", "number", 15, 2,
                 "IIF(ISNULL(SALARY) OR SALARY<0, 0, SALARY)"),
                ("COMM_CLEAN",   "number", 5, 2,
                 "IIF(ISNULL(COMMISSION_PCT), 0.10, COMMISSION_PCT)"),
                ("STATUS_O",     "string", 1, 0, "STATUS"),
                ("DEPT_NAME_O",  "string", 80, 0, "DEPT_NAME"),
                ("IS_VIP",       "string", 1, 0,
                 "DECODE(TRUE, SALARY>200000,'Y', SALARY>100000 AND DEPT_NAME='EXECUTIVE','Y', 'N')"),
            ])

        # Lookup against DW_DIM_DEPARTMENT
        write_lookup(
            w, "LKP_Dept",
            lookup_table="DW.DW_DIM_DEPARTMENT",
            in_fields=[("IN_DEPT_NAME", "string", 80, 0)],
            lookup_fields=[("DEPT_SK", "number", 18, 0),
                           ("DEPT_ID", "number", 10, 0),
                           ("DEPT_NAME", "string", 80, 0)],
            return_fields=[("O_DEPT_SK", "number", 18, 0)],
            sql_override=(
                "SELECT DEPT_SK, DEPT_ID, DEPT_NAME FROM DW.DW_DIM_DEPARTMENT "
                "WHERE LOAD_DTS >= SYSDATE - 30"),
            lookup_condition="DEPT_NAME = IN_DEPT_NAME")

        # Sorter before Joiner (for sorted input optimization)
        write_sorter(w, "SRT_ByEmpId",
            in_fields=[("EMP_ID", "number", 10, 0),
                       ("FULL_NAME", "string", 120, 0),
                       ("EMAIL_NORM", "string", 100, 0),
                       ("SALARY_CLEAN", "number", 15, 2),
                       ("COMM_CLEAN", "number", 5, 2),
                       ("IS_VIP", "string", 1, 0),
                       ("DEPT_SK", "number", 18, 0)],
            sort_keys=[("EMP_ID", "ASCENDING")])

        # Sorter for payroll
        write_sorter(w, "SRT_Payroll_ByEmp",
            in_fields=[("EMP_ID", "number", 10, 0),
                       ("PAY_PERIOD", "string", 7, 0),
                       ("GROSS_PAY", "number", 15, 2),
                       ("NET_PAY", "number", 15, 2),
                       ("TAX_AMOUNT", "number", 15, 2),
                       ("BONUS", "number", 15, 2),
                       ("PAY_DATE", "date/time", 19, 0),
                       ("CURRENCY", "string", 3, 0)],
            sort_keys=[("EMP_ID", "ASCENDING"), ("PAY_PERIOD", "ASCENDING")])

        # Joiner: master=employee, detail=payroll
        write_joiner(w, "JNR_Emp_Payroll",
            master_fields=[("EMP_ID", "number", 10, 0),
                           ("FULL_NAME", "string", 120, 0),
                           ("EMAIL_NORM", "string", 100, 0),
                           ("SALARY_CLEAN", "number", 15, 2),
                           ("COMM_CLEAN", "number", 5, 2),
                           ("IS_VIP", "string", 1, 0),
                           ("DEPT_SK", "number", 18, 0)],
            detail_fields=[("P_EMP_ID", "number", 10, 0),
                           ("PAY_PERIOD", "string", 7, 0),
                           ("GROSS_PAY", "number", 15, 2),
                           ("NET_PAY", "number", 15, 2),
                           ("TAX_AMOUNT", "number", 15, 2),
                           ("P_BONUS", "number", 15, 2),
                           ("PAY_DATE", "date/time", 19, 0),
                           ("CURRENCY", "string", 3, 0)],
            out_fields=[("EMP_ID", "number", 10, 0, ""),
                        ("FULL_NAME", "string", 120, 0, ""),
                        ("EMAIL_NORM", "string", 100, 0, ""),
                        ("SALARY_CLEAN", "number", 15, 2, ""),
                        ("COMM_CLEAN", "number", 5, 2, ""),
                        ("IS_VIP", "string", 1, 0, ""),
                        ("DEPT_SK", "number", 18, 0, ""),
                        ("PAY_PERIOD", "string", 7, 0, ""),
                        ("GROSS_PAY", "number", 15, 2, ""),
                        ("NET_PAY", "number", 15, 2, ""),
                        ("TAX_AMOUNT", "number", 15, 2, ""),
                        ("BONUS_IN", "number", 15, 2, ""),
                        ("PAY_DATE", "date/time", 19, 0, ""),
                        ("CURRENCY", "string", 3, 0, "")],
            join_condition="EMP_ID = P_EMP_ID",
            join_type="Master Outer Join")

        # Aggregator: monthly totals per employee
        write_aggregator(w, "AGG_Monthly",
            in_fields=[("EMP_ID", "number", 10, 0),
                       ("PAY_PERIOD", "string", 7, 0),
                       ("DEPT_SK", "number", 18, 0),
                       ("GROSS_PAY", "number", 15, 2),
                       ("NET_PAY", "number", 15, 2),
                       ("TAX_AMOUNT", "number", 15, 2),
                       ("BONUS_IN", "number", 15, 2),
                       ("CURRENCY", "string", 3, 0),
                       ("FULL_NAME", "string", 120, 0),
                       ("EMAIL_NORM", "string", 100, 0),
                       ("IS_VIP", "string", 1, 0)],
            out_fields=[
                ("O_EMP_ID",     "number", 10, 0, "FIRST(EMP_ID)"),
                ("O_PAY_PERIOD", "string", 7, 0, "FIRST(PAY_PERIOD)"),
                ("O_DEPT_SK",    "number", 18, 0, "FIRST(DEPT_SK)"),
                ("O_FULL_NAME",  "string", 120, 0, "FIRST(FULL_NAME)"),
                ("O_EMAIL",      "string", 100, 0, "FIRST(EMAIL_NORM)"),
                ("O_IS_VIP",     "string", 1, 0, "FIRST(IS_VIP)"),
                ("O_CURRENCY",   "string", 3, 0, "FIRST(CURRENCY)"),
                ("O_GROSS_PAY",  "number", 15, 2, "SUM(GROSS_PAY)"),
                ("O_NET_PAY",    "number", 15, 2, "SUM(NET_PAY)"),
                ("O_TAX_AMOUNT", "number", 15, 2, "SUM(TAX_AMOUNT)"),
                ("O_BONUS",      "number", 15, 2, "SUM(BONUS_IN)"),
                ("O_TOTAL_COMP", "number", 15, 2,
                 "SUM(GROSS_PAY) + SUM(BONUS_IN)"),
            ],
            group_by=["EMP_ID", "PAY_PERIOD"])

        # Rank: top 10 earners per period
        write_rank(w, "RNK_Top_Earners",
            in_fields=[("EMP_ID", "number", 10, 0),
                       ("PAY_PERIOD", "string", 7, 0),
                       ("DEPT_SK", "number", 18, 0),
                       ("FULL_NAME", "string", 120, 0),
                       ("EMAIL", "string", 100, 0),
                       ("IS_VIP", "string", 1, 0),
                       ("CURRENCY", "string", 3, 0),
                       ("GROSS_PAY", "number", 15, 2),
                       ("NET_PAY", "number", 15, 2),
                       ("TAX_AMOUNT", "number", 15, 2),
                       ("BONUS", "number", 15, 2),
                       ("TOTAL_COMP", "number", 15, 2)],
            rank_field="TOTAL_COMP",
            group_by=["PAY_PERIOD"],
            top_or_bottom="Top", n_ranks=10)

        # Filter: only active rows forward (others get audited elsewhere)
        write_filter(w, "FIL_Active",
            in_fields=[("EMP_ID", "number", 10, 0),
                       ("PAY_PERIOD", "string", 7, 0),
                       ("DEPT_SK", "number", 18, 0),
                       ("FULL_NAME", "string", 120, 0),
                       ("EMAIL", "string", 100, 0),
                       ("IS_VIP", "string", 1, 0),
                       ("CURRENCY", "string", 3, 0),
                       ("GROSS_PAY", "number", 15, 2),
                       ("NET_PAY", "number", 15, 2),
                       ("TAX_AMOUNT", "number", 15, 2),
                       ("BONUS", "number", 15, 2),
                       ("TOTAL_COMP", "number", 15, 2),
                       ("RANKINDEX", "number", 10, 0)],
            condition="NOT ISNULL(EMP_ID) AND NET_PAY > 0")

        # Expression to derive PAY_DATE
        write_expression(w, "EXP_Derive_PayDate",
            in_fields=[("PAY_PERIOD", "string", 7, 0)],
            out_fields=[("PAY_DATE_DERIVED", "date/time", 19, 0,
                         "LAST_DAY(TO_DATE(PAY_PERIOD,'YYYY-MM'))")])

        # Sequence generator for surrogate key
        write_sequence_generator(w, "SEQ_Payroll_SK", start=1, increment=1)

        # Router: split valid vs error
        write_router(w, "RTR_Split",
            in_fields=[("EMP_ID", "number", 10, 0),
                       ("PAY_PERIOD", "string", 7, 0),
                       ("DEPT_SK", "number", 18, 0),
                       ("FULL_NAME", "string", 120, 0),
                       ("EMAIL", "string", 100, 0),
                       ("GROSS_PAY", "number", 15, 2),
                       ("NET_PAY", "number", 15, 2),
                       ("TAX_AMOUNT", "number", 15, 2),
                       ("BONUS", "number", 15, 2),
                       ("TOTAL_COMP", "number", 15, 2),
                       ("CURRENCY", "string", 3, 0),
                       ("PAY_DATE", "date/time", 19, 0),
                       ("PAYROLL_SK", "number", 18, 0)],
            groups=[("VALID",
                     "NOT ISNULL(DEPT_SK) AND TOTAL_COMP > 0 AND LENGTH(CURRENCY)=3"),
                    ("ERROR",
                     "ISNULL(DEPT_SK) OR TOTAL_COMP <= 0 OR LENGTH(CURRENCY)<>3")])

        # Update Strategy before target
        write_update_strategy(w, "UPD_Fact_Payroll",
            in_fields=[("PAYROLL_SK", "number", 18, 0),
                       ("EMP_SK", "number", 18, 0),
                       ("DEPT_SK", "number", 18, 0),
                       ("PAY_PERIOD", "string", 7, 0),
                       ("GROSS_PAY", "number", 15, 2),
                       ("NET_PAY", "number", 15, 2),
                       ("TAX_AMOUNT", "number", 15, 2),
                       ("BONUS", "number", 15, 2),
                       ("TOTAL_COMP", "number", 15, 2),
                       ("CURRENCY", "string", 3, 0),
                       ("PAY_DATE", "date/time", 19, 0)],
            expr="IIF(ISNULL(PAYROLL_SK), DD_INSERT, DD_UPDATE)")

        # Transaction Control: commit per PAY_PERIOD boundary
        write_transaction_control(w, "TC_Per_Period",
            in_fields=[("PAY_PERIOD", "string", 7, 0),
                       ("PAYROLL_SK", "number", 18, 0)],
            condition=("IIF(PAY_PERIOD != $PrevPeriod, "
                       "TC_COMMIT_BEFORE, TC_CONTINUE_TRANSACTION)"))

        # Stored Procedure audit
        write_stored_procedure(w, "STP_Audit_Load")

        # SQL transformation: mark staging rows
        write_sql_transformation(w, "SQL_Mark_Processed")

        # Lookup for EMP_SK against DW_DIM_EMPLOYEE
        write_lookup(
            w, "LKP_EmpSK",
            lookup_table="DW.DW_DIM_EMPLOYEE",
            in_fields=[("IN_EMP_ID", "number", 10, 0)],
            lookup_fields=[("EMP_SK", "number", 18, 0),
                           ("EMP_ID", "number", 10, 0),
                           ("IS_CURRENT", "string", 1, 0)],
            return_fields=[("O_EMP_SK", "number", 18, 0)],
            sql_override=("SELECT EMP_SK, EMP_ID, IS_CURRENT FROM DW.DW_DIM_EMPLOYEE "
                          "WHERE IS_CURRENT = 'Y'"),
            lookup_condition="EMP_ID = IN_EMP_ID")

        # ---- INSTANCES ----

        def inst(name, ttype, tname, reusable="NO", assoc=None):
            kw = dict(DESCRIPTION="", NAME=name, REUSABLE=reusable,
                      TRANSFORMATION_NAME=tname,
                      TRANSFORMATION_TYPE=ttype, TYPE="TRANSFORMATION")
            if ttype == "Source Qualifier":
                kw["TRANSFORMATION_TYPE"] = "Source Qualifier"
            if assoc:
                with w.tag("INSTANCE", **kw):
                    w.empty("ASSOCIATED_SOURCE_INSTANCE", NAME=assoc)
            else:
                w.empty("INSTANCE", **kw)

        def src_inst(name, source_name):
            w.empty("INSTANCE", DESCRIPTION="", NAME=name,
                    TRANSFORMATION_NAME=source_name,
                    TRANSFORMATION_TYPE="", TYPE="SOURCE")

        def tgt_inst(name, target_name):
            w.empty("INSTANCE", DESCRIPTION="", NAME=name,
                    TRANSFORMATION_NAME=target_name,
                    TRANSFORMATION_TYPE="", TYPE="TARGET")

        src_inst("SRC_HR_EMPLOYEE",    "HR_EMPLOYEE")
        src_inst("SRC_HR_DEPARTMENT",  "HR_DEPARTMENT")
        src_inst("SRC_FIN_PAYROLL",    "FIN_PAYROLL_TXN")

        inst("SQ_Employee_Dept",   "Source Qualifier", "SQ_Employee_Dept",
             assoc="SRC_HR_EMPLOYEE")
        inst("SQ_Payroll",         "Source Qualifier", "SQ_Payroll",
             assoc="SRC_FIN_PAYROLL")
        inst("EXP_Clean",          "Expression",        "EXP_Clean")
        inst("LKP_Dept",           "Lookup Procedure",  "LKP_Dept")
        inst("SRT_ByEmpId",        "Sorter",            "SRT_ByEmpId")
        inst("SRT_Payroll_ByEmp",  "Sorter",            "SRT_Payroll_ByEmp")
        inst("JNR_Emp_Payroll",    "Joiner",            "JNR_Emp_Payroll")
        inst("AGG_Monthly",        "Aggregator",        "AGG_Monthly")
        inst("LKP_EmpSK",          "Lookup Procedure",  "LKP_EmpSK")
        inst("RNK_Top_Earners",    "Rank",              "RNK_Top_Earners")
        inst("FIL_Active",         "Filter",            "FIL_Active")
        inst("EXP_Derive_PayDate", "Expression",        "EXP_Derive_PayDate")
        inst("SEQ_Payroll_SK",     "Sequence",          "SEQ_Payroll_SK")
        inst("EXP_Calc_Bonus",     "Expression",        "EXP_Calc_Bonus", reusable="YES")
        inst("JTX_Parse_Event",    "Java Transformation","JTX_Parse_Event_JSON", reusable="YES")
        inst("RTR_Split",          "Router",            "RTR_Split")
        inst("UPD_Fact_Payroll",   "Update Strategy",   "UPD_Fact_Payroll")
        inst("TC_Per_Period",      "Transaction Control","TC_Per_Period")
        inst("STP_Audit_Load",     "Stored Procedure",  "STP_Audit_Load")
        inst("SQL_Mark_Processed", "SQL Transformation","SQL_Mark_Processed")

        tgt_inst("TGT_FACT_PAYROLL",       "DW_FACT_PAYROLL")
        tgt_inst("TGT_FACT_PAYROLL_ERROR", "DW_FACT_PAYROLL_ERROR")

        # ---- CONNECTORS (field-level) ----

        def c(ff, fi, tf, ti, from_group=None, to_group=None):
            kw = dict(FROMFIELD=ff, FROMINSTANCE=fi,
                      FROMINSTANCETYPE="TRANSFORMATION",
                      TOFIELD=tf, TOINSTANCE=ti,
                      TOINSTANCETYPE="TRANSFORMATION")
            if from_group:
                kw["FROMINSTANCEFIELDGROUP"] = from_group
            if to_group:
                kw["TOINSTANCEFIELDGROUP"] = to_group
            w.empty("CONNECTOR", **kw)

        # SRC -> SQ
        for f in ("EMP_ID","FIRST_NAME","LAST_NAME","EMAIL","HIRE_DATE",
                  "DEPT_ID","SALARY","COMMISSION_PCT","STATUS","LAST_UPDATE"):
            c(f, "SRC_HR_EMPLOYEE", f, "SQ_Employee_Dept")
        for f in ("DEPT_ID","DEPT_NAME","COST_CENTER"):
            c(f, "SRC_HR_DEPARTMENT", f, "SQ_Employee_Dept")
        for f in ("TXN_ID","EMP_ID","PAY_PERIOD","GROSS_PAY","NET_PAY",
                  "TAX_AMOUNT","BONUS","PAY_DATE","CURRENCY","STATUS"):
            c(f, "SRC_FIN_PAYROLL", f, "SQ_Payroll")

        # SQ_Employee_Dept -> EXP_Clean
        sq_to_exp = [("EMP_ID","EMP_ID"),("FIRST_NAME","FIRST_NAME"),
                     ("LAST_NAME","LAST_NAME"),("EMAIL","EMAIL"),
                     ("SALARY","SALARY"),("COMMISSION_PCT","COMMISSION_PCT"),
                     ("STATUS","STATUS"),("DEPT_NAME","DEPT_NAME")]
        for sf, tf in sq_to_exp:
            c(sf, "SQ_Employee_Dept", tf, "EXP_Clean")

        # EXP_Clean -> LKP_Dept
        c("DEPT_NAME_O", "EXP_Clean", "IN_DEPT_NAME", "LKP_Dept")

        # EXP_Clean + LKP_Dept -> SRT_ByEmpId
        for sf, tf in [("EMP_ID_O","EMP_ID"),("FULL_NAME","FULL_NAME"),
                       ("EMAIL_NORM","EMAIL_NORM"),("SALARY_CLEAN","SALARY_CLEAN"),
                       ("COMM_CLEAN","COMM_CLEAN"),("IS_VIP","IS_VIP")]:
            c(sf, "EXP_Clean", tf, "SRT_ByEmpId")
        c("O_DEPT_SK", "LKP_Dept", "DEPT_SK", "SRT_ByEmpId")

        # SQ_Payroll -> SRT_Payroll_ByEmp
        for f in ("EMP_ID","PAY_PERIOD","GROSS_PAY","NET_PAY",
                  "TAX_AMOUNT","BONUS","PAY_DATE","CURRENCY"):
            c(f, "SQ_Payroll", f, "SRT_Payroll_ByEmp")

        # Both sorters -> JNR_Emp_Payroll (master/detail)
        for f in ("EMP_ID","FULL_NAME","EMAIL_NORM","SALARY_CLEAN",
                  "COMM_CLEAN","IS_VIP","DEPT_SK"):
            c(f, "SRT_ByEmpId", f, "JNR_Emp_Payroll", to_group="MASTER")
        for sf, tf in [("EMP_ID","P_EMP_ID"),("PAY_PERIOD","PAY_PERIOD"),
                       ("GROSS_PAY","GROSS_PAY"),("NET_PAY","NET_PAY"),
                       ("TAX_AMOUNT","TAX_AMOUNT"),("BONUS","P_BONUS"),
                       ("PAY_DATE","PAY_DATE"),("CURRENCY","CURRENCY")]:
            c(sf, "SRT_Payroll_ByEmp", tf, "JNR_Emp_Payroll", to_group="DETAIL")

        # JNR_Emp_Payroll -> EXP_Calc_Bonus (reusable) for recalculated bonus
        for sf, tf in [("SALARY_CLEAN","BASE_SALARY"),
                       ("COMM_CLEAN","COMMISSION_PCT"),
                       ("IS_VIP","STATUS")]:
            c(sf, "JNR_Emp_Payroll", tf, "EXP_Calc_Bonus")

        # JNR_Emp_Payroll -> AGG_Monthly
        jnr_to_agg = [("EMP_ID","EMP_ID"),("PAY_PERIOD","PAY_PERIOD"),
                      ("DEPT_SK","DEPT_SK"),("GROSS_PAY","GROSS_PAY"),
                      ("NET_PAY","NET_PAY"),("TAX_AMOUNT","TAX_AMOUNT"),
                      ("BONUS_IN","BONUS_IN"),("CURRENCY","CURRENCY"),
                      ("FULL_NAME","FULL_NAME"),("EMAIL_NORM","EMAIL_NORM"),
                      ("IS_VIP","IS_VIP")]
        for sf, tf in jnr_to_agg:
            c(sf, "JNR_Emp_Payroll", tf, "AGG_Monthly")

        # AGG_Monthly -> LKP_EmpSK + RNK_Top_Earners
        c("O_EMP_ID", "AGG_Monthly", "IN_EMP_ID", "LKP_EmpSK")
        rnk = [("O_EMP_ID","EMP_ID"),("O_PAY_PERIOD","PAY_PERIOD"),
               ("O_DEPT_SK","DEPT_SK"),("O_FULL_NAME","FULL_NAME"),
               ("O_EMAIL","EMAIL"),("O_IS_VIP","IS_VIP"),
               ("O_CURRENCY","CURRENCY"),("O_GROSS_PAY","GROSS_PAY"),
               ("O_NET_PAY","NET_PAY"),("O_TAX_AMOUNT","TAX_AMOUNT"),
               ("O_BONUS","BONUS"),("O_TOTAL_COMP","TOTAL_COMP")]
        for sf, tf in rnk:
            c(sf, "AGG_Monthly", tf, "RNK_Top_Earners")

        # RNK -> FIL_Active
        for sf, tf in rnk + [("RANKINDEX","RANKINDEX")]:
            src_f = tf
            c(src_f, "RNK_Top_Earners", src_f, "FIL_Active")

        # FIL -> EXP_Derive_PayDate + SEQ + RTR
        c("PAY_PERIOD", "FIL_Active", "PAY_PERIOD", "EXP_Derive_PayDate")
        rtr_in = [("EMP_ID","EMP_ID"),("PAY_PERIOD","PAY_PERIOD"),
                  ("DEPT_SK","DEPT_SK"),("FULL_NAME","FULL_NAME"),
                  ("EMAIL","EMAIL"),("GROSS_PAY","GROSS_PAY"),
                  ("NET_PAY","NET_PAY"),("TAX_AMOUNT","TAX_AMOUNT"),
                  ("BONUS","BONUS"),("TOTAL_COMP","TOTAL_COMP"),
                  ("CURRENCY","CURRENCY")]
        for sf, tf in rtr_in:
            c(sf, "FIL_Active", tf, "RTR_Split", to_group="INPUT")
        c("PAY_DATE_DERIVED", "EXP_Derive_PayDate", "PAY_DATE",
          "RTR_Split", to_group="INPUT")
        c("NEXTVAL", "SEQ_Payroll_SK", "PAYROLL_SK",
          "RTR_Split", to_group="INPUT")

        # RTR VALID -> UPD_Fact_Payroll
        upd_fields = ["EMP_ID","PAY_PERIOD","DEPT_SK","GROSS_PAY","NET_PAY",
                      "TAX_AMOUNT","BONUS","TOTAL_COMP","CURRENCY","PAY_DATE",
                      "PAYROLL_SK"]
        # LKP_EmpSK -> UPD (EMP_SK)
        c("O_EMP_SK", "LKP_EmpSK", "EMP_SK", "UPD_Fact_Payroll")
        for f in upd_fields:
            c(f, "RTR_Split", f, "UPD_Fact_Payroll", from_group="VALID")

        # UPD -> TC_Per_Period (bookkeeping) and -> TGT_FACT_PAYROLL
        c("PAY_PERIOD", "UPD_Fact_Payroll", "PAY_PERIOD", "TC_Per_Period")
        c("PAYROLL_SK", "UPD_Fact_Payroll", "PAYROLL_SK", "TC_Per_Period")

        tgt_map = [("PAYROLL_SK","PAYROLL_SK"),("EMP_SK","EMP_SK"),
                   ("DEPT_SK","DEPT_SK"),("PAY_PERIOD","PAY_PERIOD"),
                   ("GROSS_PAY","GROSS_PAY"),("NET_PAY","NET_PAY"),
                   ("TAX_AMOUNT","TAX_AMOUNT"),("BONUS","BONUS"),
                   ("TOTAL_COMP","TOTAL_COMP"),("CURRENCY","CURRENCY"),
                   ("PAY_DATE","PAY_DATE")]
        for sf, tf in tgt_map:
            w.empty("CONNECTOR", FROMFIELD=sf, FROMINSTANCE="UPD_Fact_Payroll",
                    FROMINSTANCETYPE="TRANSFORMATION",
                    TOFIELD=tf, TOINSTANCE="TGT_FACT_PAYROLL",
                    TOINSTANCETYPE="TARGET")

        # RTR ERROR -> TGT_FACT_PAYROLL_ERROR
        w.empty("CONNECTOR", FROMFIELD="EMP_ID", FROMINSTANCE="RTR_Split",
                FROMINSTANCEFIELDGROUP="ERROR",
                FROMINSTANCETYPE="TRANSFORMATION",
                TOFIELD="EMP_ID", TOINSTANCE="TGT_FACT_PAYROLL_ERROR",
                TOINSTANCETYPE="TARGET")
        w.empty("CONNECTOR", FROMFIELD="PAY_PERIOD", FROMINSTANCE="RTR_Split",
                FROMINSTANCEFIELDGROUP="ERROR",
                FROMINSTANCETYPE="TRANSFORMATION",
                TOFIELD="ERR_REASON", TOINSTANCE="TGT_FACT_PAYROLL_ERROR",
                TOINSTANCETYPE="TARGET")

        # STP_Audit_Load and SQL_Mark_Processed get wired off EMP_ID
        c("EMP_ID", "UPD_Fact_Payroll", "IN_EMP_ID", "STP_Audit_Load")
        c("PAY_DATE", "UPD_Fact_Payroll", "IN_PAY_DATE", "STP_Audit_Load")
        c("EMP_ID", "UPD_Fact_Payroll", "EMP_ID", "SQL_Mark_Processed")

        # ---- TARGETLOADORDER ----
        w.empty("TARGETLOADORDER", ORDER="1", TARGETINSTANCE="TGT_FACT_PAYROLL")
        w.empty("TARGETLOADORDER", ORDER="2", TARGETINSTANCE="TGT_FACT_PAYROLL_ERROR")


# ============================================================
# Small mappings
# ============================================================

def write_mapping_dim_employee(w, name):
    with w.tag("MAPPING", DESCRIPTION="Type-2 SCD load for DW_DIM_EMPLOYEE",
               ISVALID="YES", NAME=name, OBJECTVERSION="1", VERSIONNUMBER="1"):
        write_source_qualifier(w, "SQ_Employee", "HR_EMPLOYEE",
            sql_override=("SELECT EMP_ID, FIRST_NAME, LAST_NAME, EMAIL, HIRE_DATE, "
                          "DEPT_ID, STATUS, LAST_UPDATE FROM HR.HR_EMPLOYEE "
                          "WHERE LAST_UPDATE > TO_DATE('$$LastRunDate','MM/DD/YYYY HH24:MI:SS')"))
        write_expression(w, "EXP_Compose",
            in_fields=[("EMP_ID","number",10,0),("FIRST_NAME","string",50,0),
                       ("LAST_NAME","string",50,0),("EMAIL","string",100,0),
                       ("HIRE_DATE","date/time",19,0),("STATUS","string",1,0)],
            out_fields=[("O_EMP_ID","number",10,0,"EMP_ID"),
                        ("FULL_NAME","string",120,0,"FIRST_NAME || ' ' || LAST_NAME"),
                        ("EMAIL_NORM","string",100,0,"LOWER(EMAIL)"),
                        ("O_HIRE_DATE","date/time",19,0,"HIRE_DATE"),
                        ("IS_CURRENT","string",1,0,"'Y'"),
                        ("EFFECTIVE_FROM","date/time",19,0,"SYSDATE"),
                        ("EFFECTIVE_TO","date/time",19,0,"TO_DATE('12/31/9999','MM/DD/YYYY')")])
        write_sequence_generator(w, "SEQ_Emp_SK")
        write_update_strategy(w, "UPD_Dim_Employee",
            in_fields=[("EMP_SK","number",18,0),("EMP_ID","number",10,0),
                       ("FULL_NAME","string",120,0),("EMAIL","string",100,0),
                       ("HIRE_DATE","date/time",19,0),
                       ("EFFECTIVE_FROM","date/time",19,0),
                       ("EFFECTIVE_TO","date/time",19,0),
                       ("IS_CURRENT","string",1,0)],
            expr="DD_INSERT")

        w.empty("INSTANCE", DESCRIPTION="", NAME="SRC_HR_EMPLOYEE",
                TRANSFORMATION_NAME="HR_EMPLOYEE",
                TRANSFORMATION_TYPE="", TYPE="SOURCE")
        for iname, tname, ttype in [
            ("SQ_Employee","SQ_Employee","Source Qualifier"),
            ("EXP_Compose","EXP_Compose","Expression"),
            ("SEQ_Emp_SK","SEQ_Emp_SK","Sequence"),
            ("UPD_Dim_Employee","UPD_Dim_Employee","Update Strategy"),
        ]:
            w.empty("INSTANCE", DESCRIPTION="", NAME=iname,
                    TRANSFORMATION_NAME=tname,
                    TRANSFORMATION_TYPE=ttype, TYPE="TRANSFORMATION")
        w.empty("INSTANCE", DESCRIPTION="", NAME="TGT_DIM_EMPLOYEE",
                TRANSFORMATION_NAME="DW_DIM_EMPLOYEE",
                TRANSFORMATION_TYPE="", TYPE="TARGET")

        for f in ("EMP_ID","FIRST_NAME","LAST_NAME","EMAIL","HIRE_DATE",
                  "STATUS"):
            w.empty("CONNECTOR", FROMFIELD=f, FROMINSTANCE="SRC_HR_EMPLOYEE",
                    FROMINSTANCETYPE="SOURCE", TOFIELD=f,
                    TOINSTANCE="SQ_Employee",
                    TOINSTANCETYPE="TRANSFORMATION")
        for f in ("EMP_ID","FIRST_NAME","LAST_NAME","EMAIL","HIRE_DATE","STATUS"):
            w.empty("CONNECTOR", FROMFIELD=f, FROMINSTANCE="SQ_Employee",
                    FROMINSTANCETYPE="TRANSFORMATION", TOFIELD=f,
                    TOINSTANCE="EXP_Compose",
                    TOINSTANCETYPE="TRANSFORMATION")
        w.empty("CONNECTOR", FROMFIELD="NEXTVAL", FROMINSTANCE="SEQ_Emp_SK",
                FROMINSTANCETYPE="TRANSFORMATION",
                TOFIELD="EMP_SK", TOINSTANCE="UPD_Dim_Employee",
                TOINSTANCETYPE="TRANSFORMATION")
        exp_to_upd = [("O_EMP_ID","EMP_ID"),("FULL_NAME","FULL_NAME"),
                      ("EMAIL_NORM","EMAIL"),("O_HIRE_DATE","HIRE_DATE"),
                      ("EFFECTIVE_FROM","EFFECTIVE_FROM"),
                      ("EFFECTIVE_TO","EFFECTIVE_TO"),
                      ("IS_CURRENT","IS_CURRENT")]
        for sf, tf in exp_to_upd:
            w.empty("CONNECTOR", FROMFIELD=sf, FROMINSTANCE="EXP_Compose",
                    FROMINSTANCETYPE="TRANSFORMATION", TOFIELD=tf,
                    TOINSTANCE="UPD_Dim_Employee",
                    TOINSTANCETYPE="TRANSFORMATION")
        tgt_cols = [("EMP_SK","EMP_SK"),("EMP_ID","EMP_ID"),
                    ("FULL_NAME","FULL_NAME"),("EMAIL","EMAIL"),
                    ("HIRE_DATE","HIRE_DATE"),
                    ("EFFECTIVE_FROM","EFFECTIVE_FROM"),
                    ("EFFECTIVE_TO","EFFECTIVE_TO"),
                    ("IS_CURRENT","IS_CURRENT")]
        for sf, tf in tgt_cols:
            w.empty("CONNECTOR", FROMFIELD=sf, FROMINSTANCE="UPD_Dim_Employee",
                    FROMINSTANCETYPE="TRANSFORMATION", TOFIELD=tf,
                    TOINSTANCE="TGT_DIM_EMPLOYEE",
                    TOINSTANCETYPE="TARGET")
        w.empty("TARGETLOADORDER", ORDER="1", TARGETINSTANCE="TGT_DIM_EMPLOYEE")


def write_mapping_dim_department(w, name):
    with w.tag("MAPPING", DESCRIPTION="Load DW_DIM_DEPARTMENT",
               ISVALID="YES", NAME=name, OBJECTVERSION="1", VERSIONNUMBER="1"):
        write_source_qualifier(w, "SQ_Department", "HR_DEPARTMENT")
        write_sequence_generator(w, "SEQ_Dept_SK")
        write_expression(w, "EXP_Dept_Prep",
            in_fields=[("DEPT_ID","number",10,0),
                       ("DEPT_NAME","string",80,0),
                       ("COST_CENTER","string",20,0)],
            out_fields=[("O_DEPT_ID","number",10,0,"DEPT_ID"),
                        ("O_DEPT_NAME","string",80,0,"UPPER(DEPT_NAME)"),
                        ("O_COST_CENTER","string",20,0,"COST_CENTER")])

        w.empty("INSTANCE", NAME="SRC_HR_DEPARTMENT",
                TRANSFORMATION_NAME="HR_DEPARTMENT",
                TRANSFORMATION_TYPE="", TYPE="SOURCE", DESCRIPTION="")
        for iname, tname, ttype in [
            ("SQ_Department","SQ_Department","Source Qualifier"),
            ("EXP_Dept_Prep","EXP_Dept_Prep","Expression"),
            ("SEQ_Dept_SK","SEQ_Dept_SK","Sequence"),
        ]:
            w.empty("INSTANCE", NAME=iname, TRANSFORMATION_NAME=tname,
                    TRANSFORMATION_TYPE=ttype, TYPE="TRANSFORMATION",
                    DESCRIPTION="")
        w.empty("INSTANCE", NAME="TGT_DIM_DEPARTMENT",
                TRANSFORMATION_NAME="DW_DIM_DEPARTMENT",
                TRANSFORMATION_TYPE="", TYPE="TARGET", DESCRIPTION="")

        for f in ("DEPT_ID","DEPT_NAME","COST_CENTER"):
            w.empty("CONNECTOR", FROMFIELD=f, FROMINSTANCE="SRC_HR_DEPARTMENT",
                    FROMINSTANCETYPE="SOURCE", TOFIELD=f,
                    TOINSTANCE="SQ_Department", TOINSTANCETYPE="TRANSFORMATION")
            w.empty("CONNECTOR", FROMFIELD=f, FROMINSTANCE="SQ_Department",
                    FROMINSTANCETYPE="TRANSFORMATION", TOFIELD=f,
                    TOINSTANCE="EXP_Dept_Prep", TOINSTANCETYPE="TRANSFORMATION")
        w.empty("CONNECTOR", FROMFIELD="NEXTVAL", FROMINSTANCE="SEQ_Dept_SK",
                FROMINSTANCETYPE="TRANSFORMATION", TOFIELD="DEPT_SK",
                TOINSTANCE="TGT_DIM_DEPARTMENT", TOINSTANCETYPE="TARGET")
        for sf, tf in [("O_DEPT_ID","DEPT_ID"),("O_DEPT_NAME","DEPT_NAME"),
                       ("O_COST_CENTER","COST_CENTER")]:
            w.empty("CONNECTOR", FROMFIELD=sf, FROMINSTANCE="EXP_Dept_Prep",
                    FROMINSTANCETYPE="TRANSFORMATION", TOFIELD=tf,
                    TOINSTANCE="TGT_DIM_DEPARTMENT", TOINSTANCETYPE="TARGET")
        w.empty("TARGETLOADORDER", ORDER="1", TARGETINSTANCE="TGT_DIM_DEPARTMENT")


# ============================================================
# Workflow + sessions
# ============================================================

def write_workflow(w, name, mappings):
    with w.tag("WORKFLOW", DESCRIPTION=f"Workflow {name}",
               ISENABLED="YES", ISRUNNABLESERVICE="NO", ISSERVICE="NO",
               ISVALID="YES", NAME=name, REUSABLE_SCHEDULER="NO",
               SCHEDULERNAME="Scheduler_Default", SERVERNAME="INT_SVC",
               SERVER_DOMAINNAME="Domain_ETL", SUSPEND_ON_ERROR="NO",
               TASKS_MUST_RUN_ON_SERVER="NO", VERSIONNUMBER="1"):
        w.empty("SCHEDULER", DESCRIPTION="", NAME="Scheduler_Default",
                REUSABLE="NO", VERSIONNUMBER="1")

        with w.tag("TASK", DESCRIPTION="", NAME="s_Start",
                   REUSABLE="NO", TYPE="Start", VERSIONNUMBER="1"):
            pass

        for m in mappings:
            session_name = f"s_{m}"
            with w.tag("SESSION", DESCRIPTION=f"Session for {m}",
                       ISVALID="YES", MAPPINGNAME=m, NAME=session_name,
                       REUSABLE="NO", SERVERNAME="INT_SVC",
                       SORTORDER="Binary", VERSIONNUMBER="1"):
                with w.tag("SESSIONCOMPONENT", REFOBJECTNAME="",
                           REUSABLE="NO", TYPE="Pre-session command"):
                    pass
                with w.tag("SESSIONCOMPONENT", REFOBJECTNAME="",
                           REUSABLE="NO", TYPE="Post-session success command"):
                    pass
                w.empty("ATTRIBUTE", NAME="Commit Type", VALUE="Target")
                w.empty("ATTRIBUTE", NAME="Commit Interval", VALUE="10000")
                w.empty("ATTRIBUTE", NAME="Stop on errors", VALUE="0")
                w.empty("ATTRIBUTE", NAME="Recovery Strategy", VALUE="Fail task and continue workflow")
                w.empty("ATTRIBUTE", NAME="DTM buffer size", VALUE="Auto")
                w.empty("ATTRIBUTE", NAME="$Source connection value",
                        VALUE="$DBConnection_Source")
                w.empty("ATTRIBUTE", NAME="$Target connection value",
                        VALUE="$DBConnection_DW")

        # Workflow links
        prev = "s_Start"
        for m in mappings:
            w.empty("WORKFLOWLINK", CONDITION="", FROMTASK=prev,
                    TOTASK=f"s_{m}")
            prev = f"s_{m}"


# ============================================================
# Main
# ============================================================

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default="sample.xml")
    ap.add_argument("--scale", type=int, default=1,
                    help="Multiplier for mapping replication (1..50)")
    args = ap.parse_args()

    with open(args.out, "w", encoding="utf-8") as fh:
        w = W(fh)
        fh.write('<?xml version="1.0" encoding="UTF-8"?>\n')
        fh.write('<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">\n')
        with w.tag("POWERMART",
                   CREATION_DATE=datetime.now().strftime("%m/%d/%Y %H:%M:%S"),
                   REPOSITORY_VERSION="186.95"):
            with w.tag("REPOSITORY", CODEPAGE="UTF-8",
                       DATABASETYPE="Oracle", NAME="Rep_Prod",
                       VERSION="186"):

                # --- Folder 1: SHARED_METADATA (SOURCE + TARGET only) ---
                with w.tag("FOLDER", DESCRIPTION="Shared source/target metadata",
                           GROUP="", NAME="SHARED_METADATA", OWNER="admin",
                           PERMISSIONS="rwx---r--", SHARED="SHARED",
                           UUID="8b7c1e10-0000-0000-0000-000000000001"):
                    for name, dbn, dbt, fields in REL_SOURCES:
                        write_source_rel(w, name, dbn, dbt, fields)
                    for name, fields in FLAT_SOURCES:
                        write_source_flat(w, name, fields)
                    for name, dbt, fields in TARGETS:
                        write_target(w, name, dbt, fields)

                # --- Folder 2: EDW_CORE ---
                with w.tag("FOLDER", DESCRIPTION="EDW core mappings",
                           GROUP="", NAME="EDW_CORE", OWNER="etl_dev",
                           PERMISSIONS="rwxrwxr--", SHARED="NOTSHARED",
                           UUID="8b7c1e10-0000-0000-0000-000000000002"):

                    # Reusable transformations (one per many types)
                    write_reusable_transformations(w)

                    # Big mapping (replicated by --scale)
                    big_mapping_names = []
                    for i in range(args.scale):
                        suffix = "" if i == 0 else f"_{i:02d}"
                        mn = f"m_Load_Fact_Payroll{suffix}"
                        big_mapping_names.append(mn)
                        write_big_mapping(w, mn)

                    # Small mappings (also replicated)
                    small_mappings = []
                    for i in range(args.scale):
                        suffix = "" if i == 0 else f"_{i:02d}"
                        n1 = f"m_Load_Dim_Employee{suffix}"
                        n2 = f"m_Load_Dim_Department{suffix}"
                        small_mappings += [n2, n1]
                        write_mapping_dim_department(w, n2)
                        write_mapping_dim_employee(w, n1)

                    # Shortcuts to Folder 1 (placed toward the end of the folder,
                    # per user's request)
                    for tgt_name in ("DW_FACT_PAYROLL", "DW_FACT_PAYROLL_ERROR",
                                     "DW_DIM_EMPLOYEE", "DW_DIM_DEPARTMENT"):
                        w.empty("SHORTCUT",
                                BUSINESSNAME="",
                                DESCRIPTION="",
                                FOLDERNAME="SHARED_METADATA",
                                NAME=f"SC_{tgt_name}",
                                OBJECTSUBTYPE="",
                                OBJECTTYPE="TARGET",
                                REFOBJECTDBDNAME="",
                                REFOBJECTFOLDERNAME="SHARED_METADATA",
                                REFOBJECTNAME=tgt_name,
                                REFOBJECTREPOSITORYNAME="Rep_Prod",
                                REFERENCETYPE="GLOBAL",
                                REPOSITORYNAME="Rep_Prod")
                    for src_name in ("HR_EMPLOYEE", "HR_DEPARTMENT",
                                     "FIN_PAYROLL_TXN", "FF_DAILY_EXCEPTIONS"):
                        w.empty("SHORTCUT",
                                BUSINESSNAME="",
                                DESCRIPTION="",
                                FOLDERNAME="SHARED_METADATA",
                                NAME=f"SC_{src_name}",
                                OBJECTSUBTYPE="",
                                OBJECTTYPE="SOURCE",
                                REFOBJECTDBDNAME="",
                                REFOBJECTFOLDERNAME="SHARED_METADATA",
                                REFOBJECTNAME=src_name,
                                REFOBJECTREPOSITORYNAME="Rep_Prod",
                                REFERENCETYPE="GLOBAL",
                                REPOSITORYNAME="Rep_Prod")

                    # Workflow referencing all mappings
                    write_workflow(w, "wf_EDW_Daily",
                                   small_mappings + big_mapping_names)


if __name__ == "__main__":
    main()
