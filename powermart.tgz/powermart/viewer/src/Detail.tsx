import { useMemo, useState } from 'react'
import type {
  Attrs, Field, Folder, Mapping, PowermartModel, SelectedObject, Source,
  SourceField, Target, TargetField, Transformation, Workflow, Shortcut,
} from './ir'
import { MappingGraph } from './MappingGraph'

type Props = {
  model: PowermartModel
  rawText: string
  selected: SelectedObject | null
  onSelect: (s: SelectedObject) => void
}

export function Detail({ model, rawText, selected, onSelect }: Props) {
  if (!selected) {
    return (
      <div className="detail">
        <div className="subtle">Select an object from the left tree.</div>
      </div>
    )
  }
  const folder = findFolder(model, selected.folder)
  if (!folder) return <div className="detail"><div className="subtle">Folder not found.</div></div>

  switch (selected.kind) {
    case 'source': {
      const obj = folder.sources.find((s) => s.name === selected.name)
      return obj ? <SourceDetail folder={folder} obj={obj} rawText={rawText} />
                 : <Missing what="source" name={selected.name} />
    }
    case 'target': {
      const obj = folder.targets.find((t) => t.name === selected.name)
      return obj ? <TargetDetail folder={folder} obj={obj} rawText={rawText} />
                 : <Missing what="target" name={selected.name} />
    }
    case 'transformation': {
      const obj = folder.transformations.find((t) => t.name === selected.name)
      return obj ? <TransformationDetail folder={folder} obj={obj} rawText={rawText} reusable />
                 : <Missing what="transformation" name={selected.name} />
    }
    case 'shortcut': {
      const obj = folder.shortcuts.find((s) => s.name === selected.name)
      return obj ? <ShortcutDetail folder={folder} obj={obj} rawText={rawText} />
                 : <Missing what="shortcut" name={selected.name} />
    }
    case 'mapping': {
      const obj = folder.mappings.find((m) => m.name === selected.name)
      return obj ? <MappingDetail folder={folder} mapping={obj} rawText={rawText}
                                  onSelectInstance={(iname) => onSelect({
                                    kind: 'instance', folder: folder.name,
                                    mapping: obj.name, name: iname,
                                  })} />
                 : <Missing what="mapping" name={selected.name} />
    }
    case 'workflow': {
      const obj = folder.workflows.find((w) => w.name === selected.name)
      return obj ? <WorkflowDetail folder={folder} obj={obj} rawText={rawText} />
                 : <Missing what="workflow" name={selected.name} />
    }
    case 'instance': {
      const mapping = folder.mappings.find((m) => m.name === selected.mapping)
      if (!mapping) return <Missing what="mapping" name={selected.mapping} />
      const inst = mapping.instances.find((i) => i.name === selected.name)
      if (!inst) return <Missing what="instance" name={selected.name} />
      return <InstanceDetail folder={folder} mapping={mapping} instanceName={inst.name}
                             rawText={rawText} onSelect={onSelect} />
    }
  }
}

function Missing({ what, name }: { what: string; name: string }) {
  return <div className="detail"><div className="subtle">Could not find {what} <code>{name}</code>.</div></div>
}

function findFolder(model: PowermartModel, name: string): Folder | undefined {
  for (const r of model.repositories) for (const f of r.folders) if (f.name === name) return f
  return undefined
}

// --------- Source ------------------------------------------------------

function SourceDetail({ folder, obj, rawText }: { folder: Folder; obj: Source; rawText: string }) {
  const [tab, setTab] = useState<'fields' | 'attrs' | 'xml'>('fields')
  return (
    <div className="detail">
      <h2>
        <span className="icon-dot src" /> {obj.name}
        <span className="pill">SOURCE</span>
        <span className="pill accent">{obj.databaseType}</span>
        {obj.isFlatFile && <span className="pill">Flat File</span>}
      </h2>
      <div className="subtle">
        Folder {folder.name} · DBD <code>{obj.dbdName}</code>
        {obj.ownerName && <> · Owner <code>{obj.ownerName}</code></>}
        {obj.description && <> · {obj.description}</>}
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[
        ['fields', `Fields (${obj.fields.length})`],
        ['attrs', `Attributes (${obj.tableAttributes.length})`],
        ['xml', 'Raw XML'],
      ]} />
      {tab === 'fields' && <SourceFieldTable fields={obj.fields} />}
      {tab === 'attrs' && <TableAttrs items={obj.tableAttributes} />}
      {tab === 'xml' && <RawXmlForName rawText={rawText} tag="SOURCE" name={obj.name} />}
    </div>
  )
}

function SourceFieldTable({ fields }: { fields: SourceField[] }) {
  return (
    <table className="grid">
      <thead>
        <tr>
          <th>#</th><th>Name</th><th>Type</th><th>Prec</th><th>Scale</th>
          <th>Key</th><th>Null</th>
        </tr>
      </thead>
      <tbody>
        {fields.map((f) => (
          <tr key={f.name}>
            <td className="dim">{f.fieldNumber}</td>
            <td>{f.name}</td>
            <td className="mono">{f.dataType}</td>
            <td>{f.precision}</td>
            <td>{f.scale}</td>
            <td>{f.keyType || ''}</td>
            <td className={f.nullable === 'NOTNULL' ? '' : 'dim'}>{f.nullable}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

// --------- Target ------------------------------------------------------

function TargetDetail({ folder, obj, rawText }: { folder: Folder; obj: Target; rawText: string }) {
  const [tab, setTab] = useState<'fields' | 'attrs' | 'xml'>('fields')
  return (
    <div className="detail">
      <h2>
        <span className="icon-dot tgt" /> {obj.name}
        <span className="pill">TARGET</span>
        <span className="pill accent">{obj.databaseType}</span>
      </h2>
      <div className="subtle">
        Folder {folder.name}
        {obj.description && <> · {obj.description}</>}
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[
        ['fields', `Fields (${obj.fields.length})`],
        ['attrs', `Attributes (${obj.tableAttributes.length})`],
        ['xml', 'Raw XML'],
      ]} />
      {tab === 'fields' && <TargetFieldTable fields={obj.fields} />}
      {tab === 'attrs' && <TableAttrs items={obj.tableAttributes} />}
      {tab === 'xml' && <RawXmlForName rawText={rawText} tag="TARGET" name={obj.name} />}
    </div>
  )
}

function TargetFieldTable({ fields }: { fields: TargetField[] }) {
  return (
    <table className="grid">
      <thead>
        <tr><th>#</th><th>Name</th><th>Type</th><th>Prec</th><th>Scale</th><th>Key</th><th>Null</th></tr>
      </thead>
      <tbody>
        {fields.map((f) => (
          <tr key={f.name}>
            <td className="dim">{f.fieldNumber}</td>
            <td>{f.name}</td>
            <td className="mono">{f.dataType}</td>
            <td>{f.precision}</td>
            <td>{f.scale}</td>
            <td>{f.keyType || ''}</td>
            <td className={f.nullable === 'NOTNULL' ? '' : 'dim'}>{f.nullable}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

// --------- Transformation (type-aware) --------------------------------

export function TransformationDetail({
  folder, obj, rawText, reusable, inMapping,
}: {
  folder: Folder; obj: Transformation; rawText: string; reusable: boolean;
  inMapping?: Mapping
}) {
  const [tab, setTab] = useState<'sql' | 'fields' | 'attrs' | 'groups' | 'init' | 'xml'>('sql')
  return (
    <div className="detail">
      <h2>
        <span className="icon-dot xform" /> {obj.name}
        <span className="pill accent">{obj.type || '(unknown type)'}</span>
        {reusable && <span className="pill ok">REUSABLE</span>}
        {inMapping && <span className="pill">in {inMapping.name}</span>}
      </h2>
      <div className="subtle">
        Folder {folder.name}
        {obj.description && <> · {obj.description}</>}
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[
        ['sql', 'Transformation'],
        ['fields', `Fields (${obj.fields.length})`],
        ['attrs', `Attributes (${obj.tableAttributes.length})`],
        ['groups', `Groups (${obj.groups.length})`],
        ['init', `Init Props (${obj.initProps.length})`],
        ['xml', 'Raw XML'],
      ].filter((x) => x[0] !== 'groups' || obj.groups.length)
       .filter((x) => x[0] !== 'init' || obj.initProps.length) as any} />
      {tab === 'sql' && <TransformationLogicPane obj={obj} />}
      {tab === 'fields' && <TransformFieldTable fields={obj.fields} />}
      {tab === 'attrs' && <TableAttrs items={obj.tableAttributes} />}
      {tab === 'groups' && <GroupsTable obj={obj} />}
      {tab === 'init' && (
        <div className="section">
          {obj.initProps.map((p, idx) => (
            <div key={idx} className="section">
              <h3>{p.name}</h3>
              <pre className="code">{p.value || <span className="subtle">(empty)</span>}</pre>
            </div>
          ))}
        </div>
      )}
      {tab === 'xml' && <RawXmlForName rawText={rawText} tag="TRANSFORMATION" name={obj.name} />}
    </div>
  )
}

/** Type-specific summary panel. Optimized for what a future SQL generator
 *  will read: expressions, filters, joins, aggregates, group-bys, etc. */
function TransformationLogicPane({ obj }: { obj: Transformation }) {
  const tattr = (name: string) => obj.tableAttributes.find((a) => a.name === name)?.value ?? ''
  const outputs = obj.fields.filter((f) => /OUTPUT/.test(f.portType) && !/INPUT/.test(f.portType))
  const groupBys = obj.fields.filter((f) => f.isGroupBy)
  const sortKeys = obj.fields.filter((f) => f.sortKey)
  const t = obj.type

  return (
    <div className="section">
      {t === 'Source Qualifier' && (
        <>
          <KV title="SQL Query" value={tattr('Sql Query')} mono multiline />
          <KV title="User Defined Join" value={tattr('User Defined Join')} mono />
          <KV title="Source Filter" value={tattr('Source Filter')} mono />
          <KV title="Pre SQL" value={tattr('Pre SQL')} mono multiline />
          <KV title="Post SQL" value={tattr('Post SQL')} mono multiline />
          <KV title="Select Distinct" value={tattr('Select Distinct')} />
          <KV title="Number Of Sorted Ports" value={tattr('Number Of Sorted Ports')} />
        </>
      )}

      {t === 'Filter' && (
        <KV title="Filter Condition" value={tattr('Filter Condition')} mono multiline />
      )}

      {t === 'Expression' && (
        <>
          <h3>Output expressions</h3>
          <table className="grid">
            <thead><tr><th>Field</th><th>Type</th><th>Expression</th></tr></thead>
            <tbody>
              {outputs.map((f) => (
                <tr key={f.name}>
                  <td>{f.name}</td>
                  <td className="mono">{f.dataType}({f.precision}{f.scale && f.scale !== '0' ? `,${f.scale}` : ''})</td>
                  <td className="mono">{f.expression || <span className="subtle">(passthrough)</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      {t === 'Aggregator' && (
        <>
          <KV title="Group By" value={groupBys.map((f) => f.name).join(', ') || '(none)'} mono />
          <KV title="Sorted Input" value={tattr('Sorted Input')} />
          <KV title="Transformation Scope" value={tattr('Transformation Scope')} />
          <h3>Aggregated outputs</h3>
          <table className="grid">
            <thead><tr><th>Field</th><th>Type</th><th>Expression</th></tr></thead>
            <tbody>
              {outputs.map((f) => (
                <tr key={f.name}>
                  <td>{f.name}</td>
                  <td className="mono">{f.dataType}({f.precision}{f.scale && f.scale !== '0' ? `,${f.scale}` : ''})</td>
                  <td className="mono">{f.expression || <span className="subtle">(passthrough)</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      {t === 'Joiner' && (
        <>
          <KV title="Join Type" value={tattr('Join Type')} />
          <KV title="Join Condition" value={tattr('Join Condition')} mono multiline />
          <KV title="Sorted Input" value={tattr('Sorted Input')} />
          <KV title="Case Sensitive" value={tattr('Case Sensitive String Comparison')} />
          <GroupsTable obj={obj} />
        </>
      )}

      {t === 'Lookup Procedure' && (
        <>
          <KV title="Lookup table" value={tattr('Lookup table name')} mono />
          <KV title="Lookup condition" value={tattr('Lookup condition')} mono />
          <KV title="Lookup SQL override" value={tattr('Lookup Sql Override')} mono multiline />
          <KV title="Caching enabled" value={tattr('Lookup caching enabled')} />
          <KV title="Policy on multiple match" value={tattr('Lookup policy on multiple match')} />
          <KV title="Connection" value={tattr('Connection Information')} mono />
        </>
      )}

      {t === 'Router' && (
        <>
          <h3>Output groups</h3>
          <table className="grid">
            <thead><tr><th>Group</th><th>Filter condition</th></tr></thead>
            <tbody>
              {obj.groups.filter((g) => g.type === 'OUTPUT').map((g) => (
                <tr key={g.name}>
                  <td>{g.name}</td>
                  <td className="mono">{tattr(`${g.name} Group Filter Condition`)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      {t === 'Update Strategy' && (
        <KV title="Update Strategy Expression" value={tattr('Update Strategy Expression')} mono multiline />
      )}

      {t === 'Transaction Control' && (
        <KV title="Transaction Control Condition" value={tattr('Transaction Control Condition')} mono multiline />
      )}

      {t === 'Sequence' && (
        <>
          <KV title="Start Value" value={tattr('Start Value')} />
          <KV title="Increment By" value={tattr('Increment By')} />
          <KV title="End Value" value={tattr('End Value')} />
          <KV title="Cycle" value={tattr('Cycle')} />
          <KV title="Number of Cached Values" value={tattr('Number of Cached Values')} />
        </>
      )}

      {t === 'Rank' && (
        <>
          <KV title="Top/Bottom" value={tattr('Top/Bottom')} />
          <KV title="Number Of Ranks" value={tattr('Number Of Ranks')} />
          <KV title="Group By" value={groupBys.map((f) => f.name).join(', ') || '(none)'} mono />
          <KV title="Rank Port" value={obj.fields.find((f) => f.rankIndex)?.name || '(none)'} mono />
        </>
      )}

      {t === 'Sorter' && (
        <>
          <KV title="Sort keys" value={sortKeys.map((f) => `${f.name} ${f.sortDirection ?? ''}`).join(', ')} mono />
          <KV title="Distinct" value={tattr('Distinct')} />
          <KV title="Case Sensitive" value={tattr('Case Sensitive')} />
        </>
      )}

      {t === 'Stored Procedure' && (
        <>
          <KV title="Call Text" value={tattr('Call Text')} mono multiline />
          <KV title="Stored Procedure Type" value={tattr('Stored Procedure Type')} />
          <KV title="Connection" value={tattr('Connection Information')} />
        </>
      )}

      {t === 'SQL Transformation' && (
        <>
          <KV title="SQL Mode" value={tattr('SQL Mode')} />
          <KV title="Database Type" value={tattr('Database Type')} />
          <KV title="Connection Type" value={tattr('Connection Type')} />
          <KV title="Script / Query" value={tattr('Script')} mono multiline />
        </>
      )}

      {t === 'Java Transformation' && (
        <>
          <KV title="Class" value={obj.initProps.find((p) => p.name === 'ClassName')?.value ?? ''} mono />
          <KV title="Runtime Location" value={obj.initProps.find((p) => p.name === 'Runtime Location')?.value ?? ''} mono />
          <h3>On Input Row</h3>
          <pre className="code">{obj.initProps.find((p) => p.name === 'On Input Row')?.value ?? ''}</pre>
          <h3>On End Of Data</h3>
          <pre className="code">{obj.initProps.find((p) => p.name === 'On End Of Data')?.value ?? ''}</pre>
          <h3>Imports</h3>
          <pre className="code">{obj.initProps.find((p) => p.name === 'Import Packages')?.value ?? ''}</pre>
        </>
      )}

      {t === 'HTTP Transformation' && (
        <>
          <KV title="Base URL" value={tattr('Base URL')} mono />
          <KV title="Method" value={tattr('HTTP Method')} />
          <KV title="Authentication" value={tattr('Authentication Type')} />
        </>
      )}

      {t === 'Web Services Consumer' && (
        <>
          <KV title="WSDL URL" value={tattr('WSDL URL')} mono />
          <KV title="Operation" value={tattr('Operation')} />
          <KV title="Endpoint" value={tattr('End Point URL')} mono />
        </>
      )}

      {t === 'External Procedure' && (
        <>
          <KV title="Module / DLL" value={tattr('Module/Program Name')} mono />
          <KV title="Procedure" value={tattr('Procedure Name')} mono />
          <KV title="Runtime Location" value={tattr('Runtime Location')} />
        </>
      )}

      {t === 'Normalizer' && (
        <>
          <KV title="Reset" value={tattr('Reset')} />
          <KV title="Restart" value={tattr('Restart')} />
        </>
      )}

      {(t === 'Custom Transformation' || t === 'Unstructured Data Transformation') && (
        <>
          <KV title="Template Name" value={obj.attrs.TEMPLATENAME ?? ''} />
          <KV title="Service Name" value={tattr('Service Name')} />
        </>
      )}
    </div>
  )
}

function KV({ title, value, mono, multiline }: {
  title: string; value: string; mono?: boolean; multiline?: boolean
}) {
  if (!value) return (
    <div className="kv"><div className="k">{title}</div><div className="v"><span className="subtle">(empty)</span></div></div>
  )
  if (multiline) return (
    <div className="section">
      <h3>{title}</h3>
      <pre className="code">{value}</pre>
    </div>
  )
  return (
    <div className="kv">
      <div className="k">{title}</div>
      <div className={`v ${mono ? 'mono' : ''}`}>{value}</div>
    </div>
  )
}

function TransformFieldTable({ fields }: { fields: Field[] }) {
  return (
    <table className="grid">
      <thead>
        <tr>
          <th>Name</th><th>Port</th><th>Group</th><th>Type</th>
          <th>Prec</th><th>Scale</th><th>Expression</th><th>Flags</th>
        </tr>
      </thead>
      <tbody>
        {fields.map((f) => (
          <tr key={`${f.name}:${f.group ?? ''}:${f.portType}`}>
            <td>{f.name}</td>
            <td className={`port-${f.portType.replace('/', '\\/')} mono`}>{f.portType}</td>
            <td className="dim">{f.group ?? ''}</td>
            <td className="mono">{f.dataType}</td>
            <td>{f.precision}</td>
            <td>{f.scale}</td>
            <td className="mono">{f.expression}</td>
            <td className="dim">
              {[f.isGroupBy && 'GROUP BY',
                f.sortKey && `SORT ${f.sortDirection ?? ''}`,
                f.rankIndex && 'RANK',
              ].filter(Boolean).join(' · ')}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

function GroupsTable({ obj }: { obj: Transformation }) {
  if (obj.groups.length === 0) return <div className="subtle">No groups.</div>
  return (
    <table className="grid">
      <thead><tr><th>Name</th><th>Type</th><th>Order</th><th>Fields</th></tr></thead>
      <tbody>
        {obj.groups.map((g) => (
          <tr key={`${g.name}:${g.type}`}>
            <td>{g.name}</td>
            <td>{g.type}</td>
            <td>{g.order}</td>
            <td className="mono">
              {obj.fields.filter((f) => f.group === g.name).map((f) => f.name).join(', ')}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

function TableAttrs({ items }: { items: { name: string; value: string }[] }) {
  if (items.length === 0) return <div className="subtle">None.</div>
  return (
    <table className="grid">
      <thead><tr><th style={{ width: '35%' }}>Name</th><th>Value</th></tr></thead>
      <tbody>
        {items.map((a, i) => (
          <tr key={i}><td>{a.name}</td><td className="mono">{a.value}</td></tr>
        ))}
      </tbody>
    </table>
  )
}

// --------- Shortcut ----------------------------------------------------

function ShortcutDetail({ folder, obj, rawText }: { folder: Folder; obj: Shortcut; rawText: string }) {
  const [tab, setTab] = useState<'info' | 'attrs' | 'xml'>('info')
  return (
    <div className="detail">
      <h2>
        <span className="icon-dot shortcut" /> {obj.name}
        <span className="pill">SHORTCUT</span>
        <span className="pill accent">{obj.objectType}</span>
      </h2>
      <div className="subtle">
        Folder {folder.name} · {obj.referenceType} reference
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[
        ['info', 'Info'],
        ['attrs', 'All attributes'],
        ['xml', 'Raw XML'],
      ]} />
      {tab === 'info' && (
        <div className="section">
          <KV title="Points to folder" value={obj.refFolder} mono />
          <KV title="Points to object" value={obj.refObject} mono />
          <KV title="Target repository" value={obj.refRepository} mono />
        </div>
      )}
      {tab === 'attrs' && <AttrsTable attrs={obj.attrs} />}
      {tab === 'xml' && <RawXmlForName rawText={rawText} tag="SHORTCUT" name={obj.name} />}
    </div>
  )
}

// --------- Mapping ----------------------------------------------------

function MappingDetail({
  folder, mapping, rawText, onSelectInstance,
}: {
  folder: Folder; mapping: Mapping; rawText: string; onSelectInstance: (n: string) => void
}) {
  const [tab, setTab] = useState<'graph' | 'instances' | 'connectors' | 'variables' | 'xml'>('graph')
  return (
    <div className="detail" style={{ height: '100%', padding: 0 }}>
      <div style={{ padding: '12px 16px 0' }}>
        <h2>
          <span className="icon-dot mapping" /> {mapping.name}
          <span className="pill">MAPPING</span>
          <span className={`pill ${mapping.isValid ? 'ok' : 'warn'}`}>
            {mapping.isValid ? 'VALID' : 'INVALID'}
          </span>
        </h2>
        <div className="subtle">
          Folder {folder.name} · {mapping.instances.length} instances ·{' '}
          {mapping.connectors.length} connectors ·{' '}
          {mapping.transformations.length} inline transformations
          {mapping.description && <> · {mapping.description}</>}
        </div>
        <Tabs value={tab} onChange={setTab} tabs={[
          ['graph', 'Graph'],
          ['instances', `Instances (${mapping.instances.length})`],
          ['connectors', `Connectors (${mapping.connectors.length})`],
          ['variables', `Variables (${mapping.mappingVariables.length})`],
          ['xml', 'Raw XML'],
        ]} />
      </div>
      {tab === 'graph' && (
        <div style={{ position: 'relative', flex: 1, minHeight: 500, height: '100%' }}>
          <MappingGraph folder={folder} mapping={mapping}
                        onSelectInstance={onSelectInstance} rawText={rawText} />
        </div>
      )}
      {tab !== 'graph' && (
        <div style={{ padding: '0 16px 16px' }}>
          {tab === 'instances' && <InstanceTable mapping={mapping} onSelect={onSelectInstance} />}
          {tab === 'connectors' && <ConnectorTable mapping={mapping} />}
          {tab === 'variables' && (
            <table className="grid">
              <thead><tr><th>Name</th><th>Type</th><th>Aggregation</th><th>Default</th></tr></thead>
              <tbody>
                {mapping.mappingVariables.map((v) => (
                  <tr key={v.name}>
                    <td className="mono">{v.name}</td>
                    <td className="mono">{v.dataType}({v.precision})</td>
                    <td>{v.aggregationType}</td>
                    <td className="mono">{v.defaultValue}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {tab === 'xml' && <RawXmlForName rawText={rawText} tag="MAPPING" name={mapping.name} />}
        </div>
      )}
    </div>
  )
}

function InstanceTable({ mapping, onSelect }: { mapping: Mapping; onSelect: (n: string) => void }) {
  return (
    <table className="grid">
      <thead><tr><th>Name</th><th>Type</th><th>Refers to</th><th>Reusable</th></tr></thead>
      <tbody>
        {mapping.instances.map((i) => (
          <tr key={i.name} style={{ cursor: 'pointer' }} onClick={() => onSelect(i.name)}>
            <td>{i.name}</td>
            <td className="dim">{i.type}{i.transformationType && ` / ${i.transformationType}`}</td>
            <td className="mono">{i.transformationName}</td>
            <td className="dim">{i.reusable ? 'YES' : ''}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

function ConnectorTable({ mapping }: { mapping: Mapping }) {
  return (
    <table className="grid">
      <thead>
        <tr>
          <th>From instance</th><th>From field</th><th>Group</th>
          <th>→ To instance</th><th>To field</th><th>Group</th>
        </tr>
      </thead>
      <tbody>
        {mapping.connectors.map((c, i) => (
          <tr key={i}>
            <td>{c.fromInstance}</td>
            <td className="mono">{c.fromField}</td>
            <td className="dim">{c.fromGroup ?? ''}</td>
            <td>{c.toInstance}</td>
            <td className="mono">{c.toField}</td>
            <td className="dim">{c.toGroup ?? ''}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

// --------- Instance (clicked from graph) ------------------------------

function InstanceDetail({
  folder, mapping, instanceName, rawText, onSelect,
}: {
  folder: Folder; mapping: Mapping; instanceName: string; rawText: string;
  onSelect: (s: SelectedObject) => void
}) {
  const inst = mapping.instances.find((i) => i.name === instanceName)!
  // Resolve the transformation this instance refers to.
  const inline = mapping.transformations.find((t) => t.name === inst.transformationName)
  const reusable = folder.transformations.find((t) => t.name === inst.transformationName)
  const src = folder.sources.find((s) => s.name === inst.transformationName)
  const tgt = folder.targets.find((t) => t.name === inst.transformationName)
  const sc = folder.shortcuts.find((s) => s.name === inst.transformationName)

  const lineage = useMemo(() => computeLineage(mapping, instanceName), [mapping, instanceName])

  return (
    <div className="detail">
      <h2>
        <span className="icon-dot xform" /> {inst.name}
        <span className="pill">INSTANCE</span>
        <span className="pill accent">{inst.type}{inst.transformationType && ` / ${inst.transformationType}`}</span>
      </h2>
      <div className="subtle">
        In mapping{' '}
        <a href="#" onClick={(e) => { e.preventDefault();
          onSelect({ kind: 'mapping', folder: folder.name, name: mapping.name }) }}>{mapping.name}</a>
        {' · '}refers to <code>{inst.transformationName}</code>
        {inst.associatedSourceInstance && <> · associated source <code>{inst.associatedSourceInstance}</code></>}
      </div>

      <div className="section">
        <h3>Incoming connectors ({lineage.incoming.length})</h3>
        <table className="grid">
          <thead><tr><th>From</th><th>From field</th><th>→ To field</th></tr></thead>
          <tbody>
            {lineage.incoming.map((c, i) => (
              <tr key={i}>
                <td>{c.fromInstance}{c.fromGroup && ` [${c.fromGroup}]`}</td>
                <td className="mono">{c.fromField}</td>
                <td className="mono">{c.toField}{c.toGroup && ` [${c.toGroup}]`}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="section">
        <h3>Outgoing connectors ({lineage.outgoing.length})</h3>
        <table className="grid">
          <thead><tr><th>Field</th><th>→ To</th><th>To field</th></tr></thead>
          <tbody>
            {lineage.outgoing.map((c, i) => (
              <tr key={i}>
                <td className="mono">{c.fromField}{c.fromGroup && ` [${c.fromGroup}]`}</td>
                <td>{c.toInstance}</td>
                <td className="mono">{c.toField}{c.toGroup && ` [${c.toGroup}]`}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {inline && <TransformationDetail folder={folder} obj={inline} rawText={rawText} reusable={false} inMapping={mapping} />}
      {reusable && <TransformationDetail folder={folder} obj={reusable} rawText={rawText} reusable inMapping={mapping} />}
      {src && <SourceDetail folder={folder} obj={src} rawText={rawText} />}
      {tgt && <TargetDetail folder={folder} obj={tgt} rawText={rawText} />}
      {sc && <ShortcutDetail folder={folder} obj={sc} rawText={rawText} />}
    </div>
  )
}

function computeLineage(mapping: Mapping, instanceName: string) {
  const incoming = mapping.connectors.filter((c) => c.toInstance === instanceName)
  const outgoing = mapping.connectors.filter((c) => c.fromInstance === instanceName)
  return { incoming, outgoing }
}

// --------- Workflow ---------------------------------------------------

function WorkflowDetail({ folder, obj, rawText }: { folder: Folder; obj: Workflow; rawText: string }) {
  const [tab, setTab] = useState<'sessions' | 'links' | 'xml'>('sessions')
  return (
    <div className="detail">
      <h2>
        <span className="icon-dot" style={{ background: 'var(--warn)' }} /> {obj.name}
        <span className="pill">WORKFLOW</span>
        <span className={`pill ${obj.isValid ? 'ok' : 'warn'}`}>
          {obj.isValid ? 'VALID' : 'INVALID'}
        </span>
      </h2>
      <div className="subtle">
        Folder {folder.name} · {obj.sessions.length} sessions · {obj.links.length} links
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[
        ['sessions', `Sessions (${obj.sessions.length})`],
        ['links', `Links (${obj.links.length})`],
        ['xml', 'Raw XML'],
      ]} />
      {tab === 'sessions' && (
        <table className="grid">
          <thead><tr><th>Name</th><th>Maps to</th><th>Attributes</th></tr></thead>
          <tbody>
            {obj.sessions.map((s) => (
              <tr key={s.name}>
                <td>{s.name}</td>
                <td className="mono">{s.mappingName}</td>
                <td className="dim">{s.attributes.length}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {tab === 'links' && (
        <table className="grid">
          <thead><tr><th>From</th><th>→ To</th><th>Condition</th></tr></thead>
          <tbody>
            {obj.links.map((l, i) => (
              <tr key={i}>
                <td>{l.fromTask}</td>
                <td>{l.toTask}</td>
                <td className="mono">{l.condition}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {tab === 'xml' && <RawXmlForName rawText={rawText} tag="WORKFLOW" name={obj.name} />}
    </div>
  )
}

// --------- Raw XML extraction -----------------------------------------

export function RawXmlForName({ rawText, tag, name }: { rawText: string; tag: string; name: string }) {
  const snippet = useMemo(
    () => extractXmlElement(rawText, tag, name) ?? '(element not found in raw text)',
    [rawText, tag, name],
  )
  return <pre className="code" style={{ maxHeight: 'calc(100vh - 260px)' }}>{snippet}</pre>
}

/** Find a `<TAG ... NAME="NAME" ...>…</TAG>` block in the raw XML source text.
 *  Works on any well-formed Powermart export (elements are line-oriented here). */
function extractXmlElement(raw: string, tag: string, name: string): string | null {
  // Escape regex metachars in the NAME.
  const esc = (s: string) => s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')
  const openRe = new RegExp(`<${tag}\\b[^>]*\\bNAME="${esc(name)}"[^>]*?(/>|>)`, 'g')
  const match = openRe.exec(raw)
  if (!match) return null
  const start = match.index
  // Self-closing element.
  if (match[1] === '/>') return raw.slice(start, openRe.lastIndex)
  // Otherwise scan to matching </TAG> allowing nested same-tag pairs.
  let depth = 1
  let i = openRe.lastIndex
  const openTag = new RegExp(`<${tag}\\b`, 'g')
  const closeTag = new RegExp(`</${tag}>`, 'g')
  while (depth > 0) {
    openTag.lastIndex = i
    closeTag.lastIndex = i
    const o = openTag.exec(raw)
    const c = closeTag.exec(raw)
    if (!c) return null
    if (o && o.index < c.index) { depth++; i = o.index + 1 }
    else { depth--; i = c.index + c[0].length }
  }
  return raw.slice(start, i)
}

// --------- Generic helpers --------------------------------------------

function Tabs<T extends string>({ value, onChange, tabs }: {
  value: T; onChange: (v: T) => void; tabs: [T, string][]
}) {
  return (
    <div className="tabs">
      {tabs.map(([k, label]) => (
        <div key={k} className={`tab ${k === value ? 'active' : ''}`}
             onClick={() => onChange(k)}>{label}</div>
      ))}
    </div>
  )
}

function AttrsTable({ attrs }: { attrs: Attrs }) {
  const rows = Object.entries(attrs)
  if (rows.length === 0) return <div className="subtle">No attributes.</div>
  return (
    <table className="grid">
      <thead><tr><th style={{ width: '35%' }}>Name</th><th>Value</th></tr></thead>
      <tbody>
        {rows.map(([k, v]) => (
          <tr key={k}><td>{k}</td><td className="mono">{v}</td></tr>
        ))}
      </tbody>
    </table>
  )
}
