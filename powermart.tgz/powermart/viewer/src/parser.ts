import { SaxesParser } from 'saxes'
import type {
  Attrs, Connector, Field, Folder, GroupDef, InitProp, Instance, Mapping,
  MappingVariable, PowermartModel, Repository, Session, Shortcut, Source,
  SourceField, Target, TargetField, TargetLoadOrder, Task, Transformation,
  Workflow, WorkflowLink,
} from './ir'

// ---- Raw tree ---------------------------------------------------------

interface RawNode {
  tag: string
  attrs: Record<string, string>
  children: RawNode[]
}

export interface ParseProgress {
  bytesRead: number
  totalBytes: number
  phase: 'parsing' | 'building' | 'done'
}

export async function parsePowermart(
  text: string,
  onProgress?: (p: ParseProgress) => void,
): Promise<PowermartModel> {
  const root: RawNode = { tag: '__root__', attrs: {}, children: [] }
  const stack: RawNode[] = [root]
  const parser = new SaxesParser({})
  let thrown: Error | null = null
  parser.on('error', (e) => { thrown = e as Error })
  parser.on('opentag', (node) => {
    // saxes gives attributes as Record<string,string> when xmlns is off
    const attrs = node.attributes as Record<string, string>
    const el: RawNode = { tag: node.name, attrs, children: [] }
    stack[stack.length - 1].children.push(el)
    stack.push(el)
  })
  parser.on('closetag', () => { stack.pop() })

  const chunkSize = 512 * 1024
  const total = text.length
  for (let i = 0; i < total; i += chunkSize) {
    parser.write(text.slice(i, i + chunkSize))
    if (thrown) throw thrown
    onProgress?.({ bytesRead: Math.min(i + chunkSize, total), totalBytes: total, phase: 'parsing' })
    // Yield to the event loop so the UI can repaint / progress update.
    await new Promise((r) => setTimeout(r, 0))
  }
  parser.close()
  if (thrown) throw thrown

  onProgress?.({ bytesRead: total, totalBytes: total, phase: 'building' })
  const powermart = root.children.find((c) => c.tag === 'POWERMART')
  if (!powermart) throw new Error('XML has no <POWERMART> root element.')
  const model = buildModel(powermart, total)
  onProgress?.({ bytesRead: total, totalBytes: total, phase: 'done' })
  return model
}

// ---- Small helpers ----------------------------------------------------

const boolAttr = (v: string | undefined) => (v ?? '').toUpperCase() === 'YES'
const childrenOf = (n: RawNode, tag: string) => n.children.filter((c) => c.tag === tag)
const freezeAttrs = (attrs: Record<string, string>): Attrs => Object.freeze({ ...attrs })

// ---- Builders ---------------------------------------------------------

function buildModel(n: RawNode, sourceSize: number): PowermartModel {
  return {
    creationDate: n.attrs.CREATION_DATE ?? '',
    repositoryVersion: n.attrs.REPOSITORY_VERSION ?? '',
    repositories: childrenOf(n, 'REPOSITORY').map(buildRepository),
    sourceSize,
  }
}

function buildRepository(n: RawNode): Repository {
  return {
    name: n.attrs.NAME ?? '',
    version: n.attrs.VERSION ?? '',
    codepage: n.attrs.CODEPAGE ?? '',
    databaseType: n.attrs.DATABASETYPE ?? '',
    folders: childrenOf(n, 'FOLDER').map(buildFolder),
    attrs: freezeAttrs(n.attrs),
  }
}

function buildFolder(n: RawNode): Folder {
  return {
    name: n.attrs.NAME ?? '',
    description: n.attrs.DESCRIPTION ?? '',
    owner: n.attrs.OWNER ?? '',
    shared: (n.attrs.SHARED ?? '').toUpperCase() === 'SHARED',
    sources: childrenOf(n, 'SOURCE').map(buildSource),
    targets: childrenOf(n, 'TARGET').map(buildTarget),
    transformations: childrenOf(n, 'TRANSFORMATION').map(buildTransformation),
    shortcuts: childrenOf(n, 'SHORTCUT').map(buildShortcut),
    mappings: childrenOf(n, 'MAPPING').map(buildMapping),
    workflows: childrenOf(n, 'WORKFLOW').map(buildWorkflow),
    attrs: freezeAttrs(n.attrs),
  }
}

function buildSource(n: RawNode): Source {
  const flat = n.children.find((c) => c.tag === 'FLATFILE')
  return {
    name: n.attrs.NAME ?? '',
    databaseType: n.attrs.DATABASETYPE ?? '',
    dbdName: n.attrs.DBDNAME ?? '',
    ownerName: n.attrs.OWNERNAME ?? '',
    description: n.attrs.DESCRIPTION ?? '',
    isFlatFile: (n.attrs.DATABASETYPE ?? '').toLowerCase() === 'flat file' || !!flat,
    flatFile: flat ? { attrs: freezeAttrs(flat.attrs) } : undefined,
    fields: childrenOf(n, 'SOURCEFIELD').map(buildSourceField),
    tableAttributes: childrenOf(n, 'TABLEATTRIBUTE').map((c) => ({
      name: c.attrs.NAME ?? '', value: c.attrs.VALUE ?? '',
    })),
    attrs: freezeAttrs(n.attrs),
  }
}

function buildSourceField(n: RawNode): SourceField {
  return {
    name: n.attrs.NAME ?? '',
    dataType: n.attrs.DATATYPE ?? '',
    precision: n.attrs.PRECISION ?? '',
    scale: n.attrs.SCALE ?? '',
    keyType: n.attrs.KEYTYPE ?? '',
    nullable: n.attrs.NULLABLE ?? '',
    fieldNumber: n.attrs.FIELDNUMBER ?? '',
    attrs: freezeAttrs(n.attrs),
  }
}

function buildTarget(n: RawNode): Target {
  return {
    name: n.attrs.NAME ?? '',
    databaseType: n.attrs.DATABASETYPE ?? '',
    description: n.attrs.DESCRIPTION ?? '',
    fields: childrenOf(n, 'TARGETFIELD').map(buildTargetField),
    tableAttributes: childrenOf(n, 'TABLEATTRIBUTE').map((c) => ({
      name: c.attrs.NAME ?? '', value: c.attrs.VALUE ?? '',
    })),
    attrs: freezeAttrs(n.attrs),
  }
}

function buildTargetField(n: RawNode): TargetField {
  return {
    name: n.attrs.NAME ?? '',
    dataType: n.attrs.DATATYPE ?? '',
    precision: n.attrs.PRECISION ?? '',
    scale: n.attrs.SCALE ?? '',
    keyType: n.attrs.KEYTYPE ?? '',
    nullable: n.attrs.NULLABLE ?? '',
    fieldNumber: n.attrs.FIELDNUMBER ?? '',
    attrs: freezeAttrs(n.attrs),
  }
}

function buildTransformation(n: RawNode): Transformation {
  const fields: Field[] = childrenOf(n, 'TRANSFORMFIELD').map((c) => ({
    name: c.attrs.NAME ?? '',
    portType: c.attrs.PORTTYPE ?? '',
    dataType: c.attrs.DATATYPE ?? '',
    precision: c.attrs.PRECISION ?? '',
    scale: c.attrs.SCALE ?? '',
    expression: c.attrs.EXPRESSION ?? '',
    group: c.attrs.GROUP,
    isGroupBy: boolAttr(c.attrs.ISGROUPBY),
    sortKey: boolAttr(c.attrs.SORTKEY),
    sortDirection: c.attrs.SORTDIRECTION,
    rankIndex: boolAttr(c.attrs.RANKINDEX),
    attrs: freezeAttrs(c.attrs),
  }))
  const groups: GroupDef[] = childrenOf(n, 'GROUP').map((c) => ({
    name: c.attrs.NAME ?? '',
    type: (c.attrs.TYPE === 'INPUT' ? 'INPUT' : 'OUTPUT'),
    order: Number(c.attrs.ORDER ?? 0),
    attrs: freezeAttrs(c.attrs),
  }))
  const tableAttributes = childrenOf(n, 'TABLEATTRIBUTE').map((c) => ({
    name: c.attrs.NAME ?? '', value: c.attrs.VALUE ?? '',
  }))
  const initProps: InitProp[] = childrenOf(n, 'INITPROP').map((c) => ({
    name: c.attrs.NAME ?? '', value: c.attrs.VALUE ?? '',
  }))
  return {
    name: n.attrs.NAME ?? '',
    type: n.attrs.TYPE ?? '',
    reusable: boolAttr(n.attrs.REUSABLE),
    description: n.attrs.DESCRIPTION ?? '',
    fields, groups, tableAttributes, initProps,
    attrs: freezeAttrs(n.attrs),
  }
}

function buildShortcut(n: RawNode): Shortcut {
  return {
    name: n.attrs.NAME ?? '',
    objectType: n.attrs.OBJECTTYPE ?? '',
    refFolder: n.attrs.REFOBJECTFOLDERNAME ?? n.attrs.FOLDERNAME ?? '',
    refObject: n.attrs.REFOBJECTNAME ?? n.attrs.OBJECTNAME ?? '',
    refRepository: n.attrs.REFOBJECTREPOSITORYNAME ?? n.attrs.REPOSITORYNAME ?? '',
    referenceType: n.attrs.REFERENCETYPE ?? '',
    attrs: freezeAttrs(n.attrs),
  }
}

function buildMapping(n: RawNode): Mapping {
  const transformations = childrenOf(n, 'TRANSFORMATION').map(buildTransformation)
  const instances: Instance[] = childrenOf(n, 'INSTANCE').map((c) => ({
    name: c.attrs.NAME ?? '',
    type: ((c.attrs.TYPE === 'SOURCE' || c.attrs.TYPE === 'TARGET')
      ? c.attrs.TYPE : 'TRANSFORMATION'),
    transformationName: c.attrs.TRANSFORMATION_NAME ?? '',
    transformationType: c.attrs.TRANSFORMATION_TYPE ?? '',
    reusable: boolAttr(c.attrs.REUSABLE),
    associatedSourceInstance: c.children.find((x) => x.tag === 'ASSOCIATED_SOURCE_INSTANCE')?.attrs.NAME,
    description: c.attrs.DESCRIPTION ?? '',
    attrs: freezeAttrs(c.attrs),
  }))
  const connectors: Connector[] = childrenOf(n, 'CONNECTOR').map((c) => ({
    fromInstance: c.attrs.FROMINSTANCE ?? '',
    fromField: c.attrs.FROMFIELD ?? '',
    fromGroup: c.attrs.FROMINSTANCEFIELDGROUP,
    fromInstanceType: c.attrs.FROMINSTANCETYPE,
    toInstance: c.attrs.TOINSTANCE ?? '',
    toField: c.attrs.TOFIELD ?? '',
    toGroup: c.attrs.TOINSTANCEFIELDGROUP,
    toInstanceType: c.attrs.TOINSTANCETYPE,
    attrs: freezeAttrs(c.attrs),
  }))
  const mappingVariables: MappingVariable[] = childrenOf(n, 'MAPPINGVARIABLE').map((c) => ({
    name: c.attrs.NAME ?? '',
    dataType: c.attrs.DATATYPE ?? '',
    precision: c.attrs.PRECISION ?? '',
    scale: c.attrs.SCALE ?? '',
    aggregationType: c.attrs.AGGREGATIONTYPE ?? '',
    defaultValue: c.attrs.DEFAULTVALUE ?? '',
    description: c.attrs.DESCRIPTION ?? '',
    userDefined: boolAttr(c.attrs.USERDEFINED),
    attrs: freezeAttrs(c.attrs),
  }))
  const targetLoadOrder: TargetLoadOrder[] = childrenOf(n, 'TARGETLOADORDER').map((c) => ({
    targetInstance: c.attrs.TARGETINSTANCE ?? '',
    order: Number(c.attrs.ORDER ?? 0),
  }))
  return {
    name: n.attrs.NAME ?? '',
    description: n.attrs.DESCRIPTION ?? '',
    isValid: boolAttr(n.attrs.ISVALID),
    transformations, instances, connectors, mappingVariables, targetLoadOrder,
    attrs: freezeAttrs(n.attrs),
  }
}

function buildWorkflow(n: RawNode): Workflow {
  const sessions: Session[] = childrenOf(n, 'SESSION').map((c) => ({
    name: c.attrs.NAME ?? '',
    mappingName: c.attrs.MAPPINGNAME ?? '',
    description: c.attrs.DESCRIPTION ?? '',
    reusable: boolAttr(c.attrs.REUSABLE),
    attributes: childrenOf(c, 'ATTRIBUTE').map((a) => ({
      name: a.attrs.NAME ?? '', value: a.attrs.VALUE ?? '',
    })),
    attrs: freezeAttrs(c.attrs),
  }))
  const tasks: Task[] = childrenOf(n, 'TASK').map((c) => ({
    name: c.attrs.NAME ?? '',
    type: c.attrs.TYPE ?? '',
    reusable: boolAttr(c.attrs.REUSABLE),
    description: c.attrs.DESCRIPTION ?? '',
    attrs: freezeAttrs(c.attrs),
  }))
  const links: WorkflowLink[] = childrenOf(n, 'WORKFLOWLINK').map((c) => ({
    fromTask: c.attrs.FROMTASK ?? '',
    toTask: c.attrs.TOTASK ?? '',
    condition: c.attrs.CONDITION ?? '',
    attrs: freezeAttrs(c.attrs),
  }))
  return {
    name: n.attrs.NAME ?? '',
    description: n.attrs.DESCRIPTION ?? '',
    isValid: boolAttr(n.attrs.ISVALID),
    sessions, tasks, links,
    attrs: freezeAttrs(n.attrs),
  }
}

// ---- Index helpers ----------------------------------------------------

export function indexFolder(f: Folder) {
  return {
    sources: new Map(f.sources.map((s) => [s.name, s])),
    targets: new Map(f.targets.map((t) => [t.name, t])),
    transformations: new Map(f.transformations.map((t) => [t.name, t])),
    shortcuts: new Map(f.shortcuts.map((s) => [s.name, s])),
    mappings: new Map(f.mappings.map((m) => [m.name, m])),
    workflows: new Map(f.workflows.map((w) => [w.name, w])),
  }
}

/** Return the Transformation (reusable or inline) that an INSTANCE references. */
export function resolveInstanceTransformation(
  mapping: Mapping, folder: Folder, instance: Instance,
): Transformation | Source | Target | Shortcut | undefined {
  if (instance.type === 'SOURCE') {
    return folder.sources.find((s) => s.name === instance.transformationName)
        ?? folder.shortcuts.find((s) => s.name === instance.transformationName)
  }
  if (instance.type === 'TARGET') {
    return folder.targets.find((t) => t.name === instance.transformationName)
        ?? folder.shortcuts.find((s) => s.name === instance.transformationName)
  }
  return mapping.transformations.find((t) => t.name === instance.transformationName)
      ?? folder.transformations.find((t) => t.name === instance.transformationName)
      ?? folder.shortcuts.find((s) => s.name === instance.transformationName)
}
