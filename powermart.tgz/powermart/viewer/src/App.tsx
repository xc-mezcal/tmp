import { useCallback, useEffect, useMemo, useState } from 'react'
import { parsePowermart, type ParseProgress } from './parser'
import type { PowermartModel, SelectedObject } from './ir'
import { TreeBrowser } from './TreeBrowser'
import { Detail } from './Detail'

function humanBytes(n: number): string {
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`
}

export default function App() {
  const [model, setModel] = useState<PowermartModel | null>(null)
  const [rawText, setRawText] = useState<string>('')
  const [progress, setProgress] = useState<ParseProgress | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [selected, setSelected] = useState<SelectedObject | null>(null)
  const [dragging, setDragging] = useState(false)
  const [loadedName, setLoadedName] = useState<string>('')

  const loadText = useCallback(async (text: string, name: string) => {
    setError(null)
    setSelected(null)
    setProgress({ bytesRead: 0, totalBytes: text.length, phase: 'parsing' })
    try {
      const m = await parsePowermart(text, (p) => setProgress(p))
      setModel(m)
      setRawText(text)
      setLoadedName(name)
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setProgress(null)
    }
  }, [])

  const onFile = useCallback(async (file: File) => {
    const text = await file.text()
    await loadText(text, file.name)
  }, [loadText])

  const loadSample = useCallback(async () => {
    const r = await fetch('/sample.xml')
    const text = await r.text()
    await loadText(text, 'sample.xml')
  }, [loadText])

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) onFile(file)
  }, [onFile])

  // Keep content panel's selection addressable from URL fragment (optional nicety).
  useEffect(() => {
    if (!selected) return
    const parts = [selected.kind, selected.folder, (selected as any).name ?? '']
    history.replaceState(null, '', `#${parts.filter(Boolean).join('/')}`)
  }, [selected])

  const folderStats = useMemo(() => {
    if (!model) return null
    let sources = 0, targets = 0, xf = 0, mappings = 0, shortcuts = 0
    for (const r of model.repositories) {
      for (const f of r.folders) {
        sources += f.sources.length
        targets += f.targets.length
        xf += f.transformations.length + f.mappings.reduce((a, m) => a + m.transformations.length, 0)
        mappings += f.mappings.length
        shortcuts += f.shortcuts.length
      }
    }
    return { sources, targets, xf, mappings, shortcuts }
  }, [model])

  return (
    <div className="app">
      <div className="topbar">
        <div className="title">
          Powermart <span className="dim">viewer</span>
        </div>
        {model && (
          <>
            <div className="meta">
              {loadedName} &middot; {humanBytes(model.sourceSize)} &middot;{' '}
              {model.repositories.length} repo
              {model.repositories.length === 1 ? '' : 's'}
              {folderStats && (
                <>
                  {' '}&middot; {folderStats.sources} src, {folderStats.targets} tgt,{' '}
                  {folderStats.xf} xf, {folderStats.mappings} map,{' '}
                  {folderStats.shortcuts} sc
                </>
              )}
            </div>
          </>
        )}
        <div className="spacer" />
        {model && (
          <>
            <label>
              <input type="file" accept=".xml" style={{ display: 'none' }}
                     onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
              <span className="" style={{ display: 'inline-block' }}>
                <button onClick={(e) => (e.currentTarget.parentElement!.previousSibling as HTMLInputElement).click()}>
                  Open XML…
                </button>
              </span>
            </label>
            <button onClick={loadSample}>Reload sample</button>
          </>
        )}
      </div>

      {!model ? (
        <div
          className={`drop-zone ${dragging ? 'dragging' : ''}`}
          onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
        >
          <div className="card">
            <h1>Drop a Powermart XML here</h1>
            <div>Or load the bundled <code>sample.xml</code>.</div>
            <div className="actions">
              <label>
                <input type="file" accept=".xml"
                       onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
                <button onClick={(e) => (e.currentTarget.previousSibling as HTMLInputElement).click()}>
                  Choose file…
                </button>
              </label>
              <button onClick={loadSample}>Load bundled sample</button>
            </div>
            {progress && (
              <div>
                <div style={{ marginTop: 18 }}>
                  {progress.phase === 'parsing' && 'Parsing XML…'}
                  {progress.phase === 'building' && 'Building model…'}
                  {progress.phase === 'done' && 'Done.'}
                </div>
                <div className="progress">
                  <div style={{ width: `${Math.min(100, (progress.bytesRead / Math.max(progress.totalBytes, 1)) * 100)}%` }} />
                </div>
              </div>
            )}
            {error && (
              <div style={{ color: 'var(--danger)', marginTop: 18 }}>
                Parse error: {error}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="workspace">
          <aside className="sidebar">
            <TreeBrowser
              model={model}
              selected={selected}
              onSelect={setSelected}
            />
          </aside>
          <main className="content">
            <Detail model={model} rawText={rawText} selected={selected}
                    onSelect={setSelected} />
          </main>
        </div>
      )}
    </div>
  )
}
