import { useEffect, useMemo, useRef, useState } from 'react'
import {
  Background, Controls, Handle, MiniMap, Position, ReactFlow,
  type Edge, type Node, type NodeProps,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import ELK from 'elkjs/lib/elk.bundled.js'
import type { Folder, Instance, Mapping } from './ir'
import { TransformationDetail, RawXmlForName } from './Detail'

type Props = {
  folder: Folder
  mapping: Mapping
  rawText: string
  onSelectInstance: (name: string) => void
}

type PmNodeData = {
  label: string
  subtitle: string
  kind: 'SOURCE' | 'TARGET' | 'TRANSFORMATION'
  selected: boolean
}

function PmNode({ data }: NodeProps<Node<PmNodeData>>) {
  const cls = data.kind === 'SOURCE' ? 'source'
           : data.kind === 'TARGET' ? 'target' : 'transform'
  return (
    <div className={`pm-node ${cls} ${data.selected ? 'selected' : ''}`}>
      <Handle type="target" position={Position.Left} style={{ background: '#555' }} />
      <div className="pm-title">{data.label}</div>
      <div className="pm-subtitle">{data.subtitle}</div>
      <Handle type="source" position={Position.Right} style={{ background: '#555' }} />
    </div>
  )
}

const nodeTypes = { pm: PmNode }

const elk = new ELK()

export function MappingGraph({ folder, mapping, rawText, onSelectInstance }: Props) {
  const [nodes, setNodes] = useState<Node<PmNodeData>[]>([])
  const [edges, setEdges] = useState<Edge[]>([])
  const [drawerInstance, setDrawerInstance] = useState<string | null>(null)
  const layoutKey = useRef(0)

  // Build unlaid-out nodes + edges from the mapping.
  const { rawNodes, rawEdges } = useMemo(() => {
    const nodes: Node<PmNodeData>[] = mapping.instances.map((inst) => ({
      id: inst.name,
      type: 'pm',
      position: { x: 0, y: 0 },
      data: {
        label: inst.name,
        subtitle: subtitleFor(inst),
        kind: inst.type,
        selected: false,
      },
    }))
    // Deduplicate instance-level edges (multiple field-level connectors
    // between the same pair collapse into one visual edge).
    const seen = new Set<string>()
    const edges: Edge[] = []
    for (const c of mapping.connectors) {
      const key = `${c.fromInstance}→${c.toInstance}`
      if (seen.has(key)) continue
      seen.add(key)
      const fieldCount = mapping.connectors.filter(
        (x) => x.fromInstance === c.fromInstance && x.toInstance === c.toInstance,
      ).length
      edges.push({
        id: `e:${c.fromInstance}:${c.toInstance}`,
        source: c.fromInstance,
        target: c.toInstance,
        label: fieldCount > 1 ? `${fieldCount}` : undefined,
        style: { stroke: '#7c8ab0', strokeWidth: 1.5 },
        labelStyle: { fill: '#9aa3b2', fontSize: 10 },
        labelBgStyle: { fill: '#161a22' },
      })
    }
    return { rawNodes: nodes, rawEdges: edges }
  }, [mapping])

  // Compute layout with elkjs whenever the mapping changes.
  useEffect(() => {
    let cancelled = false
    const key = ++layoutKey.current
    setNodes(rawNodes.map((n) => ({ ...n })))
    setEdges(rawEdges)

    const graph = {
      id: 'root',
      layoutOptions: {
        'elk.algorithm': 'layered',
        'elk.direction': 'RIGHT',
        'elk.layered.spacing.nodeNodeBetweenLayers': '90',
        'elk.spacing.nodeNode': '40',
        'elk.layered.nodePlacement.strategy': 'NETWORK_SIMPLEX',
      },
      children: rawNodes.map((n) => ({
        id: n.id, width: 200, height: 64,
      })),
      edges: rawEdges.map((e) => ({
        id: e.id, sources: [e.source], targets: [e.target],
      })),
    }
    elk.layout(graph as any).then((res) => {
      if (cancelled || key !== layoutKey.current) return
      const posById = new Map<string, { x: number; y: number }>()
      for (const c of res.children ?? []) {
        posById.set(c.id!, { x: c.x ?? 0, y: c.y ?? 0 })
      }
      setNodes((curr) => curr.map((n) => ({
        ...n,
        position: posById.get(n.id) ?? n.position,
      })))
    }).catch((err) => {
      // Layout failed — fall back to grid.
      if (cancelled) return
      setNodes((curr) => curr.map((n, idx) => ({
        ...n,
        position: { x: (idx % 6) * 240, y: Math.floor(idx / 6) * 120 },
      })))
      // eslint-disable-next-line no-console
      console.warn('ELK layout failed:', err)
    })
    return () => { cancelled = true }
  }, [rawNodes, rawEdges])

  // Selection highlight.
  useEffect(() => {
    setNodes((curr) => curr.map((n) => ({
      ...n,
      data: { ...n.data, selected: n.id === drawerInstance },
    })))
  }, [drawerInstance])

  const drawerInst = drawerInstance
    ? mapping.instances.find((i) => i.name === drawerInstance)
    : null
  const resolved = drawerInst
    ? resolveForInstance(folder, mapping, drawerInst)
    : null

  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: 0.15 }}
        proOptions={{ hideAttribution: true }}
        onNodeClick={(_e, node) => {
          setDrawerInstance(node.id)
          onSelectInstance(node.id)
        }}
        onPaneClick={() => setDrawerInstance(null)}
      >
        <Background color="#2a3042" gap={24} />
        <Controls showInteractive={false} />
        <MiniMap
          pannable zoomable
          nodeColor={(n) => {
            const k = (n.data as PmNodeData)?.kind
            return k === 'SOURCE' ? '#f4a261'
                 : k === 'TARGET' ? '#2a9d8f'
                 : '#8b9dfb'
          }}
          maskColor="rgba(0,0,0,0.5)"
          style={{ background: '#0f1115', border: '1px solid #2a3042' }}
        />
      </ReactFlow>

      {drawerInst && (
        <div className="drawer">
          <div className="drawer-close">
            <div>
              <b>{drawerInst.name}</b>{' '}
              <span className="subtle">{drawerInst.type}
                {drawerInst.transformationType && ` / ${drawerInst.transformationType}`}</span>
            </div>
            <button onClick={() => setDrawerInstance(null)}>Close</button>
          </div>
          {resolved?.kind === 'transformation' && (
            <TransformationDetail folder={folder} obj={resolved.obj} rawText={rawText}
                                  reusable={resolved.reusable} inMapping={mapping} />
          )}
          {resolved?.kind === 'source' && (
            <div className="detail">
              <h2>{resolved.obj.name} <span className="pill">SOURCE</span></h2>
              <div className="subtle">Referenced from this mapping as <code>{drawerInst.name}</code></div>
              <RawXmlForName rawText={rawText} tag="SOURCE" name={resolved.obj.name} />
            </div>
          )}
          {resolved?.kind === 'target' && (
            <div className="detail">
              <h2>{resolved.obj.name} <span className="pill">TARGET</span></h2>
              <div className="subtle">Referenced from this mapping as <code>{drawerInst.name}</code></div>
              <RawXmlForName rawText={rawText} tag="TARGET" name={resolved.obj.name} />
            </div>
          )}
          {resolved?.kind === 'shortcut' && (
            <div className="detail">
              <h2>{resolved.obj.name} <span className="pill">SHORTCUT</span></h2>
              <div className="subtle">
                Points to {resolved.obj.refFolder}/{resolved.obj.refObject} ({resolved.obj.objectType})
              </div>
            </div>
          )}
          {!resolved && (
            <div className="detail"><div className="subtle">Reference not found.</div></div>
          )}
        </div>
      )}
    </div>
  )
}

function subtitleFor(inst: Instance): string {
  if (inst.type === 'SOURCE') return `SOURCE → ${inst.transformationName}`
  if (inst.type === 'TARGET') return `TARGET → ${inst.transformationName}`
  const bits = [inst.transformationType || 'TRANSFORMATION']
  if (inst.reusable) bits.push('reusable')
  if (inst.associatedSourceInstance) bits.push(`src: ${inst.associatedSourceInstance}`)
  return bits.join(' · ')
}

type Resolved =
  | { kind: 'transformation'; obj: import('./ir').Transformation; reusable: boolean }
  | { kind: 'source'; obj: import('./ir').Source }
  | { kind: 'target'; obj: import('./ir').Target }
  | { kind: 'shortcut'; obj: import('./ir').Shortcut }

function resolveForInstance(folder: Folder, mapping: Mapping, inst: Instance): Resolved | null {
  if (inst.type === 'SOURCE') {
    const s = folder.sources.find((x) => x.name === inst.transformationName)
    if (s) return { kind: 'source', obj: s }
    const sc = folder.shortcuts.find((x) => x.name === inst.transformationName)
    if (sc) return { kind: 'shortcut', obj: sc }
    return null
  }
  if (inst.type === 'TARGET') {
    const t = folder.targets.find((x) => x.name === inst.transformationName)
    if (t) return { kind: 'target', obj: t }
    const sc = folder.shortcuts.find((x) => x.name === inst.transformationName)
    if (sc) return { kind: 'shortcut', obj: sc }
    return null
  }
  const inline = mapping.transformations.find((t) => t.name === inst.transformationName)
  if (inline) return { kind: 'transformation', obj: inline, reusable: false }
  const reusable = folder.transformations.find((t) => t.name === inst.transformationName)
  if (reusable) return { kind: 'transformation', obj: reusable, reusable: true }
  const sc = folder.shortcuts.find((x) => x.name === inst.transformationName)
  if (sc) return { kind: 'shortcut', obj: sc }
  return null
}
