"""
Lineage graph viewer.
=====================
Converts a LineageDAG into a standalone interactive HTML file using
Cytoscape.js. Nodes are SQL scopes (base tables / CTEs / subqueries /
INSERT targets); clicking a node or edge opens a side panel with
column-level details, predicates, and clause info.

Dependencies:
  - None on the Python side beyond the stdlib.
  - Browser-side: Cytoscape.js loaded from CDN by default. Pass a local
    path to `cytoscape_js_path` to inline a vendored copy for offline use.

Usage:
    from oracle_sql_analyzer import analyze_file
    from lineage_viewer import render_lineage_html
    report, df = analyze_file("script.sql")
    # `analyze_file` doesn't currently return the dag — call from the
    # pieces exposed in `report` or refactor `analyze_file` to return it.
    # For now this module accepts a LineageDAG instance directly.
"""

import json
from collections import defaultdict
from pathlib import Path
from typing import Optional


CDN_URL = "https://cdn.jsdelivr.net/npm/cytoscape@3.30.2/dist/cytoscape.min.js"

# Vendored JS auto-detection. Any of these files sitting next to the module
# (or in CWD) will be inlined into the generated HTML for fully-offline use.
_HERE = Path(__file__).resolve().parent

def _find_vendor(name: str) -> Optional[Path]:
    for p in (_HERE / name, Path.cwd() / name):
        if p.exists():
            return p
    return None

DEFAULT_CYTOSCAPE_JS = _find_vendor("cytoscape.min.js")
DEFAULT_DAGRE_JS = _find_vendor("dagre.min.js")
DEFAULT_CYTOSCAPE_DAGRE_JS = _find_vendor("cytoscape-dagre.js") or _find_vendor("cytoscape-dagre.min.js")


# ---------------------------------------------------------------------------
# Build graph model from the flat edge list
# ---------------------------------------------------------------------------

def build_graph_model(edges: list[dict]) -> dict:
    """
    Collapse flat column-level edges into a node/edge model suitable for
    Cytoscape. Tracks three pieces of node metadata beyond the basics:

      - columns: the scope's *produced* output columns (projection/base
        edges only; filter edges never add columns).
      - column_provenance: {out_col: [{src_node, src_col, ambiguous}, ...]}
        — where each produced column came from.
      - filter_references: {clause: [{src_node, src_col, ambiguous}, ...]}
        — what this scope's WHERE/JOIN_ON/HAVING/etc. clauses look at.
      - column_roles: {col: [clauses]} — where a column appears as a
        source across the file (used on base-table nodes mostly).

    Node type inferred only from projection / base edges.
    """
    type_rank = {"base": 0, "subquery": 1, "cte": 2, "root": 3}

    nodes: dict[str, dict] = {}
    proj_agg: dict[tuple, list] = defaultdict(list)
    filt_agg: dict[tuple, list] = defaultdict(list)

    def ensure_node(name: str, block_index: int):
        if not name:
            return None
        node = nodes.setdefault(name, {
            "id": name,
            "label": _clean_label(name),
            "type": "base",
            "columns": set(),
            "column_provenance": defaultdict(list),
            "filter_references": defaultdict(list),
            "column_roles": defaultdict(set),
            "block_indexes": set(),
        })
        node["block_indexes"].add(block_index)
        return node

    def promote_type(name: str, scope_type: str):
        if not name or scope_type == "filter":
            return
        node = nodes.get(name)
        if node is None:
            return
        if type_rank.get(scope_type, -1) > type_rank.get(node["type"], -1):
            node["type"] = scope_type

    for e in edges:
        out_tbl = e["output_table"]
        out_col = e["output_column"]
        src_tbl = e["source_table"]
        src_col = e["source_column"]
        scope = e["scope_type"]
        clause = e["clause"]
        block = e["block_index"]
        ambiguous = e.get("ambiguous", False)
        unqualified = e.get("unqualified", False)

        out_node = ensure_node(out_tbl, block)
        promote_type(out_tbl, scope)

        # Base leaf edges: the output IS a base column reference. Tag role
        # but don't add provenance (there's no upstream).
        if src_tbl is None:
            if out_node is not None and out_col:
                out_node["columns"].add(out_col)
                out_node["column_roles"][out_col].add(clause)
            continue

        # Literal-sourced column: record it as produced but with no upstream.
        if src_tbl == "__LITERAL":
            if out_node is not None and out_col and scope != "filter":
                out_node["columns"].add(out_col)
                out_node["column_provenance"][out_col].append({
                    "src_node": "__LITERAL", "src_col": None,
                    "ambiguous": False, "unqualified": False, "clause": clause,
                })
            continue

        ensure_node(src_tbl, block)
        if src_col:
            nodes[src_tbl]["columns"].add(src_col)
            nodes[src_tbl]["column_roles"][src_col].add(clause)

        pair = {
            "src_col": src_col, "out_col": out_col, "clause": clause,
            "ambiguous": ambiguous, "unqualified": unqualified, "block": block,
        }

        if scope == "filter":
            filt_agg[(src_tbl, out_tbl)].append(pair)
            if out_node is not None:
                out_node["filter_references"][clause].append({
                    "src_node": src_tbl, "src_col": src_col,
                    "ambiguous": ambiguous, "unqualified": unqualified,
                })
        else:
            proj_agg[(src_tbl, out_tbl)].append(pair)
            if out_node is not None and out_col:
                out_node["columns"].add(out_col)
                out_node["column_provenance"][out_col].append({
                    "src_node": src_tbl, "src_col": src_col,
                    "ambiguous": ambiguous, "unqualified": unqualified,
                    "clause": clause,
                })

    edge_records = []
    for (src, tgt), pairs in proj_agg.items():
        breakdown = defaultdict(int)
        for p in pairs:
            breakdown[p["clause"]] += 1
        edge_records.append({
            "id": f"proj__{src}__{tgt}",
            "source": src, "target": tgt, "kind": "projection",
            "clause_breakdown": dict(breakdown), "pairs": pairs,
        })
    for (src, tgt), pairs in filt_agg.items():
        breakdown = defaultdict(int)
        for p in pairs:
            breakdown[p["clause"]] += 1
        edge_records.append({
            "id": f"filt__{src}__{tgt}",
            "source": src, "target": tgt, "kind": "filter",
            "clause_breakdown": dict(breakdown), "pairs": pairs,
        })

    node_records = []
    for n in nodes.values():
        node_records.append({
            "id": n["id"], "label": n["label"], "type": n["type"],
            "synthetic": n["id"].startswith("__") and not n["id"].startswith("__ROOT_BLOCK_"),
            "columns": sorted(n["columns"]),
            "column_provenance": {c: p for c, p in n["column_provenance"].items()},
            "filter_references": {c: r for c, r in n["filter_references"].items()},
            "column_roles": {c: sorted(cs) for c, cs in n["column_roles"].items()},
            "block_indexes": sorted(n["block_indexes"]),
        })

    return {"nodes": node_records, "edges": edge_records}


def _clean_label(name: str) -> str:
    """Turn internal scope names into friendlier labels."""
    if name.startswith("__ROOT_BLOCK_"):
        return "ROOT (block " + name.split("_")[-1] + ")"
    if name == "__SCALAR":
        return "⟨scalar subq⟩"
    if name == "__WHERE_SUBQ":
        return "⟨where subq⟩"
    if name.startswith("__SUBQ"):
        return "⟨subq⟩"
    return name


# ---------------------------------------------------------------------------
# HTML rendering
# ---------------------------------------------------------------------------

def render_lineage_html(
    dag_or_edges,
    out_path: str,
    title: str = "SQL Lineage",
    cytoscape_js_path: Optional[str] = None,
    dagre_js_path: Optional[str] = None,
    cytoscape_dagre_js_path: Optional[str] = None,
) -> str:
    """
    Emit a standalone HTML file with an interactive lineage graph.

    Args:
        dag_or_edges: a LineageDAG instance (uses `.edges`) or a list of edge
            dicts in the same shape.
        out_path: destination HTML file path.
        title: page title.
        cytoscape_js_path: if given, the file's contents are inlined in a
            <script> tag for offline use. Otherwise a CDN <script src=...>
            is emitted.

    Returns the out_path.
    """
    edges = dag_or_edges.edges if hasattr(dag_or_edges, "edges") else dag_or_edges
    graph = build_graph_model(edges)

    graph_json = json.dumps(graph, indent=2)

    # If caller didn't specify, fall back to vendored files next to the module
    # or in CWD, so the HTML works offline by default.
    if cytoscape_js_path is None and DEFAULT_CYTOSCAPE_JS is not None:
        cytoscape_js_path = str(DEFAULT_CYTOSCAPE_JS)
    if dagre_js_path is None and DEFAULT_DAGRE_JS is not None:
        dagre_js_path = str(DEFAULT_DAGRE_JS)
    if cytoscape_dagre_js_path is None and DEFAULT_CYTOSCAPE_DAGRE_JS is not None:
        cytoscape_dagre_js_path = str(DEFAULT_CYTOSCAPE_DAGRE_JS)

    def _inline_or_cdn(local: Optional[str], cdn: str) -> str:
        if local:
            return f"<script>{Path(local).read_text(encoding='utf-8')}</script>"
        return f'<script src="{cdn}"></script>'

    cytoscape_tag = _inline_or_cdn(cytoscape_js_path, CDN_URL)

    # dagre is optional — only emit the tags and enable the dagre layout
    # if both dagre + cytoscape-dagre are available (inline or CDN allowed).
    dagre_enabled = bool(dagre_js_path and cytoscape_dagre_js_path)
    dagre_tag = ""
    if dagre_enabled:
        dagre_tag = (
            _inline_or_cdn(dagre_js_path, "https://unpkg.com/dagre@0.8.5/dist/dagre.min.js")
            + "\n"
            + _inline_or_cdn(cytoscape_dagre_js_path,
                             "https://unpkg.com/cytoscape-dagre@2.5.0/cytoscape-dagre.js")
        )

    html = _HTML_TEMPLATE.format(
        title=title,
        cytoscape_tag=cytoscape_tag,
        dagre_tag=dagre_tag,
        dagre_enabled="true" if dagre_enabled else "false",
        graph_json=graph_json,
    )

    Path(out_path).write_text(html, encoding="utf-8")
    return out_path


# ---------------------------------------------------------------------------
# One-shot wrapper: .sql → .html
# ---------------------------------------------------------------------------

def view_sql_file(sql_path: str, out_path: Optional[str] = None,
                  cytoscape_js_path: Optional[str] = None,
                  dagre_js_path: Optional[str] = None,
                  cytoscape_dagre_js_path: Optional[str] = None) -> str:
    """
    Parse a PL/SQL file and render its lineage graph to HTML in one call.

    - `out_path` defaults to the input's stem with a `.html` extension,
      written next to the input file (e.g., `foo.sql` → `foo.html`).
    - `cytoscape_js_path` defaults to a local `cytoscape.min.js` next to
      this module or in CWD. Falls back to the CDN only if neither exists.
    """
    # Local import keeps this module import-safe even if the analyzer
    # pulls in optional deps the caller doesn't have.
    from oracle_sql_analyzer import (
        LineageDAG, process_block, extract_execute_immediate_blocks,
        extract_direct_sql_blocks, clean_sql_for_parsing, clean_direct_sql,
        _parse_declare_variables,
    )

    sql_p = Path(sql_path)
    if out_path is None:
        out_path = str(sql_p.with_suffix(".html"))

    text = sql_p.read_text(encoding="utf-8", errors="replace")
    raw_blocks = extract_execute_immediate_blocks(text)
    mode = "execute_immediate"
    if not raw_blocks:
        raw_blocks = extract_direct_sql_blocks(text)
        mode = "direct_sql"
    if not raw_blocks:
        raw_blocks = [text]
        mode = "raw"

    plsql_vars = _parse_declare_variables(text) if mode == "direct_sql" else set()
    dag = LineageDAG()
    for i, raw in enumerate(raw_blocks):
        cleaned = (clean_direct_sql(raw, plsql_vars) if mode == "direct_sql"
                   else clean_sql_for_parsing(raw))
        process_block(cleaned, dag, block_index=i + 1)

    return render_lineage_html(
        dag, out_path,
        title=f"Lineage — {sql_p.name}",
        cytoscape_js_path=cytoscape_js_path,
        dagre_js_path=dagre_js_path,
        cytoscape_dagre_js_path=cytoscape_dagre_js_path,
    )


# ---------------------------------------------------------------------------
# HTML template
# ---------------------------------------------------------------------------
# Placeholders: {title}, {cytoscape_tag}, {dagre_tag}, {dagre_enabled},
# {graph_json}. All braces in CSS/JS are doubled to survive str.format.

_HTML_TEMPLATE = r"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>{title}</title>
{cytoscape_tag}
{dagre_tag}
<style>
  html, body {{ margin: 0; padding: 0; height: 100%; font-family: -apple-system, Segoe UI, Helvetica, Arial, sans-serif; }}
  #app {{ display: flex; height: 100vh; }}
  #graph {{ flex: 1 1 auto; background: #fafafa; }}
  #side {{
    width: 380px; border-left: 1px solid #ddd; background: #fff;
    overflow-y: auto; padding: 14px 18px; box-sizing: border-box;
  }}
  #side h2 {{ margin: 4px 0 8px; font-size: 16px; }}
  #side .meta {{ color: #666; font-size: 12px; margin-bottom: 10px; }}
  #side .section {{ margin-top: 14px; }}
  #side .section h3 {{ font-size: 12px; text-transform: uppercase; color: #888; margin: 0 0 6px; letter-spacing: 0.04em; }}
  #side ul {{ margin: 0; padding-left: 18px; font-size: 13px; }}
  #side li {{ margin: 2px 0; }}
  #side .tag {{ display: inline-block; padding: 1px 7px; border-radius: 10px; font-size: 11px;
    background: #eef; color: #335; margin-right: 4px; }}
  #side .tag.filter {{ background: #fde; color: #733; }}
  #side .tag.clause-select {{ background: #e4efdc; color: #36602b; }}
  #side .tag.clause-filter {{ background: #fde; color: #733; }}
  #side .tag.clause-join   {{ background: #e3e9fb; color: #2a3d7c; }}
  #side .tag.clause-group  {{ background: #fbecd6; color: #7a4a12; }}
  #side .tag.clause-order  {{ background: #eee; color: #555; }}
  #side table {{ width: 100%; border-collapse: collapse; font-size: 12px; }}
  #side th, #side td {{ text-align: left; padding: 3px 6px; border-bottom: 1px solid #eee; }}
  #toolbar {{ position: absolute; top: 10px; left: 10px; background: #fff;
    border: 1px solid #ddd; border-radius: 4px; padding: 6px 10px; font-size: 12px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.05); }}
  #toolbar label {{ margin-right: 10px; }}
  .empty {{ color: #999; font-style: italic; }}
</style>
</head>
<body>
<div id="app">
  <div id="graph">
    <div id="toolbar">
      <label><input type="checkbox" id="show-filters" checked> Show filter edges</label>
      <label><input type="checkbox" id="show-base" checked> Show base tables</label>
      <label><input type="checkbox" id="show-synthetic" checked> Show synthetic scopes</label>
      <button id="refit">Fit</button>
    </div>
  </div>
  <div id="side">
    <h2>Lineage</h2>
    <div class="meta">Click a node or edge to see details.</div>
    <div id="detail"></div>
  </div>
</div>
<script>
const GRAPH = {graph_json};

const TYPE_COLOR = {{
  base:     '#6a9bd1',
  cte:      '#e0a458',
  subquery: '#a06ac0',
  root:     '#52a46a',
}};

function nodeStyle(n) {{
  return {{
    'background-color': TYPE_COLOR[n.data('type')] || '#888',
    'label': 'data(label)',
    'color': '#fff',
    'text-valign': 'center',
    'text-halign': 'center',
    'font-size': 11,
    'font-weight': 'bold',
    'text-outline-width': 2,
    'text-outline-color': '#333',
    'width': 'label',
    'height': 28,
    'padding': '10px',
    'shape': 'round-rectangle',
  }};
}}

// --- Layout ---
// Prefer dagre (proper crossing reduction) when its JS is inlined.
// Otherwise fall back to a custom layered layout (longest-path rank, LR).
const DAGRE_ENABLED = {dagre_enabled};
if (DAGRE_ENABLED && typeof cytoscapeDagre !== 'undefined') {{
  cytoscape.use(cytoscapeDagre);
}}
const preds = {{}}, succs = {{}};
for (const n of GRAPH.nodes) {{ preds[n.id] = []; succs[n.id] = []; }}
for (const e of GRAPH.edges) {{
  if (preds[e.target] && succs[e.source]) {{
    preds[e.target].push(e.source);
    succs[e.source].push(e.target);
  }}
}}
const rank = {{}};
function computeRank(id, seen) {{
  if (rank[id] !== undefined) return rank[id];
  if (seen.has(id)) return 0;          // cycle guard
  seen.add(id);
  const ps = preds[id] || [];
  const r = ps.length === 0 ? 0 : 1 + Math.max(...ps.map(p => computeRank(p, seen)));
  seen.delete(id);
  rank[id] = r;
  return r;
}}
for (const n of GRAPH.nodes) computeRank(n.id, new Set());
const byRank = {{}};
for (const n of GRAPH.nodes) {{
  (byRank[rank[n.id]] = byRank[rank[n.id]] || []).push(n.id);
}}
const COL_W = 240, ROW_H = 90;
const positions = {{}};
for (const r of Object.keys(byRank)) {{
  const ids = byRank[r].sort();
  const n = ids.length;
  ids.forEach((id, i) => {{
    positions[id] = {{ x: Number(r) * COL_W, y: (i - (n - 1) / 2) * ROW_H }};
  }});
}}

const elements = [];
for (const n of GRAPH.nodes) {{
  elements.push({{
    data: {{
      id: n.id, label: n.label, type: n.type, synthetic: !!n.synthetic,
      columns: n.columns,
      column_roles: n.column_roles || {{}},
      column_provenance: n.column_provenance || {{}},
      filter_references: n.filter_references || {{}},
      block_indexes: n.block_indexes,
    }},
    position: positions[n.id],
  }});
}}
for (const e of GRAPH.edges) {{
  elements.push({{ data: {{
    id: e.id, source: e.source, target: e.target,
    kind: e.kind, clause_breakdown: e.clause_breakdown, pairs: e.pairs,
    label: Object.keys(e.clause_breakdown).join(', '),
  }} }});
}}

const LAYOUT = (DAGRE_ENABLED && typeof cytoscapeDagre !== 'undefined')
  ? {{ name: 'dagre', rankDir: 'LR', nodeSep: 30, rankSep: 90,
       edgeSep: 10, ranker: 'tight-tree', fit: true, padding: 30 }}
  : {{ name: 'preset', padding: 30, fit: true }};

const cy = cytoscape({{
  container: document.getElementById('graph'),
  elements: elements,
  layout: LAYOUT,
  style: [
    {{ selector: 'node', style: {{
      'background-color': ele => TYPE_COLOR[ele.data('type')] || '#888',
      'label': 'data(label)', 'color': '#fff',
      'text-valign': 'center', 'text-halign': 'center',
      'font-size': 11, 'font-weight': 'bold',
      'text-outline-width': 2, 'text-outline-color': '#333',
      'width': 'label', 'height': 28, 'padding': '10px',
      'shape': 'round-rectangle',
    }} }},
    {{ selector: 'node[?synthetic]', style: {{
      'opacity': 0.7, 'font-style': 'italic',
      'border-width': 1, 'border-color': '#888', 'border-style': 'dashed',
    }} }},
    {{ selector: 'edge[kind = "projection"]', style: {{
      'curve-style': 'bezier', 'target-arrow-shape': 'triangle',
      'line-color': '#999', 'target-arrow-color': '#999',
      'width': 2, 'font-size': 9, 'color': '#666',
      'label': 'data(label)', 'text-background-color': '#fafafa',
      'text-background-opacity': 0.9, 'text-background-padding': 2,
    }} }},
    {{ selector: 'edge[kind = "filter"]', style: {{
      'curve-style': 'bezier', 'target-arrow-shape': 'triangle',
      'line-style': 'dashed',
      'line-color': '#d46b7a', 'target-arrow-color': '#d46b7a',
      'width': 1.5, 'font-size': 9, 'color': '#a44',
      'label': 'data(label)',
    }} }},
    {{ selector: ':selected', style: {{
      'border-width': 3, 'border-color': '#222',
      'line-color': '#222', 'target-arrow-color': '#222',
    }} }},
  ],
}});

function esc(s) {{ return String(s == null ? '' : s).replace(/[&<>]/g, c => ({{'&':'&amp;','<':'&lt;','>':'&gt;'}}[c])); }}

const CLAUSE_TAG_CLASS = {{
  SELECT: 'clause-select', WHERE: 'clause-filter',
  JOIN_ON: 'clause-join', GROUP_BY: 'clause-group',
  HAVING: 'clause-filter', ORDER_BY: 'clause-order',
}};

function clauseTag(clause) {{
  const cls = CLAUSE_TAG_CLASS[clause] || '';
  return `<span class="tag ${{cls}}">${{esc(clause)}}</span>`;
}}

function formatSourceRef(s) {{
  // s shape: src_node, src_col, ambiguous, unqualified
  const node = esc(s.src_node);
  const col = s.src_col == null ? '' : '.' + esc(s.src_col);
  const flags = [];
  if (s.ambiguous) flags.push('ambig');
  if (s.unqualified) flags.push('unq');
  const flagStr = flags.length ? ` <small>(${{flags.join(', ')}})</small>` : '';
  return `${{node}}${{col}}${{flagStr}}`;
}}

function renderNodeDetail(n) {{
  const d = n.data();
  const cols = d.columns || [];
  const roles = d.column_roles || {{}};
  const prov = d.column_provenance || {{}};
  const filt = d.filter_references || {{}};
  const bi = d.block_indexes || [];
  const isDerived = d.type !== 'base';

  let html = `<h2>${{esc(d.label)}}</h2>`;
  html += `<div class="meta">Type: <span class="tag">${{esc(d.type)}}</span>`;
  if (d.synthetic) html += ` <span class="tag">synthetic</span>`;
  if (bi.length) html += ` &nbsp;Blocks: ${{bi.join(', ')}}`;
  html += `</div>`;

  // Output columns with provenance — most useful for derived scopes.
  if (cols.length) {{
    const title = isDerived ? 'Output columns &amp; sources' : 'Columns &amp; roles';
    html += `<div class="section"><h3>${{title}}</h3>`;
    html += `<table><thead><tr><th>Column</th><th>${{isDerived ? 'Source(s)' : 'Used in'}}</th></tr></thead><tbody>`;
    const sortedCols = cols.slice().sort();
    for (const c of sortedCols) {{
      let cell;
      if (isDerived) {{
        const sources = prov[c] || [];
        if (!sources.length) {{
          cell = '<span class="empty">—</span>';
        }} else if (sources.length === 1) {{
          cell = formatSourceRef(sources[0]);
        }} else {{
          // Dedupe (multiple clauses may reference the same source).
          const seen = new Set();
          const uniq = sources.filter(s => {{
            const k = (s.src_node||'') + '|' + (s.src_col||'');
            if (seen.has(k)) return false;
            seen.add(k); return true;
          }});
          const amb = uniq.some(s => s.ambiguous);
          if (uniq.length > 3) {{
            cell = `<span class="tag filter">${{amb ? 'ambiguous' : 'multiple'}}</span> ${{uniq.length}} sources`;
            cell += `<ul style="margin-top:4px">${{uniq.map(s => `<li>${{formatSourceRef(s)}}</li>`).join('')}}</ul>`;
          }} else {{
            const badge = amb ? '<span class="tag filter">ambiguous</span> ' : '';
            cell = badge + uniq.map(formatSourceRef).join(', ');
          }}
        }}
      }} else {{
        const rs = roles[c] || [];
        cell = rs.length ? rs.map(clauseTag).join(' ') : '<span class="empty">—</span>';
      }}
      html += `<tr><td>${{esc(c)}}</td><td>${{cell}}</td></tr>`;
    }}
    html += `</tbody></table></div>`;
  }} else {{
    html += `<div class="section"><h3>Columns</h3><div class="empty">none tracked</div></div>`;
  }}

  // Filter predicates — list WHERE/JOIN_ON/HAVING/etc. references.
  const clauses = Object.keys(filt);
  if (clauses.length) {{
    const CLAUSE_ORDER = ['JOIN_ON','WHERE','HAVING','GROUP_BY','ORDER_BY','SELECT'];
    clauses.sort((a,b) => CLAUSE_ORDER.indexOf(a) - CLAUSE_ORDER.indexOf(b));
    html += `<div class="section"><h3>Filter / join predicates</h3>`;
    for (const cl of clauses) {{
      const refs = filt[cl] || [];
      html += `<div style="margin:4px 0 8px">${{clauseTag(cl)}} <small>(${{refs.length}})</small><ul>`;
      const seen = new Set();
      for (const r of refs) {{
        const k = (r.src_node||'') + '|' + (r.src_col||'');
        if (seen.has(k)) continue;
        seen.add(k);
        html += `<li>${{formatSourceRef(r)}}</li>`;
      }}
      html += `</ul></div>`;
    }}
    html += `</div>`;
  }}

  // Compact upstream/downstream summary.
  const incoming = n.incomers('edge');
  const outgoing = n.outgoers('edge');
  html += `<div class="section"><h3>Upstream (${{incoming.length}})</h3>`;
  html += incoming.length
    ? `<ul>${{incoming.map(e => `<li>${{esc(e.data('source'))}} <span class="tag ${{e.data('kind')==='filter'?'filter':''}}">${{esc(e.data('kind'))}}</span> ${{Object.keys(e.data('clause_breakdown')).map(clauseTag).join(' ')}}</li>`).join('')}}</ul>`
    : `<div class="empty">none</div>`;
  html += `</div>`;

  html += `<div class="section"><h3>Downstream (${{outgoing.length}})</h3>`;
  html += outgoing.length
    ? `<ul>${{outgoing.map(e => `<li>${{esc(e.data('target'))}} <span class="tag ${{e.data('kind')==='filter'?'filter':''}}">${{esc(e.data('kind'))}}</span> ${{Object.keys(e.data('clause_breakdown')).map(clauseTag).join(' ')}}</li>`).join('')}}</ul>`
    : `<div class="empty">none</div>`;
  html += `</div>`;

  return html;
}}

function renderEdgeDetail(e) {{
  const d = e.data();
  const pairs = d.pairs || [];
  let html = `<h2>${{esc(d.source)}} → ${{esc(d.target)}}</h2>`;
  html += `<div class="meta">Kind: <span class="tag ${{d.kind==='filter'?'filter':''}}">${{esc(d.kind)}}</span> ${{pairs.length}} column reference(s)</div>`;

  html += `<div class="section"><h3>Column pairs</h3>`;
  if (pairs.length) {{
    html += `<table><thead><tr><th>Source</th><th>Output</th><th>Clause</th><th>Blk</th></tr></thead><tbody>`;
    for (const p of pairs) {{
      const flags = [];
      if (p.ambiguous) flags.push('ambig');
      if (p.unqualified) flags.push('unq');
      const flagStr = flags.length ? ` <small>(${{flags.join(', ')}})</small>` : '';
      html += `<tr><td>${{esc(p.src_col)}}</td><td>${{esc(p.out_col)}}${{flagStr}}</td><td>${{esc(p.clause)}}</td><td>${{esc(p.block)}}</td></tr>`;
    }}
    html += `</tbody></table>`;
  }} else {{
    html += `<div class="empty">no pairs</div>`;
  }}
  html += `</div>`;
  return html;
}}

const detailEl = document.getElementById('detail');
cy.on('tap', 'node', evt => {{ detailEl.innerHTML = renderNodeDetail(evt.target); }});
cy.on('tap', 'edge', evt => {{ detailEl.innerHTML = renderEdgeDetail(evt.target); }});
cy.on('tap', evt => {{ if (evt.target === cy) detailEl.innerHTML = ''; }});

document.getElementById('show-filters').addEventListener('change', e => {{
  cy.edges('[kind = "filter"]').style('display', e.target.checked ? 'element' : 'none');
}});
document.getElementById('show-base').addEventListener('change', e => {{
  cy.nodes('[type = "base"]').style('display', e.target.checked ? 'element' : 'none');
}});
document.getElementById('show-synthetic').addEventListener('change', e => {{
  cy.nodes('[?synthetic]').style('display', e.target.checked ? 'element' : 'none');
}});
document.getElementById('refit').addEventListener('click', () => cy.fit());
</script>
</body>
</html>
"""


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse
    from oracle_sql_analyzer import (
        LineageDAG, process_block, extract_execute_immediate_blocks,
        extract_direct_sql_blocks, clean_sql_for_parsing, clean_direct_sql,
        _parse_declare_variables,
    )

    parser = argparse.ArgumentParser(
        description="Render an interactive lineage graph from a PL/SQL file")
    parser.add_argument("input", help="Path to the .sql file")
    parser.add_argument("--output", "-o", default="lineage.html")
    parser.add_argument("--cytoscape-js", default=None,
                        help="Path to a local cytoscape.min.js for offline use")
    args = parser.parse_args()

    text = Path(args.input).read_text(encoding="utf-8", errors="replace")
    raw_blocks = extract_execute_immediate_blocks(text)
    mode = "execute_immediate"
    if not raw_blocks:
        raw_blocks = extract_direct_sql_blocks(text)
        mode = "direct_sql"
    if not raw_blocks:
        raw_blocks = [text]
        mode = "raw"

    plsql_vars = _parse_declare_variables(text) if mode == "direct_sql" else set()
    dag = LineageDAG()
    for i, raw in enumerate(raw_blocks):
        cleaned = clean_direct_sql(raw, plsql_vars) if mode == "direct_sql" else clean_sql_for_parsing(raw)
        process_block(cleaned, dag, block_index=i + 1)

    render_lineage_html(dag, args.output, title=f"Lineage — {Path(args.input).name}",
                        cytoscape_js_path=args.cytoscape_js)
    print(f"Wrote {args.output} ({len(dag.edges)} edges, "
          f"{len({e['output_table'] for e in dag.edges if e['output_table']})} nodes)")
